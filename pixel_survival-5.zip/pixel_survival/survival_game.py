# PIXEL SURVIVAL v3  |  Python 3 + Pygame  |  Pydroid 3 (Android) / PC
#
# Files needed in the same folder:  survival_game.py  game_data.py  sound.py  net.py
#                                   make_assets.py   (+ assets/ and sounds/ folders,
#                                   they are created automatically when missing)
#
#   - Minecraft-style INVENTORY (36 slots, hotbar, armor slot), CHEST, FURNACE
#   - trees and rocks GROW BACK after a while
#   - CAVES inside the mountains: coal, iron, gold and diamond ore
#   - tools: axe, pickaxe, iron pickaxe, shovel, swords, FISHING ROD
#   - gold / iron / diamond ARMOR, many new walls, floors and blocks
#   - animals, farming, hunger, rain, zombies / spiders / ghosts, sound effects
#   - OAK FENCE + FENCE GATE, WHEAT + seeds, breed cows / sheep / chickens / pigs
#   - title MENU with 3 worlds (new world / continue / delete), pause menu
#   - MULTIPLAYER (Wi-Fi / phone hotspot, up to 4 players): title menu -> Multiplayer
#       Host a Game  = you run the world, friends join your IP
#       Join a Game  = pick the host from the list or type its IP address
#   - the tool you hold (sword, pickaxe, axe...) shows in your hand
#
# TOUCH:  arrow buttons = move | A = hit / chop / mine / open / cook / harvest
#         B = use the held item (place block, eat, wear, plant) or pick up a block
#         bottom bar = hotbar (tap to hold an item) | backpack icon beside it = inventory
#         top right: speaker = sound on/off | menu button = pause menu
# KEYS:   arrows/WASD move | J/Space = A | K/E = B | 1-9 hotbar | I = inventory
#
# SOUND: put your own .ogg / .wav / .mp3 in the "sounds" folder using the same
#        names (chop, mine, hit, hurt, eat, place, craft, pickup, splash, bite,
#        click, death, zombie, sleep, rain, open). music.ogg = background music.
#
# If the screen looks wrong or touch is misplaced, set USE_SCALED = False.

import json
import math
import os
import random
import sys
import time as _time

import pygame

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
from game_data import *          # noqa: E402,F401,F403
from sound import Sfx            # noqa: E402
import net as netlib             # noqa: E402

ASSETS = os.path.join(BASE, "assets")
SOUNDS = os.path.join(BASE, "sounds")
NUM_WORLDS = 3
PLAYER_FILE = os.path.join(BASE, "survival_mp_player.json")     # your character in friends' worlds
SETTINGS_FILE = os.path.join(BASE, "survival_mp_settings.json")  # last IP you joined


def load_settings():
    try:
        with open(SETTINGS_FILE) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(d):
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(d, f)
    except OSError:
        pass


def clean_slots(lst, n):
    """Make a list of n item slots out of untrusted data."""
    out = []
    for sl in (lst if isinstance(lst, list) else [])[:n]:
        item = None
        if isinstance(sl, (list, tuple)) and len(sl) == 2 and isinstance(sl[0], str) \
                and sl[0] in ITEMS:
            try:
                c = int(sl[1])
            except (TypeError, ValueError):
                c = 0
            if c > 0:
                item = [sl[0], min(c, ITEMS[sl[0]][2])]
        out.append(item)
    return out + [None] * (n - len(out))


def world_path(slot):
    return os.path.join(BASE, f"survival_world_{slot}.json")


def read_slot(slot):
    """Info about a saved world (None if the slot is empty)."""
    try:
        with open(world_path(slot)) as f:
            d = json.load(f)
        return {"day": int(d.get("day", 1)), "seed": int(d["seed"])}
    except (OSError, ValueError, KeyError, TypeError):
        return None


USE_SCALED = True               # GPU scaling = much faster than software scaling
SHOW_FPS = True

# ---------- screen layout ----------
MENU_RECT = pygame.Rect(W - 24, 4, 20, 16)
SND_RECT = pygame.Rect(W - 46, 4, 20, 16)
_cx, _cy, _bs = 46, 166, 28
DPAD = {"up": pygame.Rect(_cx - 14, _cy - 44, _bs, _bs),
        "down": pygame.Rect(_cx - 14, _cy + 16, _bs, _bs),
        "left": pygame.Rect(_cx - 44, _cy - 14, _bs, _bs),
        "right": pygame.Rect(_cx + 16, _cy - 14, _bs, _bs)}
A_C, A_R = (350, 160), 21
B_C, B_R = (314, 188), 16
HSLOT = 20
HOT_X = (W - 9 * HSLOT) // 2
HOT_Y = H - 24
BAG_RECT = pygame.Rect(HOT_X - 22, HOT_Y, 18, 18)     # backpack button beside the hotbar
PANEL = pygame.Rect(8, 6, 368, 204)
GX, PITCH, SZ = 16, 23, 21             # inventory grid
COL_X = 242                            # right column of the inventory screen


class Ent:
    def __init__(self, x, y, d=0):
        self.x = float(x)           # feet position (bottom centre)
        self.y = float(y)
        self.dir = d
        self.anim = 0.0
        self.moving = False


class Mob(Ent):
    _next_id = 0

    def __init__(self, kind, x, y):
        super().__init__(x, y, random.randint(0, 3))
        Mob._next_id += 1
        self.id = Mob._next_id
        self.tx, self.ty = float(x), float(y)       # network target (client side)
        d = MOBS[kind]
        self.kind = kind
        self.hp = d["hp"]
        self.speed = d["sp"]
        self.hostile = d["hostile"]
        self.dmg = d["dmg"]
        self.hit_cd = 0.5
        self.flash = 0.0
        self.kx = self.ky = 0.0
        self.burn = random.uniform(0.5, 5.0)      # monsters burn in daylight
        self.stuck = 0.0
        self.wander = 0.0
        self.wx = self.wy = 0.0
        self.flee = 0.0
        self.idle = random.uniform(0, 2)
        self.leap = 0.0
        self.leap_cd = random.uniform(1, 3)
        self.baby = False
        self.age = 0.0
        self.love = 0.0
        self.breed_cd = 0.0


class RPlayer(Ent):
    """Another player in the same world."""

    def __init__(self, pid, name, x, y):
        super().__init__(x, y, 0)
        self.pid = pid
        self.name = name
        self.armor = None
        self.held = None
        self.swing = 0.0
        self.tx, self.ty = float(x), float(y)


def make_light(r):
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    for rad in range(r, 0, -1):
        a = int(255 * (1 - rad / r) ** 1.25)
        pygame.draw.circle(s, (0, 0, 0, a), (r, r), rad)
    return s


def item_name(k):
    return ITEMS[k][0]


_RES = {}
RES_KEYS = ("tiles", "chars", "animal_img", "spider", "ghostR", "ghostL", "icons", "heart",
            "hunger_icon", "item_icon", "fxf", "shadow", "slot_bg", "lights", "dark", "fade",
            "redsurf", "rain_surf", "font", "tiny", "big", "_txt", "baby_cache", "hand_cache")


def get_res():
    """Load all images once (shared by the title menu and every world)."""
    if not _RES:
        class _Loader:
            pass
        Game.load_images(_Loader())
    return _RES


def put_text(cv, s, x, y, col=(255, 255, 255), font=None, center=False, right=False):
    font = font or _RES["font"]
    cache = _RES["_txt"]
    key = (s, col, id(font))
    img = cache.get(key)
    if img is None:
        if len(cache) > 500:
            cache.clear()
        shade = font.render(s, False, (20, 20, 30))
        img = pygame.Surface((shade.get_width() + 1, shade.get_height() + 1), pygame.SRCALPHA)
        img.blit(shade, (1, 1))
        img.blit(font.render(s, False, col), (0, 0))
        cache[key] = img
    if center:
        x -= img.get_width() // 2
    if right:
        x -= img.get_width()
    cv.blit(img, (int(x), int(y)))


# ============================================================
#  GAME
# ============================================================

class Game:
    def __init__(self, canvas, snd, slot, seed, net=None, welcome=None):
        self.cv = canvas
        self.snd = snd
        self.slot = slot
        self.seed = seed
        self.net = net                          # netlib.Host / netlib.Client / None
        self.welcome = welcome
        self.is_client = bool(net and welcome)
        self.is_host = bool(net and not welcome)
        self.my_id = welcome["id"] if welcome else 0
        self.my_name = welcome["name"] if welcome else "Host"
        self.remotes = {}                       # id -> RPlayer (the other players)
        self.mob_ids = {}                       # client: network id -> Mob
        self.pending = {}                       # host: connections waiting for their hello
        self._remote = False                    # True while applying an edit from the network
        self.exit_msg = ""
        self.net_send_t = self.net_snap_t = self.net_cont_t = 0.0
        self.cont_lock = -99.0
        self.last_cont = ""
        self.path = None if self.is_client else world_path(slot)
        self.request = None                     # "title" when the player leaves the world
        self.floats = []                        # floating damage numbers
        self.mobs_loaded = False
        self.load_images()
        self.ground, self.var, self.obj = gen_world(seed)
        self.floor = [[0] * MAP for _ in range(MAP)]
        c = MAP * T / 2
        self.spawn = (c, c + 8)
        self.p = Ent(*self.spawn)
        self.hp = MAXHP
        self.hunger = float(MAXFOOD)
        self.starve_t = 0.0
        self.inv = [None] * INV_SIZE            # each slot: None or [item, count]
        self.armor_slot = [None]
        self.sel = 0                            # held hotbar slot
        self.cursor = None                      # stack carried by the cursor (UI)
        self.ui = None                          # None / inv / craft / chest / furnace
        self.ui_key = None
        self.station = "hand"
        self.scroll = 0
        self.ui_rects, self.ui_btns, self.craft_rows = [], [], []
        self.chests = {}                        # (tx,ty) -> 27 slots
        self.furnaces = {}                      # (tx,ty) -> {"s":[in,fuel,out],"prog","burn"}
        self.regrow = []                        # [tx, ty, object id, seconds]
        self.crops = {}                         # (tx,ty) -> [first-stage id, seconds]
        self.fishing = None
        self.time = START_TIME
        self.day = 1
        self.mobs = []
        self.fx = []                            # [x, y, kind(0 spark/1 smoke), age]
        self.hits = {}
        self.hurt_t = 99.0
        self.invuln = 0.0
        self.regen = 0.0
        self.act_cd = 0.0
        self.swing = 0.0
        self.spawn_t = 3.0
        self.cave_t = 3.0
        self.animal_t = 2.0
        self.hint_t = 0.0
        self.hint_text = ""
        self.sleep_phase = None
        self.sleep_fade = 0.0
        self.sleep_hold = 0.0
        self.dead_t = 0.0
        self.red = 0.0
        self.cave_a = 0.0
        self.raining = False
        self.rain_a = 0.0
        self.weather_t = random.uniform(70, 150)
        self.drops = [[random.uniform(0, W), random.uniform(0, H), random.uniform(260, 340)]
                      for _ in range(60)]
        self.exit_armed = 0.0
        self.save_t = 60.0
        self.clock = 0.0
        self.fps = 0.0
        self.load()
        self.build_layers()
        self.index_objects()
        if not self.box_free(self.p.x, self.p.y):
            self.p.x, self.p.y = self.spawn
        if not self.mobs_loaded and not self.is_client:
            self.populate_animals()
        if self.path and not os.path.exists(self.path):
            self.save()                         # the new world now shows up in the menu
        if self.is_host:
            self.hint("Friends join with IP: " + self.net.ips[0], 9)
        elif self.is_client:
            self.hint("Joined! You are " + self.my_name, 5)
        else:
            self.hint("Hold A near a tree to chop wood!", 6)

    # ---------- assets ----------
    def load_images(self):
        if _RES:
            self.__dict__.update(_RES)
            return
        need = ("tiles.png", "player.png", "player_armor.png", "player_gold.png",
                "player_diamond.png", "zombie.png", "animals.png", "spider.png",
                "ghost.png", "items.png", "fx.png")
        if not all(os.path.exists(os.path.join(ASSETS, n)) for n in need):
            import make_assets
            make_assets.generate(ASSETS)

        def ld(name):
            return pygame.image.load(os.path.join(ASSETS, name)).convert_alpha()

        def cut(sheet, x, y, w, h):
            return sheet.subsurface((x, y, w, h)).copy()

        sheet = ld("tiles.png")
        self.tiles = [cut(sheet, (i % 10) * T, (i // 10) * T, T, T) for i in range(72)]
        self.chars = {}
        for key, name in (("player", "player.png"), ("iarmor", "player_armor.png"),
                          ("garmor", "player_gold.png"), ("darmor", "player_diamond.png"),
                          ("zombie", "zombie.png")):
            sh = ld(name)
            self.chars[key] = [[cut(sh, f * 16, r * 20, 16, 20) for f in range(3)]
                               for r in range(4)]
        an = ld("animals.png")
        self.animal_img = {}
        for r, kind in enumerate(ANIMALS):
            cells = [cut(an, c * 16, r * 16, 16, 16) for c in range(4)]
            self.animal_img[kind] = {
                "R": cells[0:2],
                "L": [pygame.transform.flip(i, True, False) for i in cells[0:2]],
                "F": cells[2:4]}
        sp = ld("spider.png")
        self.spider = [cut(sp, f * 16, 0, 16, 16) for f in range(2)]
        gh = ld("ghost.png")
        self.ghostR, self.ghostL = [], []
        for f in range(2):
            g = cut(gh, f * 16, 0, 16, 16)
            g.set_alpha(175)
            self.ghostR.append(g)
            gl = pygame.transform.flip(g, True, False)
            gl.set_alpha(175)
            self.ghostL.append(gl)

        items = ld("items.png")
        self.icons = {i: cut(items, (i % 8) * 16, (i // 8) * 16, 16, 16) for i in range(40)}
        self.heart = {"full": cut(items, 32 + 2, 3, 11, 10),
                      "empty": cut(items, 48 + 2, 3, 11, 10),
                      "half": cut(items, 64 + 2, 16 + 3, 11, 10)}
        self.hunger_icon = {"full": self.icons[13], "empty": self.icons[14],
                            "half": self.icons[15]}
        self.item_icon = {}
        for key, (name, (src, idx), stack, kind) in ITEMS.items():
            self.item_icon[key] = self.icons[idx] if src == "i" else self.tiles[idx]
        fx = ld("fx.png")
        self.fxf = [cut(fx, i * 16, 0, 16, 16) for i in range(6)]

        self.shadow = pygame.Surface((14, 6), pygame.SRCALPHA)
        pygame.draw.ellipse(self.shadow, (0, 0, 0, 70), (0, 0, 14, 6))
        self.slot_bg = pygame.Surface((HSLOT - 2, HSLOT - 2), pygame.SRCALPHA)
        self.slot_bg.fill((20, 24, 34, 170))
        self.lights = {r: make_light(r) for r in (36, 40, 44, 48, 70, 80)}
        self.dark = pygame.Surface((W, H), pygame.SRCALPHA)
        self.fade = pygame.Surface((W, H))
        self.fade.fill((0, 0, 0))
        self.redsurf = pygame.Surface((W, H))
        self.redsurf.fill((200, 30, 30))
        self.rain_surf = pygame.Surface((W, H))
        self.rain_surf.fill((22, 30, 52))
        self.font = pygame.font.Font(None, 16)
        self.tiny = pygame.font.Font(None, 14)
        self.big = pygame.font.Font(None, 28)
        self._txt = {}
        self.baby_cache = {}
        self.hand_cache = {}
        _RES.update({k: self.__dict__[k] for k in RES_KEYS})

    def text(self, s, x, y, col=(255, 255, 255), font=None, center=False, right=False):
        put_text(self.cv, s, x, y, col, font, center, right)

    def hint(self, s, sec=2.0):
        self.hint_text = s
        self.hint_t = sec

    # ---------- world layers (pre-rendered -> fast) ----------
    def ground_idx(self, tx, ty, frame):
        g = self.ground[ty][tx]
        if g == G_WATER:
            return 4 + frame
        if g == G_SAND:
            return 6 + (self.var[ty][tx] & 1)
        if g == G_DIRT:
            return 9
        if g == G_CAVE:
            return 35
        return self.var[ty][tx]

    def paint_tile(self, tx, ty):
        for f, layer in enumerate(self.layers):
            layer.blit(self.tiles[self.ground_idx(tx, ty, f)], (tx * T, ty * T))
            fl = self.floor[ty][tx]
            if fl:
                layer.blit(self.tiles[FLOOR_TILE[fl]], (tx * T, ty * T))

    def build_layers(self):
        self.layers = [pygame.Surface((MAP * T, MAP * T)).convert() for _ in (0, 1)]
        for ty in range(MAP):
            for tx in range(MAP):
                self.paint_tile(tx, ty)

    def set_floor(self, tx, ty, v):
        self.floor[ty][tx] = v
        self.paint_tile(tx, ty)
        self.net_edit("f", tx, ty, v)

    def set_ground(self, tx, ty, g):
        self.ground[ty][tx] = g
        self.paint_tile(tx, ty)
        self.net_edit("g", tx, ty, g)

    def index_objects(self):
        self.obj_rows = [{} for _ in range(MAP)]
        self.light_objs = {}
        for ty in range(MAP):
            row = self.obj[ty]
            for tx in range(MAP):
                o = row[tx]
                if o:
                    self.obj_rows[ty][tx] = o
                    if o in LIGHT:
                        self.light_objs[(tx, ty)] = o

    def set_obj(self, tx, ty, o):
        self.obj[ty][tx] = o
        if o:
            self.obj_rows[ty][tx] = o
            if o in LIGHT:
                self.light_objs[(tx, ty)] = o
        else:
            self.obj_rows[ty].pop(tx, None)
            self.light_objs.pop((tx, ty), None)
        self.net_edit("o", tx, ty, o)

    # ---------- save / load ----------
    def save_player(self):
        data = {"hp": self.hp, "hunger": self.hunger, "inv": self.inv,
                "armor": self.armor_slot[0], "sel": self.sel}
        try:
            with open(PLAYER_FILE, "w") as f:
                json.dump(data, f)
        except OSError:
            pass

    def load_player(self):
        try:
            with open(PLAYER_FILE) as f:
                d = json.load(f)
            self.hp = clamp(int(d["hp"]), 1, MAXHP)
            self.hunger = clamp(float(d["hunger"]), 0.0, MAXFOOD)
            self.inv = clean_slots(d["inv"], INV_SIZE)
            a = clean_slots([d.get("armor")], 1)[0]
            self.armor_slot = [a if a and ITEMS[a[0]][3] == "armor" else None]
            self.sel = int(d.get("sel", 0)) % 9
        except (OSError, ValueError, KeyError, TypeError):
            pass

    def load_client(self):
        w = self.welcome["world"]
        for key in ("obj", "floor", "ground"):
            if len(w[key]) != MAP * MAP:
                raise ValueError("world size does not match")
        self.obj, self.floor, self.ground = dec(w["obj"]), dec(w["floor"]), dec(w["ground"])
        self.time, self.day = float(w["time"]), int(w["day"])
        self.raining = bool(w.get("rain"))
        self.rain_a = 1.0 if self.raining else 0.0
        self.chests = {(int(a), int(b)): clean_slots(v, 27) for a, b, v in w.get("chests", [])}
        self.furnaces = {(int(a), int(b)): {"s": clean_slots(sl, 3), "prog": float(pr),
                                            "burn": float(bu)}
                         for a, b, sl, pr, bu in w.get("furnaces", [])}
        hx, hy = self.welcome["pos"]
        self.p.x, self.p.y = float(hx), float(hy)
        for ox, oy in ((10, 0), (-10, 0), (0, 10), (0, -10), (0, 0)):
            if self.box_free(self.p.x + ox, self.p.y + oy):
                self.p.x += ox
                self.p.y += oy
                break
        self.load_player()

    def save(self):
        if self.is_client:
            self.save_player()
            return
        data = {
            "obj": enc(self.obj), "floor": enc(self.floor), "ground": enc(self.ground),
            "x": self.p.x, "y": self.p.y, "hp": self.hp, "hunger": self.hunger,
            "inv": self.inv, "armor": self.armor_slot[0],
            "time": self.time, "day": self.day, "sel": self.sel,
            "crops": [[k[0], k[1], v[0], v[1]] for k, v in self.crops.items()],
            "chests": [[k[0], k[1], v] for k, v in self.chests.items()],
            "furnaces": [[k[0], k[1], v] for k, v in self.furnaces.items()],
            "regrow": self.regrow, "seed": self.seed,
            "mobs": [[m.kind, round(m.x, 1), round(m.y, 1), m.baby, round(m.age, 1),
                      round(m.breed_cd, 1)] for m in self.mobs if not m.hostile][:80],
        }
        try:
            with open(self.path, "w") as f:
                json.dump(data, f)
        except OSError:
            pass

    def load(self):
        if self.is_client:
            self.load_client()
            return
        try:
            with open(self.path) as f:
                d = json.load(f)
            for key in ("obj", "floor", "ground"):
                if len(d[key]) != MAP * MAP:
                    return
            self.obj, self.floor, self.ground = dec(d["obj"]), dec(d["floor"]), dec(d["ground"])
            self.p.x, self.p.y = float(d["x"]), float(d["y"])
            self.hp = clamp(int(d["hp"]), 1, MAXHP)
            self.hunger = clamp(float(d["hunger"]), 0.0, MAXFOOD)
            inv = d["inv"]
            self.inv = [s if (s and s[0] in ITEMS) else None for s in inv][:INV_SIZE]
            self.inv += [None] * (INV_SIZE - len(self.inv))
            a = d.get("armor")
            self.armor_slot = [a if (a and a[0] in ITEMS) else None]
            self.time, self.day = float(d["time"]), int(d["day"])
            self.sel = int(d.get("sel", 0)) % 9
            self.crops = {(int(a), int(b)): [int(c), float(t)] for a, b, c, t in d.get("crops", [])}
            self.chests = {(int(a), int(b)): v for a, b, v in d.get("chests", [])}
            self.furnaces = {(int(a), int(b)): v for a, b, v in d.get("furnaces", [])}
            self.regrow = [list(r) for r in d.get("regrow", [])]
            if "mobs" in d:
                for kind, x, y, baby, age, cd in d["mobs"]:
                    if kind in ANIMALS:
                        m = Mob(kind, x, y)
                        m.baby, m.age, m.breed_cd = bool(baby), float(age), float(cd)
                        if m.baby:
                            m.hp = max(1, m.hp // 2)
                        self.mobs.append(m)
                self.mobs_loaded = True
        except (OSError, ValueError, KeyError, TypeError):
            pass

    # ---------- collision ----------
    def solid_tile(self, tx, ty, mode=0):
        if not (0 <= tx < MAP and 0 <= ty < MAP):
            return True
        o = self.obj[ty][tx]
        if o in SOLID_OBJ:
            return True
        if mode == 1 and o in ANIMAL_SOLID:
            return True
        if mode == 2 and o in HOSTILE_SOLID:
            return True
        if self.ground[ty][tx] == G_WATER and not self.floor[ty][tx]:
            return True
        return False

    def box_free(self, x, y, mode=0):
        x0 = int((x - 5) // T)
        x1 = int((x + 4.99) // T)
        y0 = int((y - 6) // T)
        y1 = int((y - 0.01) // T)
        for ty in range(y0, y1 + 1):
            for tx in range(x0, x1 + 1):
                if self.solid_tile(tx, ty, mode):
                    return False
        return True

    def move(self, e, dx, dy, mode=0):
        if self.box_free(e.x + dx, e.y, mode):
            e.x += dx
        if self.box_free(e.x, e.y + dy, mode):
            e.y += dy

    def move_mob(self, m, dx, dy):
        if m.kind == "ghost":                       # flies through everything
            m.x = clamp(m.x + dx, 12, MAP * T - 12)
            m.y = clamp(m.y + dy, 12, MAP * T - 12)
        else:
            self.move(m, dx, dy, 2 if m.hostile else 1)

    def target(self):
        """Tile in front of the player (player's tile + facing direction)."""
        p = self.p
        dx, dy = DV[p.dir]
        return (int(math.floor(p.x / T)) + dx,
                int(math.floor((p.y - 5) / T)) + dy)

    def in_map(self, tx, ty):
        return 0 <= tx < MAP and 0 <= ty < MAP

    def overlaps_player(self, tx, ty):
        p = self.p
        return (p.x + 5 > tx * T and p.x - 5 < (tx + 1) * T
                and p.y > ty * T and p.y - 6 < (ty + 1) * T)

    def occupied(self, tx, ty):
        if self.overlaps_player(tx, ty):
            return True
        for rp in self.remotes.values():
            if tx * T - 6 < rp.x < (tx + 1) * T + 6 and ty * T - 4 < rp.y < (ty + 1) * T + 8:
                return True
        for m in self.mobs:
            if tx * T - 6 < m.x < (tx + 1) * T + 6 and ty * T - 4 < m.y < (ty + 1) * T + 8:
                return True
        return False

    # ---------- inventory ----------
    def add_item(self, item, n=1):
        mx = ITEMS[item][2]
        for s in self.inv:
            if s and s[0] == item and s[1] < mx:
                a = min(n, mx - s[1])
                s[1] += a
                n -= a
                if n <= 0:
                    return 0
        for i, s in enumerate(self.inv):
            if s is None:
                a = min(n, mx)
                self.inv[i] = [item, a]
                n -= a
                if n <= 0:
                    return 0
        return n

    def count(self, item):
        return sum(s[1] for s in self.inv if s and s[0] == item)

    def remove_item(self, item, n):
        for i, s in enumerate(self.inv):
            if s and s[0] == item and n > 0:
                a = min(n, s[1])
                s[1] -= a
                n -= a
                if s[1] <= 0:
                    self.inv[i] = None

    def can_fit(self, item, n):
        mx = ITEMS[item][2]
        space = sum(mx - s[1] for s in self.inv if s and s[0] == item)
        space += sum(mx for s in self.inv if s is None)
        return space >= n

    def can_pay(self, cost):
        return all(self.count(k) >= v for k, v in cost.items())

    def pay(self, cost):
        for k, v in cost.items():
            self.remove_item(k, v)

    def gain(self, item, n, quiet=False):
        left = self.add_item(item, n)
        if n - left > 0 and not quiet:
            self.hint(f"+{n - left} {item_name(item)}", 1.5)
            self.snd.play("pickup", 0.6)
        if left:
            self.hint("Inventory full!", 2)
        return left

    def held(self):
        s = self.inv[self.sel]
        return s[0] if s else None

    def take_held(self, n=1):
        s = self.inv[self.sel]
        if s:
            s[1] -= n
            if s[1] <= 0:
                self.inv[self.sel] = None

    def armor_key(self):
        s = self.armor_slot[0]
        return s[0] if s else None

    # ---------- eating / armor ----------
    def try_eat(self, key):
        if self.hunger >= MAXFOOD - 0.5:
            self.hint("You are full", 1.5)
            return False
        self.hunger = min(float(MAXFOOD), self.hunger + FOOD[key])
        self.snd.play("eat")
        self.hint(f"Ate {item_name(key)} (+{FOOD[key] // 2} hunger)", 1.5)
        return True

    def equip_held(self):
        s = self.inv[self.sel]
        old = self.armor_slot[0]
        self.armor_slot[0] = [s[0], 1]
        self.inv[self.sel] = old
        self.snd.play("craft")
        self.hint(f"Wearing {item_name(s[0])}", 2)

    # ---------- player actions ----------
    def try_act(self):
        if self.dead_t > 0 or self.sleep_phase or self.ui:
            return
        self.act_cd = 0.28
        self.act()

    def kill(self, m, killer=0):
        if m in self.mobs:
            self.mobs.remove(m)
        self.fx.append([m.x, m.y - 8, 1, 0.0])
        loot = []
        for item, lo, hi in MOBS[m.kind]["drops"]:
            n = random.randint(lo, hi)
            if n > 0:
                loot.append([item, n])
        if killer and self.net and killer in self.net.conns:
            self.net.send(killer, {"t": "loot", "i": loot})     # the drops go to the killer
        else:
            for item, n in loot:
                self.gain(item, n)

    def hit_effects(self, m, dmg):
        self.fx.append([m.x, m.y - 8, 0, 0.0])
        self.floats.append([m.x, m.y - 22, f"-{dmg}", 0.7,
                            (255, 226, 80) if dmg >= 4 else (255, 255, 255)])
        self.snd.play("hit")

    def hit_mob(self, m, dmg, dx, dy, kb, killer=0):
        m.hp -= dmg
        m.flash = 0.15
        m.kx, m.ky = dx * kb, dy * kb
        if not m.hostile:
            m.flee = 3.0
        self.hit_effects(m, dmg)
        if m.hp <= 0:
            self.kill(m, killer)

    def act(self):
        p = self.p
        if self.fishing:
            self.reel()
            return
        held = self.held()
        self.swing = 0.2
        dx, dy = DV[p.dir]
        cx, cy = p.x + dx * 12, p.y - 6 + dy * 12
        dmg_hand = TOOL_DMG.get(held, 1)
        dmg_mon = TOOL_DMG_HOSTILE.get(held, dmg_hand)        # swords hurt monsters more
        hit = False
        for m in list(self.mobs):
            if abs(m.x - cx) < 13 and abs(m.y - 6 - cy) < 13:
                dmg = dmg_mon if m.hostile else dmg_hand
                kb = 170 if (held in SWORDS and m.hostile) else 110
                if self.is_client:                       # the host owns the mobs
                    self.net.send({"t": "hit", "id": m.id, "dmg": dmg, "dx": dx, "dy": dy,
                                   "kb": kb})
                    m.flash = 0.15
                    self.hit_effects(m, dmg)
                else:
                    self.hit_mob(m, dmg, dx, dy, kb)
                hit = True
        if hit:
            return
        tx, ty = self.target()
        if not self.in_map(tx, ty):
            return
        o = self.obj[ty][tx]
        px, py = tx * T + 8, ty * T + 8
        if o == 0 and held == "rod":
            if self.ground[ty][tx] == G_WATER and not self.floor[ty][tx]:
                self.cast(tx, ty)
            else:
                self.hint("Face the water to fish", 1.5)
        elif o in RES:
            self.hit_resource(o, tx, ty, held)
        elif o == O_TABLE:
            self.open_ui("craft", "table")
        elif o == O_CHEST:
            self.open_ui("chest", (tx, ty))
        elif o == O_FURNACE:
            self.open_ui("furnace", (tx, ty))
        elif o in CROP_INFO:
            kind, base, stage = CROP_INFO[o]
            if stage == 2:
                self.set_obj(tx, ty, base)               # it regrows
                self.start_crop(tx, ty, base)
                self.fx.append([px, py, 0, 0.0])
                for item, lo, hi in CROP_DROPS[kind]:
                    self.gain(item, random.randint(lo, hi))
            else:
                self.hint("Not ripe yet (B picks it up)", 1.5)
        elif o == O_FIRE:
            self.cook_at_fire(px, py)
        elif o in (O_GATE, O_GATE_OPEN):
            self.toggle_gate(tx, ty)
        elif o == O_BED:
            if night_factor(self.time) > 0.5:
                self.sleep_phase, self.sleep_fade = "out", 0.0
                self.snd.play("sleep")
            else:
                self.hint("You can only sleep at night", 2)
        elif o == 0 and held == "shovel":
            self.dig(tx, ty)
        elif o == 0 and self.ground[ty][tx] == G_GRASS and not self.floor[ty][tx] \
                and random.random() < 0.12:                  # seeds from the grass
            self.gain("seeds", 1)
            self.fx.append([px, py, 1, 0.0])

    def start_crop(self, tx, ty, base):
        if self.is_client:
            self.net.send({"t": "crop", "x": tx, "y": ty, "b": base})
        else:
            self.crops[(tx, ty)] = [base, 0.0]

    def add_regrow(self, tx, ty, o, secs):
        if self.is_client:
            self.net.send({"t": "rg", "x": tx, "y": ty, "o": o, "s": round(secs, 1)})
        else:
            self.regrow.append([tx, ty, o, secs])

    def toggle_gate(self, tx, ty):
        o = self.obj[ty][tx]
        if o == O_GATE_OPEN and self.occupied(tx, ty):
            self.hint("Something is in the way", 1.5)
            return
        self.set_obj(tx, ty, O_GATE_OPEN if o == O_GATE else O_GATE)
        self.snd.play("open")

    def is_fence(self, tx, ty):
        return self.in_map(tx, ty) and self.obj[ty][tx] in (O_FENCE, O_GATE, O_GATE_OPEN)

    def fence_mask(self, tx, ty):
        return ((1 if self.is_fence(tx, ty - 1) else 0) | (2 if self.is_fence(tx + 1, ty) else 0)
                | (4 if self.is_fence(tx, ty + 1) else 0) | (8 if self.is_fence(tx - 1, ty) else 0))

    def gate_vertical(self, tx, ty):
        m = self.fence_mask(tx, ty)
        return bool(m & 5) and not (m & 10)

    # ---------- animals: feeding and breeding ----------
    def animal_in_front(self):
        p = self.p
        dx, dy = DV[p.dir]
        cx, cy = p.x + dx * 12, p.y - 6 + dy * 12
        for m in self.mobs:
            if not m.hostile and abs(m.x - cx) < 14 and abs(m.y - 6 - cy) < 14:
                return m
        return None

    def remote_feed(self, m):
        """Host: a friend fed this animal."""
        if m.baby:
            m.age += 30
        elif not (m.love > 0 or m.breed_cd > 0):
            m.love = LOVE_TIME

    def feed(self, m):
        name = m.kind.capitalize()
        if self.is_client:
            if not m.baby and (m.love > 0 or m.breed_cd > 0):
                self.hint(f"The {m.kind} is not hungry now", 1.5)
                return
            self.net.send({"t": "feed", "id": m.id})
            self.take_held()
            self.hint(f"The baby {m.kind} grows faster!" if m.baby
                      else f"{name} is in love! Feed another one", 2.5)
            self.snd.play("eat")
            return
        if m.baby:
            m.age += 30
            self.take_held()
            self.hint(f"The baby {m.kind} grows faster!", 1.5)
        elif m.love > 0 or m.breed_cd > 0:
            self.hint(f"The {m.kind} is not hungry now", 1.5)
            return
        else:
            m.love = LOVE_TIME
            self.take_held()
            self.hint(f"{name} is in love! Feed another one", 2.5)
        self.snd.play("eat")

    def find_partner(self, m):
        best, bd = None, 130.0
        for o in self.mobs:
            if o is not m and o.kind == m.kind and o.love > 0 and not o.baby:
                d = math.hypot(o.x - m.x, o.y - m.y)
                if d < bd:
                    best, bd = o, d
        return best

    def try_breed(self, m, newborns):
        if len(self.mobs) + len(newborns) > 70:
            return
        for o in self.mobs:
            if o is not m and o.kind == m.kind and o.love > 0 and not o.baby \
                    and abs(o.x - m.x) < 28 and abs(o.y - m.y) < 22:
                b = Mob(m.kind, (m.x + o.x) / 2, (m.y + o.y) / 2)
                b.baby, b.age = True, 0.0
                b.hp = max(1, b.hp // 2)
                newborns.append(b)
                m.love = o.love = 0.0
                m.breed_cd = o.breed_cd = BREED_COOLDOWN
                self.floats.append([b.x, b.y - 22, "Baby!", 1.2, (255, 170, 200)])
                self.snd.play("pickup")
                return

    def hit_resource(self, o, tx, ty, held):
        hp, drop, (lo, hi), need, tool = RES[o]
        tier = TOOL_TIER.get(held, 0)
        if tier < need:
            self.hint("You need a Pickaxe" if need == 1 else "You need an Iron Pickaxe", 2)
            self.snd.play("click")
            return
        dmg = 1
        if tool == "axe" and held == "axe":
            dmg = 2
        elif tool == "pick" and tier > 0:
            dmg = 1 + tier
        h = self.hits.setdefault((tx, ty), [0, 2.0])
        h[0] += dmg
        h[1] = 2.0
        self.fx.append([tx * T + 8, ty * T + 8, 0, 0.0])
        self.snd.play("chop" if o == O_TREE else "mine")
        if h[0] >= hp:
            del self.hits[(tx, ty)]
            self.set_obj(tx, ty, 0)
            self.gain(drop, random.randint(lo, hi))
            if o in (O_TREE, O_ROCK):                    # they grow back later
                self.add_regrow(tx, ty, o, random.uniform(REGROW_MIN, REGROW_MAX))

    def dig(self, tx, ty):
        g = self.ground[ty][tx]
        if g not in (G_GRASS, G_DIRT, G_SAND) or self.floor[ty][tx]:
            return
        h = self.hits.setdefault((tx, ty), [0, 2.0])
        h[0] += 1
        h[1] = 2.0
        self.fx.append([tx * T + 8, ty * T + 8, 1, 0.0])
        self.snd.play("place", 0.6)
        if h[0] >= 2:
            del self.hits[(tx, ty)]
            self.gain("sand" if g == G_SAND else "dirt", 1)
            if g == G_GRASS:
                self.set_ground(tx, ty, G_DIRT)

    def cook_at_fire(self, px, py):
        for raw, done in COOK.items():
            if self.count(raw) > 0:
                self.remove_item(raw, 1)
                self.gain(done, 1, quiet=True)
                self.fx.append([px, py - 4, 1, 0.0])
                self.snd.play("eat", 0.5)
                self.hint(f"Cooked {item_name(done)}!", 1.5)
                return
        self.hint("Bring raw meat, fish or a potato to cook", 1.8)

    # ---------- fishing ----------
    def cast(self, tx, ty):
        self.fishing = {"tx": tx, "ty": ty, "phase": "wait", "t": random.uniform(2.5, 6.0)}
        self.snd.play("splash")
        self.hint("Waiting for a bite... then press A!", 2.5)

    def reel(self):
        f = self.fishing
        if f["phase"] == "bite":
            self.gain("fish", 1)
        else:
            self.hint("Too early! The fish got scared", 1.5)
            self.snd.play("click")
        self.fishing = None

    def update_fishing(self, dt):
        f = self.fishing
        if not f:
            return
        if self.held() != "rod" or self.p.moving:
            self.fishing = None
            self.hint("Stopped fishing", 1.2)
            return
        f["t"] -= dt
        if f["phase"] == "wait" and f["t"] <= 0:
            f["phase"], f["t"] = "bite", 1.0
            self.snd.play("bite")
            self.hint("A fish! Press A now!", 1.0)
        elif f["phase"] == "bite" and f["t"] <= 0:
            self.fishing = None
            self.hint("It got away...", 1.5)

    # ---------- B button: use held item / pick up ----------
    def use_held(self):
        if self.ui or self.dead_t > 0 or self.sleep_phase:
            return
        held = self.held()
        kind = ITEMS[held][3] if held else None
        tx, ty = self.target()
        if not self.in_map(tx, ty):
            return
        o = self.obj[ty][tx]
        animal = self.animal_in_front()
        if animal and held in ANIMAL_FOOD[animal.kind]:
            self.feed(animal)
            return
        if held in PLANTABLE and o == 0 and not self.floor[ty][tx] \
                and self.ground[ty][tx] in (G_GRASS, G_DIRT):
            base = PLACE[held][1]
            self.take_held()
            self.set_obj(tx, ty, base)
            self.start_crop(tx, ty, base)
            self.snd.play("place")
            self.hint("Planted!", 1)
            return
        if kind == "food":
            if self.try_eat(held):
                self.take_held()
            return
        if kind == "armor":
            self.equip_held()
            return
        if o in PICK_ITEM:
            self.pickup(tx, ty, o)
        elif o in RES:
            self.hint("Use A to chop / mine that", 1.5)
        elif o == 0 and self.floor[ty][tx] and held in PLACE and PLACE[held][0] == "floor":
            item = FLOOR_ITEM[self.floor[ty][tx]]
            if self.can_fit(item, 1):
                self.gain(item, 1, quiet=True)
                self.set_floor(tx, ty, 0)
                self.snd.play("pickup", 0.6)
            else:
                self.hint("Inventory full!", 1.5)
        elif held in PLACE:
            self.place_block(tx, ty, held)
        else:
            self.hint("Hold a block, food or armor and press B", 1.8)

    def pickup(self, tx, ty, o):
        item = PICK_ITEM[o]
        if o == O_CHEST and any(self.chests.get((tx, ty), [])):
            self.hint("Empty the chest first", 1.8)
            return
        if o == O_FURNACE and any(self.furnaces.get((tx, ty), {"s": []})["s"]):
            self.hint("Empty the furnace first", 1.8)
            return
        if not self.can_fit(item, 1):
            self.hint("Inventory full!", 1.5)
            return
        self.gain(item, 1, quiet=True)
        self.set_obj(tx, ty, 0)
        self.crops.pop((tx, ty), None)
        self.chests.pop((tx, ty), None)
        self.furnaces.pop((tx, ty), None)
        self.snd.play("pickup", 0.6)
        self.hint("Picked up " + item_name(item), 1)

    def place_block(self, tx, ty, held):
        kind, oid = PLACE[held]
        if kind == "floor":
            self.set_floor(tx, ty, oid)
            self.take_held()
            self.snd.play("place")
            return
        if kind == "crop":
            self.hint("Plant on bare grass or dirt", 1.5)
            return
        water = self.ground[ty][tx] == G_WATER and not self.floor[ty][tx]
        if kind == "dirt" and water:
            self.set_ground(tx, ty, G_DIRT)
            self.take_held()
            self.snd.play("place")
            self.hint("Filled the water with dirt", 1.5)
            return
        if water:
            self.hint("Can't build on water (use a floor)", 2)
            return
        solid = oid in SOLID_OBJ
        if solid or oid == O_DOOR:
            for m in self.mobs + list(self.remotes.values()):
                if self.near_tile(m, tx, ty):
                    self.hint("Something is in the way", 1.5)
                    return
        p = self.p
        if solid and self.overlaps_player(tx, ty):
            dx, dy = DV[p.dir]
            if dx > 0:
                need = (p.x + 5) - tx * T
            elif dx < 0:
                need = (tx + 1) * T - (p.x - 5)
            elif dy > 0:
                need = p.y - ty * T
            else:
                need = (ty + 1) * T - (p.y - 6)
            nx, ny = p.x - dx * (need + 0.5), p.y - dy * (need + 0.5)
            if self.box_free(nx, ny):
                p.x, p.y = nx, ny
            else:
                self.hint("Something is in the way", 1.5)
                return
        self.set_obj(tx, ty, oid)
        self.take_held()
        self.snd.play("place")
        if oid == O_CHEST:
            self.chests[(tx, ty)] = [None] * 27
        elif oid == O_FURNACE:
            self.furnaces[(tx, ty)] = {"s": [None, None, None], "prog": 0.0, "burn": 0.0}

    def near_tile(self, m, tx, ty):
        return tx * T - 5 < m.x < (tx + 1) * T + 5 and ty * T - 2 < m.y < (ty + 1) * T + 6 + 6

    def select(self, i):
        if 0 <= i < 9:
            if i != self.sel:
                self.fishing = None
            self.sel = i

    def damage_player(self, n):
        if self.invuln > 0:
            return
        n = max(1, round(n * ARMOR_MULT.get(self.armor_key(), 1.0)))
        self.hp -= n
        self.invuln = 1.0
        self.red = 0.25
        self.hurt_t = 0.0
        self.snd.play("hurt")

    # ---------- crafting ----------
    def craft(self, ri):
        out, n, cost, needs_table = RECIPES[ri]
        if not self.can_pay(cost):
            self.hint("Not enough materials", 1.5)
            self.snd.play("click")
        elif not self.can_fit(out, n):
            self.hint("Inventory full!", 1.5)
        else:
            self.pay(cost)
            self.gain(out, n, quiet=True)
            self.snd.play("craft")
            self.hint(f"Crafted {item_name(out)} x{n}", 1.5)

    # ---------- furnace ----------
    def furnace_result(self, f):
        inp, out = f["s"][0], f["s"][2]
        if not inp or inp[0] not in SMELT:
            return None
        res = SMELT[inp[0]]
        if out is None or (out[0] == res and out[1] < ITEMS[res][2]):
            return res
        return None

    def update_furnaces(self, dt):
        for f in self.furnaces.values():
            res = self.furnace_result(f)
            fuel = f["s"][1]
            if f["burn"] <= 0 and res and fuel and fuel[0] in FUEL:
                f["burn"] = FUEL[fuel[0]]
                fuel[1] -= 1
                if fuel[1] <= 0:
                    f["s"][1] = None
            if f["burn"] > 0:
                f["burn"] -= dt
                if res:
                    f["prog"] += dt
                    if f["prog"] >= SMELT_TIME:
                        f["prog"] = 0.0
                        inp = f["s"][0]
                        inp[1] -= 1
                        if inp[1] <= 0:
                            f["s"][0] = None
                        if f["s"][2] is None:
                            f["s"][2] = [res, 1]
                        else:
                            f["s"][2][1] += 1
                else:
                    f["prog"] = 0.0
            else:
                f["prog"] = 0.0

    # ---------- inventory screen ----------
    def open_ui(self, kind, key=None):
        self.ui = kind
        self.ui_key = key
        self.fishing = None
        if kind == "craft":
            self.station = "table" if key == "table" else "hand"
            self.scroll = 0
        elif kind == "chest":
            self.chests.setdefault(key, [None] * 27)
        elif kind == "furnace":
            self.furnaces.setdefault(key, {"s": [None, None, None], "prog": 0.0, "burn": 0.0})
        self.snd.play("open")

    def send_container(self):
        """Client: push the chest / furnace you are editing to the host."""
        if not self.is_client or self.ui not in ("chest", "furnace"):
            return
        self.cont_lock = self.clock
        if self.ui == "chest":
            slots, kind = self.chests.get(self.ui_key), "c"
        else:
            f = self.furnaces.get(self.ui_key)
            slots, kind = (f["s"] if f else None), "f"
        if slots is not None:
            self.net.send({"t": "cs", "k": kind, "x": self.ui_key[0], "y": self.ui_key[1],
                           "d": slots})

    def close_ui(self):
        if self.cursor:
            left = self.add_item(self.cursor[0], self.cursor[1])
            if left:
                self.hint("Inventory full - items lost", 2)
            self.cursor = None
        self.send_container()
        self.ui = None
        self.snd.play("click")

    def slot_click_local(self, rule, slots, i):
        s, c = slots[i], self.cursor
        self.snd.play("click", 0.5)
        if c is None:
            if s:
                self.cursor = s
                slots[i] = None
            return
        if rule == "armor" and ITEMS[c[0]][3] != "armor":
            self.hint("Only armor fits here", 1.5)
            return
        if rule == "in" and c[0] not in SMELT:
            self.hint("That can't be smelted", 1.5)
            return
        if rule == "fuel" and c[0] not in FUEL:
            self.hint("Use coal or wood as fuel", 1.5)
            return
        if rule == "out":
            return
        mx = ITEMS[c[0]][2]
        if s is None:
            slots[i] = c
            self.cursor = None
        elif s[0] == c[0]:
            a = min(c[1], mx - s[1])
            s[1] += a
            c[1] -= a
            if c[1] <= 0:
                self.cursor = None
        else:
            slots[i] = c
            self.cursor = s

    def slot_click(self, rule, slots, i):
        self.slot_click_local(rule, slots, i)
        self.send_container()

    def ui_button(self, name):
        c = self.cursor
        if name in ("close", "resume"):
            self.close_ui()
        elif name == "sound":
            self.snd.toggle()
        elif name == "title":
            self.close_ui()
            self.save()
            self.request = "title"
        elif name == "quit":
            self.close_ui()
            self.save()
            self.request = "quit"
        elif name == "back":
            self.ui = "inv" if self.station == "hand" else None
            if self.ui is None:
                self.close_ui()
        elif name == "craft":
            self.open_ui("craft", "hand")
        elif name == "trash":
            self.cursor = None
        elif name == "eat" and c and ITEMS[c[0]][3] == "food":
            if self.try_eat(c[0]):
                c[1] -= 1
                if c[1] <= 0:
                    self.cursor = None
        elif name == "wear" and c and ITEMS[c[0]][3] == "armor":
            old = self.armor_slot[0]
            self.armor_slot[0] = [c[0], 1]
            self.cursor = old
            self.snd.play("craft")
        elif name == "up":
            self.scroll = max(0, self.scroll - 1)
        elif name == "down":
            self.scroll += 1

    def ui_press(self, x, y):
        for r, name, enabled in self.ui_btns:
            if r.collidepoint(x, y):
                if enabled:
                    self.ui_button(name)
                return
        for r, group, slots, i in self.ui_rects:
            if r.collidepoint(x, y):
                self.slot_click(group, slots, i)
                return
        for r, ri in self.craft_rows:
            if r.collidepoint(x, y):
                self.craft(ri)
                return
        if not PANEL.collidepoint(x, y):
            self.close_ui()

    # ---------- update ----------
    def update(self, dt, mx, my, a_held):
        self.clock += dt
        self.exit_armed = max(0.0, self.exit_armed - dt)
        self.hint_t = max(0.0, self.hint_t - dt)
        self.swing = max(0.0, self.swing - dt)
        self.act_cd = max(0.0, self.act_cd - dt)
        self.invuln = max(0.0, self.invuln - dt)
        self.red = max(0.0, self.red - dt)
        self.hurt_t += dt
        for f in self.fx:
            f[3] += dt
        if self.fx:
            self.fx = [f for f in self.fx if f[3] < 0.27]
        if self.floats:
            for f in self.floats:
                f[1] -= 22 * dt
                f[3] -= dt
            self.floats = [f for f in self.floats if f[3] > 0]
        if self.hits:
            for k in list(self.hits):
                self.hits[k][1] -= dt
                if self.hits[k][1] <= 0:
                    del self.hits[k]
        if self.furnaces and not self.is_client:
            self.update_furnaces(dt)
        if self.net:
            self.net_update(dt)
            if self.request:
                return

        if self.dead_t > 0:
            self.dead_t -= dt
            if self.dead_t <= 0:
                self.respawn()
            if self.net:
                self.world_step(dt)                    # a shared world never pauses
            return
        self.update_sleep(dt)
        if self.sleep_phase or self.ui:
            if self.net:
                self.world_step(dt)
                self.check_death()
            return

        p = self.p
        p.moving = False
        if mx or my:
            ln = math.hypot(mx, my)
            mx, my = mx / ln, my / ln
            self.move(p, mx * PLAYER_SPEED * dt, my * PLAYER_SPEED * dt)
            if abs(mx) > abs(my):
                p.dir = 1 if mx < 0 else 2
            else:
                p.dir = 0 if my > 0 else 3
            p.moving = True
            p.anim += dt
        if a_held and self.act_cd <= 0 and not self.fishing and self.held() != "rod":
            self.try_act()
        self.update_fishing(dt)
        self.world_step(dt)

        if self.hp < MAXHP and self.hurt_t > 5 and self.hunger >= 12:
            self.regen += dt
            if self.regen >= 3:
                self.regen = 0
                self.hp += 1
        if self.check_death():
            return
        self.save_t -= dt
        if self.save_t <= 0:
            self.save_t = 60.0
            self.save()

    def check_death(self):
        if self.hp <= 0 and self.dead_t <= 0:
            self.dead_t = 2.5
            self.snd.play("death")
            return True
        return False

    def world_step(self, dt):
        """Time, mobs, weather, crops. In multiplayer this keeps running while a menu is open."""
        p = self.p
        self.time += TIME_RATE * dt
        if self.time >= 24:
            self.time -= 24
            if not self.is_client:
                self.day += 1
        ty = clamp(int((p.y - 5) // T), 0, MAP - 1)
        tx = clamp(int(p.x // T), 0, MAP - 1)
        target = 1.0 if self.ground[ty][tx] == G_CAVE else 0.0
        self.cave_a += clamp(target - self.cave_a, -dt * 2, dt * 2)
        if self.net:
            self.update_remotes(dt)
        if self.is_client:
            self.update_proxy_mobs(dt)
        else:
            self.update_mobs(dt)
        self.update_survival(dt)
        if not self.is_client:
            self.update_regrow(dt)

    def update_regrow(self, dt):
        if not self.regrow:
            return
        for r in self.regrow[:]:
            r[3] -= dt
            if r[3] > 0:
                continue
            tx, ty, oid = r[0], r[1], r[2]
            ok_ground = (G_GRASS,) if oid == O_TREE else (G_GRASS, G_SAND, G_DIRT)
            if self.obj[ty][tx] == 0 and not self.floor[ty][tx] \
                    and self.ground[ty][tx] in ok_ground and not self.occupied(tx, ty):
                self.set_obj(tx, ty, oid)
                self.regrow.remove(r)
            else:
                r[3] = 15.0

    def update_survival(self, dt):
        if not self.is_client:
            self.weather_t -= dt
            if self.weather_t <= 0:
                self.raining = not self.raining
                self.weather_t = random.uniform(35, 70) if self.raining else random.uniform(70, 150)
                self.hint("It started to rain..." if self.raining else "The rain stopped", 3)
        target = 1.0 if self.raining else 0.0
        self.rain_a += clamp(target - self.rain_a, -dt * 0.5, dt * 0.5)
        self.snd.set_rain(self.rain_a * (1.0 - self.cave_a * 0.8))
        if self.rain_a > 0.02:
            for d in self.drops:
                d[1] += d[2] * dt
                d[0] -= 60 * dt
                if d[1] > H or d[0] < 0:
                    d[0] = random.uniform(0, W + 60)
                    d[1] = random.uniform(-30, 0)
        if self.crops:
            rate = 2.0 if self.raining else 1.0
            for k in list(self.crops):
                base, t = self.crops[k]
                t += dt * rate
                stage = 0 if t < STAGE_TIME else 1 if t < STAGE_TIME * 2 else 2
                if self.obj[k[1]][k[0]] != base + stage:
                    self.set_obj(k[0], k[1], base + stage)
                if stage == 2:
                    del self.crops[k]
                else:
                    self.crops[k][1] = t
        self.hunger = max(0.0, self.hunger - HUNGER_RATE * dt)
        if self.hunger <= 0:
            self.starve_t += dt
            if self.starve_t >= 4 and self.hp > 2:
                self.starve_t = 0.0
                self.hp -= 1
                self.hurt_t = 0.0
                self.red = 0.2
                self.hint("You are starving! Eat something", 2)
        else:
            self.starve_t = 0.0

    # ---------- mobs ----------
    def populate_animals(self):
        tries = 0
        n = sum(1 for m in self.mobs if not m.hostile)
        while n < 28 and tries < 600:
            tries += 1
            tx, ty = random.randrange(MAP), random.randrange(MAP)
            if (self.ground[ty][tx] == G_GRASS and self.obj[ty][tx] == 0
                    and math.hypot(tx * T - self.spawn[0], ty * T - self.spawn[1]) > 60):
                x, y = tx * T + 8, ty * T + 12
                if self.box_free(x, y, 1):
                    self.mobs.append(Mob(random.choice(ANIMALS), x, y))
                    n += 1

    def spawn_animal_near(self, pl=None):
        p = pl or self.p
        for _ in range(8):
            a = random.uniform(0, 6.283)
            d = random.uniform(230, 300)
            x, y = p.x + math.cos(a) * d, p.y + math.sin(a) * d
            tx, ty = int(x // T), int(y // T)
            if (0 < tx < MAP - 1 and 0 < ty < MAP - 1
                    and self.ground[ty][tx] == G_GRASS and self.box_free(x, y, 1)):
                self.mobs.append(Mob(random.choice(ANIMALS), x, y))
                return

    def in_cave(self, e):
        tx = clamp(int(e.x // T), 0, MAP - 1)
        ty = clamp(int((e.y - 5) // T), 0, MAP - 1)
        return self.ground[ty][tx] == G_CAVE

    def spawn_hostile(self, pl=None, k=1.0):
        counts = {"zombie": 0, "spider": 0, "ghost": 0}
        for m in self.mobs:
            if m.hostile:
                counts[m.kind] += 1
        caps = {"zombie": min(3 + self.day, 9), "spider": min(2 + self.day // 2, 5),
                "ghost": min(1 + self.day // 3, 3) if self.day >= 2 else 0}
        caps = {kk: int(v * k) for kk, v in caps.items()}
        r = random.random()
        kind = "ghost" if r < 0.15 else "spider" if r < 0.40 else "zombie"
        if counts[kind] >= caps[kind]:
            kind = "zombie"
            if counts[kind] >= caps[kind]:
                return
        p = pl or self.p
        for _ in range(8):
            a = random.uniform(0, 6.283)
            d = random.uniform(205, 255)
            x, y = p.x + math.cos(a) * d, p.y + math.sin(a) * d
            if 12 < x < MAP * T - 12 and 12 < y < MAP * T - 12 \
                    and (kind == "ghost" or self.box_free(x, y, 2)):
                self.mobs.append(Mob(kind, x, y))
                self.snd.play("zombie", 0.4)
                return

    def spawn_cave_mob(self, pl=None):
        p = pl or self.p
        for _ in range(10):
            a = random.uniform(0, 6.283)
            d = random.uniform(70, 160)
            x, y = p.x + math.cos(a) * d, p.y + math.sin(a) * d
            tx, ty = int(x // T), int(y // T)
            if (0 <= tx < MAP and 0 <= ty < MAP and self.ground[ty][tx] == G_CAVE
                    and self.obj[ty][tx] == 0 and self.box_free(x, y, 2)):
                self.mobs.append(Mob(random.choice(("zombie", "spider", "spider")), x, y))
                self.snd.play("zombie", 0.4)
                return

    def players_list(self):
        """[(entity, held item, id)] for every player the host looks after."""
        out = [(self.p, self.held(), 0)]
        for rp in self.remotes.values():
            out.append((rp, rp.held, rp.pid))
        return out

    def update_mobs(self, dt):
        nf = night_factor(self.time)
        players = self.players_list()
        k = 1.0 + 0.6 * (len(players) - 1)             # more players = more monsters
        surface = [e for e, _h, _i in players if not self.in_cave(e)]
        caves = [e for e, _h, _i in players if self.in_cave(e)]
        self.spawn_t -= dt
        if nf > 0.6 and surface and self.spawn_t <= 0:
            self.spawn_t = random.uniform(1.5, 3.5)
            self.spawn_hostile(random.choice(surface), k)
        self.cave_t -= dt
        if caves and self.cave_t <= 0:
            self.cave_t = random.uniform(3, 6)
            if sum(1 for m in self.mobs if m.hostile) < 5 * k:
                self.spawn_cave_mob(random.choice(caves))
        self.animal_t -= dt
        if self.animal_t <= 0:
            self.animal_t = 3.0
            if sum(1 for m in self.mobs if not m.hostile) < 24:
                self.spawn_animal_near(random.choice(players)[0])

        srcs = None
        alive = []
        newborns = []
        for m in self.mobs:
            m.moving = False
            m.flash = max(0.0, m.flash - dt)
            d, ent, held, pid = None, None, None, 0
            for e, h, i in players:                        # the nearest player is the target
                dd = math.hypot(e.x - m.x, e.y - m.y)
                if d is None or dd < d:
                    d, ent, held, pid = dd, e, h, i
            dx, dy = ent.x - m.x, ent.y - m.y
            if not m.hostile:
                m.breed_cd = max(0.0, m.breed_cd - dt)
                if m.baby:
                    m.age += dt
                    if m.age >= BABY_TIME:
                        m.baby = False
                        m.hp = MOBS[m.kind]["hp"]
                partner = None
                if m.love > 0:
                    m.love -= dt
                    partner = self.find_partner(m)
                    self.try_breed(m, newborns)
                if d < 360:                                  # far animals sleep
                    if abs(m.kx) > 3 or abs(m.ky) > 3:
                        self.move_mob(m, m.kx * dt, m.ky * dt)
                        f = max(0.0, 1 - dt * 7)
                        m.kx *= f
                        m.ky *= f
                    else:
                        m.kx = m.ky = 0.0
                        self.ai_animal(m, dt, d, dx, dy, held, partner)
                alive.append(m)
                continue
            if d > 320:
                continue
            m.hit_cd -= dt
            mtx = clamp(int(m.x // T), 0, MAP - 1)
            mty = clamp(int(m.y // T), 0, MAP - 1)
            if nf < 0.3 and self.ground[mty][mtx] != G_CAVE:    # sunlight burns them
                m.burn -= dt
                if m.burn <= 0:
                    self.fx.append([m.x, m.y - 8, 1, 0.0])
                    continue
            if abs(m.kx) > 3 or abs(m.ky) > 3:
                self.move_mob(m, m.kx * dt, m.ky * dt)
                f = max(0.0, 1 - dt * 7)
                m.kx *= f
                m.ky *= f
            else:
                m.kx = m.ky = 0.0
                if m.kind == "ghost" and srcs is None:
                    srcs = [(tx * T + 8, ty * T + 8, LIGHT[o][0])
                            for (tx, ty), o in self.light_objs.items()]
                    srcs += [(tx * T + 8, ty * T + 8, FURNACE_LIGHT[0])
                             for (tx, ty), f in self.furnaces.items() if f["burn"] > 0]
                self.ai_hostile(m, dt, d, dx, dy, srcs)
            if m.hit_cd <= 0 and abs(dx) < 9 and abs(dy) < 8:
                if pid == 0:
                    self.damage_player(m.dmg)
                else:
                    self.net.send(pid, {"t": "dmg", "n": m.dmg})
                m.hit_cd = 1.0
            alive.append(m)
        self.mobs = alive + newborns

    def face(self, m, vx, vy):
        if abs(vx) > abs(vy):
            m.dir = 1 if vx < 0 else 2
        else:
            m.dir = 0 if vy > 0 else 3

    def ai_animal(self, m, dt, d, dx, dy, held=None, partner=None):
        sp = m.speed
        if m.flee > 0:
            m.flee -= dt
            vx, vy = -dx / max(d, 1), -dy / max(d, 1)
            sp *= 2.2
        elif partner is not None:                      # walk to the other loving animal
            px, py = partner.x - m.x, partner.y - m.y
            pd = math.hypot(px, py)
            vx, vy = (px / pd, py / pd) if pd > 12 else (0.0, 0.0)
            sp *= 1.3
        elif held in ANIMAL_FOOD[m.kind] and d < 110:  # follow the food in your hand
            vx, vy = (dx / d, dy / d) if d > 20 else (0.0, 0.0)
            sp *= 1.2
        else:
            m.idle -= dt
            if m.idle <= 0:
                m.idle = random.uniform(1, 3)
                if random.random() < 0.5:
                    m.wx = m.wy = 0.0
                else:
                    a = random.uniform(0, 6.283)
                    m.wx, m.wy = math.cos(a), math.sin(a)
            vx, vy = m.wx, m.wy
        if vx or vy:
            ox, oy = m.x, m.y
            self.move_mob(m, vx * sp * dt, vy * sp * dt)
            if abs(m.x - ox) + abs(m.y - oy) > 0.01:
                m.moving = True
                m.anim += dt
                self.face(m, vx, vy)
            elif m.flee <= 0:
                m.wx = m.wy = 0.0

    def ai_hostile(self, m, dt, d, dx, dy, srcs):
        sp = m.speed * (1 + min(self.day, 12) * 0.03)
        vx, vy = dx / max(d, 1), dy / max(d, 1)
        if m.kind == "ghost":
            for lx, ly, r in srcs:                           # scared of light
                ddx, ddy = m.x - lx, m.y - ly
                dd = math.hypot(ddx, ddy)
                if dd < r:
                    vx, vy = ddx / max(dd, 1), ddy / max(dd, 1)
                    sp *= 1.4
                    break
            self.move_mob(m, vx * sp * dt, vy * sp * dt)
            m.moving = True
            m.anim += dt
            m.dir = 1 if vx < 0 else 2
            return
        if m.kind == "spider":                               # leaps at you
            m.leap_cd -= dt
            if m.leap > 0:
                m.leap -= dt
                sp *= 2.4
            elif m.leap_cd <= 0 and d < 90:
                m.leap = 0.25
                m.leap_cd = random.uniform(2.0, 3.5)
        if m.wander > 0:
            m.wander -= dt
            vx, vy = m.wx, m.wy
        ox, oy = m.x, m.y
        self.move_mob(m, vx * sp * dt, vy * sp * dt)
        moved = abs(m.x - ox) + abs(m.y - oy)
        if moved < sp * dt * 0.35:
            m.stuck += dt
            if m.stuck > 0.8:
                m.stuck = 0.0
                a = random.uniform(0, 6.283)
                m.wx, m.wy = math.cos(a), math.sin(a)
                m.wander = random.uniform(0.6, 1.4)
        else:
            m.stuck = 0.0
        m.moving = moved > 0.01
        self.face(m, vx, vy)
        m.anim += dt

    # ---------- multiplayer ----------
    def net_edit(self, k, tx, ty, v):
        """A block changed here: tell everybody else."""
        if not self.net or self._remote:
            return
        msg = {"t": "e", "k": k, "x": tx, "y": ty, "v": v}
        if self.is_client:
            self.net.send(msg)
        else:
            self.net.broadcast(msg)

    def apply_edit(self, m):
        """Apply a block change that came from the network. Returns the clean message or None."""
        try:
            k, tx, ty, v = m["k"], int(m["x"]), int(m["y"]), int(m["v"])
        except (KeyError, TypeError, ValueError):
            return None
        if k not in ("o", "f", "g") or not self.in_map(tx, ty):
            return None
        if (k == "o" and v != 0 and v not in OBJ_TILE) or (k == "f" and v != 0 and v not in FLOOR_TILE) \
                or (k == "g" and not 0 <= v <= 9):
            return None
        self._remote = True
        try:
            if k == "o":
                self.set_obj(tx, ty, v)
                if self.is_host:                             # keep the host's tables in step
                    if v == 0:
                        self.crops.pop((tx, ty), None)
                        self.chests.pop((tx, ty), None)
                        self.furnaces.pop((tx, ty), None)
                    elif v == O_CHEST:
                        self.chests.setdefault((tx, ty), [None] * 27)
                    elif v == O_FURNACE:
                        self.furnaces.setdefault((tx, ty), {"s": [None, None, None],
                                                            "prog": 0.0, "burn": 0.0})
            elif k == "f":
                self.set_floor(tx, ty, v)
            else:
                self.set_ground(tx, ty, v)
        finally:
            self._remote = False
        return {"t": "e", "k": k, "x": tx, "y": ty, "v": v}

    def find_mob(self, mid):
        for m in self.mobs:
            if m.id == mid:
                return m
        return None

    def update_remotes(self, dt):
        """Smooth the other players' movement."""
        k = min(1.0, dt * 14)
        for rp in self.remotes.values():
            if abs(rp.tx - rp.x) > 48 or abs(rp.ty - rp.y) > 48:
                rp.x, rp.y = rp.tx, rp.ty
            else:
                rp.x += (rp.tx - rp.x) * k
                rp.y += (rp.ty - rp.y) * k
            rp.swing = max(0.0, rp.swing - dt)
            if rp.moving:
                rp.anim += dt

    def update_proxy_mobs(self, dt):
        """Client: mobs are copies of what the host sends - just animate and smooth them."""
        k = min(1.0, dt * 14)
        for m in self.mobs:
            if abs(m.tx - m.x) > 48 or abs(m.ty - m.y) > 48:
                m.x, m.y = m.tx, m.ty
            else:
                m.x += (m.tx - m.x) * k
                m.y += (m.ty - m.y) * k
            m.flash = max(0.0, m.flash - dt)
            if m.moving:
                m.anim += dt

    def net_update(self, dt):
        net = self.net
        if self.is_client:
            net.pump()
            for m in net.take():
                self.client_msg(m)
            if net.dead or net.state == "failed":
                self.exit_msg = net.err or "Lost connection to the host"
                self.request = "title"
                return
            self.net_send_t -= dt
            if self.net_send_t <= 0:
                self.net_send_t = 0.05
                p = self.p
                net.send({"t": "ps", "x": round(p.x, 1), "y": round(p.y, 1), "d": p.dir,
                          "mv": 1 if p.moving else 0, "ar": self.armor_key(), "h": self.held(),
                          "sw": 1 if self.swing > 0 else 0})
            return
        # ---------------- host ----------------
        for _ in range(netlib.MAX_CLIENTS):
            cid = net.accept()
            if cid is None:
                break
            self.pending[cid] = self.clock
        for cid, m in net.poll():
            self.host_msg(cid, m)
        for cid in net.dropped:
            rp = self.remotes.pop(cid, None)
            self.pending.pop(cid, None)
            if rp:
                self.hint(f"{rp.name} left the game", 3)
                net.broadcast({"t": "msg", "s": f"{rp.name} left the game"})
        net.dropped.clear()
        for cid, t0 in list(self.pending.items()):           # never said hello
            if self.clock - t0 > 8 and cid in net.conns:
                net.conns[cid].dead = True
                del self.pending[cid]
        net.beacon(dt, 1 + len(self.remotes))
        self.net_snap_t -= dt
        if self.net_snap_t <= 0 and self.remotes:
            self.net_snap_t = 0.066
            for cid, rp in self.remotes.items():
                if net.backlog(cid) < 150000:
                    net.send(cid, self.build_snap(cid, rp))
        self.net_cont_t -= dt
        if self.net_cont_t <= 0:
            self.net_cont_t = 0.6
            if self.remotes:
                msg = self.container_msg()
                txt = json.dumps(msg, separators=(",", ":"))
                if txt != self.last_cont:
                    self.last_cont = txt
                    net.broadcast(msg)

    def container_msg(self):
        return {"t": "cn",
                "c": [[x, y, v] for (x, y), v in self.chests.items()],
                "f": [[x, y, f["s"], round(f["prog"], 1), round(f["burn"], 1)]
                      for (x, y), f in self.furnaces.items()]}

    def build_snap(self, cid, rp):
        p = self.p
        pl = [[0, self.my_name, round(p.x, 1), round(p.y, 1), p.dir, 1 if p.moving else 0,
               self.armor_key(), self.held(), 1 if self.swing > 0 else 0]]
        for oid, o in self.remotes.items():
            if oid != cid:
                pl.append([oid, o.name, round(o.x, 1), round(o.y, 1), o.dir,
                           1 if o.moving else 0, o.armor, o.held, 1 if o.swing > 0 else 0])
        mb = []
        for m in self.mobs:
            if abs(m.x - rp.x) < 300 and abs(m.y - rp.y) < 260:
                fl = ((1 if m.baby else 0) | (2 if m.love > 0 else 0)
                      | (4 if m.breed_cd > 0 else 0) | (8 if m.flash > 0 else 0))
                mb.append([m.id, m.kind, round(m.x, 1), round(m.y, 1), m.dir,
                           1 if m.moving else 0, fl])
        return {"t": "s", "tm": round(self.time, 3), "dy": self.day,
                "rn": 1 if self.raining else 0, "pl": pl, "mb": mb}

    def welcome_msg(self, cid, name):
        return {"t": "welcome", "v": netlib.VERSION, "id": cid, "name": name,
                "seed": self.seed, "pos": [round(self.p.x, 1), round(self.p.y, 1)],
                "world": {"obj": enc(self.obj), "floor": enc(self.floor),
                          "ground": enc(self.ground), "time": self.time, "day": self.day,
                          "rain": 1 if self.raining else 0,
                          "chests": [[x, y, v] for (x, y), v in self.chests.items()],
                          "furnaces": [[x, y, f["s"], f["prog"], f["burn"]]
                                       for (x, y), f in self.furnaces.items()]}}

    def host_msg(self, cid, m):
        net = self.net
        t = m.get("t")
        if t == "hello":
            if cid in self.remotes:
                return
            self.pending.pop(cid, None)
            if m.get("v") != netlib.VERSION:
                net.send(cid, {"t": "kick"})
                if cid in net.conns:
                    net.conns[cid].dead = True
                return
            name = f"Player {cid + 1}"
            self.remotes[cid] = RPlayer(cid, name, self.p.x + 10, self.p.y)
            net.send(cid, self.welcome_msg(cid, name))
            net.broadcast({"t": "msg", "s": f"{name} joined the game"}, exclude=cid)
            self.hint(f"{name} joined the game", 3)
            self.snd.play("pickup", 0.6)
            return
        rp = self.remotes.get(cid)
        if rp is None:
            return
        try:
            if t == "ps":
                rp.tx, rp.ty = clamp(float(m["x"]), 0, MAP * T), clamp(float(m["y"]), 0, MAP * T)
                rp.dir = int(m["d"]) if m["d"] in (0, 1, 2, 3) else 0
                rp.moving = bool(m["mv"])
                rp.armor = m["ar"] if m["ar"] in self.chars else None
                rp.held = m["h"] if m["h"] in ITEMS else None
                if m["sw"] and rp.swing <= 0:
                    rp.swing = 0.2
            elif t == "e":
                clean = self.apply_edit(m)
                if clean:
                    net.broadcast(clean, exclude=cid)
            elif t == "crop":
                tx, ty, base = int(m["x"]), int(m["y"]), int(m["b"])
                if self.in_map(tx, ty) and base in CROP_INFO:
                    self.crops[(tx, ty)] = [base, 0.0]
            elif t == "rg":
                tx, ty, oid = int(m["x"]), int(m["y"]), int(m["o"])
                if self.in_map(tx, ty) and oid in (O_TREE, O_ROCK) and len(self.regrow) < 400:
                    self.regrow.append([tx, ty, oid, clamp(float(m["s"]), 5.0, 900.0)])
            elif t == "hit":
                mob = self.find_mob(int(m["id"]))
                if mob and math.hypot(mob.x - rp.x, mob.y - rp.y) < 60:
                    dmg = int(clamp(int(m["dmg"]), 1, 12))
                    dx, dy = clamp(float(m["dx"]), -1, 1), clamp(float(m["dy"]), -1, 1)
                    self.hit_mob(mob, dmg, dx, dy, clamp(float(m["kb"]), 0, 200), cid)
            elif t == "feed":
                mob = self.find_mob(int(m["id"]))
                if mob and not mob.hostile:
                    self.remote_feed(mob)
            elif t == "cs":
                key = (int(m["x"]), int(m["y"]))
                if m["k"] == "c" and key in self.chests:
                    self.chests[key][:] = clean_slots(m["d"], 27)
                elif m["k"] == "f" and key in self.furnaces:
                    self.furnaces[key]["s"][:] = clean_slots(m["d"], 3)
            elif t == "sleep":
                self.skip_night()
                self.hint(f"{rp.name} slept - it is morning", 3)
                net.broadcast({"t": "msg", "s": f"{rp.name} slept - it is morning"})
            elif t == "bye":
                if cid in net.conns:
                    net.conns[cid].dead = True
        except (KeyError, TypeError, ValueError):
            pass

    def client_msg(self, m):
        t = m.get("t")
        try:
            if t == "s":
                self.apply_snap(m)
            elif t == "e":
                self.apply_edit(m)
            elif t == "cn":
                self.apply_containers(m)
            elif t == "dmg":
                self.damage_player(int(clamp(int(m["n"]), 1, 10)))
            elif t == "loot":
                for item, n in m["i"]:
                    if item in ITEMS and int(n) > 0:
                        self.gain(item, min(int(n), 20))
            elif t == "msg":
                self.hint(str(m.get("s", ""))[:40], 3)
            elif t == "kick":
                self.exit_msg = "The host closed the game"
                self.request = "title"
        except (KeyError, TypeError, ValueError):
            pass

    def apply_snap(self, s):
        self.time, self.day = float(s["tm"]), int(s["dy"])
        rain = bool(s["rn"])
        if rain != self.raining:
            self.raining = rain
            self.hint("It started to rain..." if rain else "The rain stopped", 3)
        seen = set()
        for pid, name, x, y, d, mv, ar, h, sw in s["pl"]:
            if pid == self.my_id:
                continue
            rp = self.remotes.get(pid)
            if rp is None:
                rp = self.remotes[pid] = RPlayer(pid, str(name)[:12], x, y)
            rp.tx, rp.ty = float(x), float(y)
            rp.dir = d if d in (0, 1, 2, 3) else 0
            rp.moving = bool(mv)
            rp.armor = ar if ar in self.chars else None
            rp.held = h if h in ITEMS else None
            if sw and rp.swing <= 0:
                rp.swing = 0.2
            seen.add(pid)
        for pid in [i for i in self.remotes if i not in seen]:
            del self.remotes[pid]
        alive = {}
        for mid, kind, x, y, d, mv, fl in s["mb"]:
            m = self.mob_ids.get(mid)
            if m is None:
                if kind not in MOBS:
                    continue
                m = Mob(kind, x, y)
                m.id = mid
            m.tx, m.ty = float(x), float(y)
            m.dir = d if d in (0, 1, 2, 3) else 0
            m.moving = bool(mv)
            m.baby = bool(fl & 1)
            m.love = 1.0 if fl & 2 else 0.0
            m.breed_cd = 1.0 if fl & 4 else 0.0
            if fl & 8:
                m.flash = max(m.flash, 0.12)
            alive[mid] = m
        self.mob_ids = alive
        self.mobs = list(alive.values())

    def apply_containers(self, m):
        locked = self.clock - self.cont_lock < 1.2               # you are editing right now
        for x, y, sl in m.get("c", []):
            key = (int(x), int(y))
            if locked and self.ui == "chest" and self.ui_key == key:
                continue
            new = clean_slots(sl, 27)
            if key in self.chests:
                self.chests[key][:] = new
            else:
                self.chests[key] = new
        for x, y, sl, prog, burn in m.get("f", []):
            key = (int(x), int(y))
            f = self.furnaces.get(key)
            if f is None:
                f = self.furnaces[key] = {"s": [None, None, None], "prog": 0.0, "burn": 0.0}
            f["prog"], f["burn"] = float(prog), float(burn)
            if not (locked and self.ui == "furnace" and self.ui_key == key):
                f["s"][:] = clean_slots(sl, 3)

    def close_net(self):
        if self.net:
            self.net.close()
            self.net = None

    # ---------- sleep / death ----------
    def update_sleep(self, dt):
        if self.sleep_phase == "out":
            self.sleep_fade = min(1.0, self.sleep_fade + dt * 0.9)
            if self.sleep_fade >= 1.0:
                if self.is_client:
                    self.net.send({"t": "sleep"})              # the host skips the night
                else:
                    self.skip_night()
                self.hp = MAXHP
                self.save()
                self.sleep_phase = "hold"
                self.sleep_hold = 0.0
        elif self.sleep_phase == "hold":
            self.sleep_hold += dt
            if self.sleep_hold > 1.4:
                self.sleep_phase = "in"
        elif self.sleep_phase == "in":
            self.sleep_fade = max(0.0, self.sleep_fade - dt * 0.9)
            if self.sleep_fade <= 0:
                self.sleep_phase = None

    def skip_night(self):
        if self.time >= 19:
            self.day += 1
        self.time = 6.0
        self.mobs = [m for m in self.mobs if not m.hostile]

    def respawn(self):
        self.p.x, self.p.y = self.spawn
        self.hp = MAXHP
        self.hunger = float(MAXFOOD)
        for s in self.inv:                       # lose half of every stack
            if s and s[1] > 1:
                s[1] = max(1, s[1] // 2)
        self.cursor = None
        self.ui = None
        self.fishing = None
        if not self.net:                         # in a shared world the time keeps going
            self.skip_night()
        self.invuln = 2.0
        self.hint("You died... lost half of your items", 4)

    # ---------- input from touch ----------
    def on_press(self, x, y):
        """Single tap. Returns True if the game should quit."""
        if MENU_RECT.collidepoint(x, y):
            was = self.ui
            if was:
                self.close_ui()
            if was != "menu" and self.dead_t <= 0 and not self.sleep_phase:
                self.open_ui("menu")
            return False
        if SND_RECT.collidepoint(x, y):
            self.snd.toggle()
            self.hint("Sound on" if self.snd.on else "Sound off", 1.2)
            return False
        if self.dead_t > 0 or self.sleep_phase:
            return False
        if self.ui:
            self.ui_press(x, y)
            return False
        if BAG_RECT.collidepoint(x, y):
            self.open_ui("inv")
        elif math.hypot(x - A_C[0], y - A_C[1]) <= A_R + 5:
            self.try_act()
        elif math.hypot(x - B_C[0], y - B_C[1]) <= B_R + 6:
            self.use_held()
        else:
            for i in range(9):
                if pygame.Rect(HOT_X + i * HSLOT, HOT_Y, HSLOT - 2, HSLOT - 2).collidepoint(x, y):
                    self.select(i)
        return False

    # ---------- drawing: world ----------
    def draw_mob(self, m, camx, camy):
        sx, sy = int(m.x - camx), int(m.y - camy)
        k = m.kind
        fr = int(m.anim * 6) % 2 if m.moving else 0
        ox, oy, hover = 8, 15, 0
        if k in ANIMALS:
            d = self.animal_img[k]
            img = d["L"][fr] if m.dir == 1 else d["R"][fr] if m.dir == 2 else d["F"][fr]
        elif k == "spider":
            img = self.spider[int(m.anim * 10) % 2 if m.moving else 0]
        elif k == "ghost":
            img = (self.ghostL if m.dir == 1 else self.ghostR)[int(self.clock * 3) % 2]
            hover = int(7 + 2 * math.sin(self.clock * 3 + m.x))
        else:
            img = self.chars["zombie"][m.dir][[1, 0, 2, 0][int(m.anim * 7) % 4] if m.moving else 0]
            oy = 19
        if k in ANIMALS and m.baby:
            key = (k, m.dir if m.dir in (1, 2) else 0, fr)
            small = self.baby_cache.get(key)
            if small is None:
                small = pygame.transform.scale(img, (10, 10))
                self.baby_cache[key] = small
            img, ox, oy = small, 5, 9
        if m.flash > 0:
            img = img.copy()
            img.fill((110, 110, 110), special_flags=pygame.BLEND_RGB_ADD)
        self.cv.blit(self.shadow, (sx - 7, sy - 4))
        self.cv.blit(img, (sx - ox, sy - oy - hover))
        if m.love > 0:
            self.cv.blit(self.heart["full"], (sx - 5, sy - oy - 13))

    def draw_char(self, e, armor, held, swing, camx, camy, name=None, blink=False):
        if blink:
            return
        fr = [1, 0, 2, 0][int(e.anim * 7) % 4] if e.moving else 0
        sheet = self.chars.get(armor or "player") or self.chars["player"]
        sx, sy = int(e.x - camx), int(e.y - camy)
        tool = held in HAND_ITEMS
        if tool and e.dir == 3:                       # facing up: the tool is behind you
            self.draw_hand_item(held, sx, sy, e, swing)
        self.cv.blit(self.shadow, (sx - 7, sy - 4))
        self.cv.blit(sheet[e.dir][fr], (sx - 8, sy - 19))
        if tool and e.dir != 3:
            self.draw_hand_item(held, sx, sy, e, swing)
        if name:
            self.text(name, sx, sy - 29, (190, 235, 255), font=self.tiny, center=True)

    def draw_player(self, camx, camy):
        blink = self.invuln > 0 and int(self.invuln * 12) % 2 == 0
        self.draw_char(self.p, self.armor_key(), self.held(), self.swing, camx, camy,
                       None, blink)

    def draw_hand_item(self, item, sx, sy, p=None, swing=None):
        p = p or self.p
        swing = self.swing if swing is None else swing
        if item not in self.item_icon:
            return
        base = self.hand_cache.get(item)
        if base is None:
            img = pygame.transform.scale(self.item_icon[item], (12, 12))
            base = (img, pygame.transform.flip(img, True, False))
            self.hand_cache[item] = base
        img = base[1] if p.dir == 1 else base[0]
        cx, cy = {0: (sx + 7, sy - 7), 1: (sx - 8, sy - 11),
                  2: (sx + 8, sy - 11), 3: (sx - 7, sy - 10)}[p.dir]
        if swing > 0:
            t = 1 - swing / 0.2
            ang = lerp(55, -65, t)
            if p.dir == 1:
                ang = -ang
            img = pygame.transform.rotate(img, ang)
            dx, dy = DV[p.dir]
            reach = math.sin(math.pi * t) * 5
            cx += dx * reach
            cy += dy * reach
        elif p.moving:
            cy += int(math.sin(p.anim * 14) * 1.2)
        self.cv.blit(img, (int(cx - img.get_width() / 2), int(cy - img.get_height() / 2)))

    def draw(self, pts):
        cv, p = self.cv, self.p
        camx = int(clamp(p.x - W / 2, 0, MAP * T - W))
        camy = int(clamp(p.y - 12 - H / 2, 0, MAP * T - H))
        wf = int(self.clock * 1.6) % 2
        cv.blit(self.layers[wf], (0, 0), (camx, camy, W, H))     # ONE blit for the ground

        x0, x1 = camx // T, min(MAP - 1, (camx + W) // T)
        y0, y1 = camy // T, min(MAP - 1, (camy + H) // T)
        items = []
        for ty in range(y0, y1 + 1):
            row = self.obj_rows[ty]
            if row:
                for tx, o in row.items():
                    if x0 <= tx <= x1:
                        items.append(((ty + 1) * T, 0, tx, ty, o))
        items.append((p.y, 1, p, None))
        for rp in self.remotes.values():
            if camx - 20 < rp.x < camx + W + 20 and camy - 30 < rp.y < camy + H + 30:
                items.append((rp.y, 1, rp, None))
        for m in self.mobs:
            if camx - 20 < m.x < camx + W + 20 and camy - 30 < m.y < camy + H + 30:
                items.append((m.y, 1, m, None))
        items.sort(key=lambda it: (it[0], it[1]))
        anim4 = int(self.clock * 8) % 4
        for it in items:
            if it[1] == 0:
                _, _, tx, ty, o = it
                idx = OBJ_TILE[o]
                if o == O_FIRE:
                    idx = 16 + anim4
                elif o == O_TORCH:
                    idx = 22 + anim4
                elif o == O_FENCE:
                    idx = 49 + self.fence_mask(tx, ty)
                elif o == O_GATE or o == O_GATE_OPEN:
                    idx = (65 if o == O_GATE else 66) + (2 if self.gate_vertical(tx, ty) else 0)
                elif o == O_FURNACE:
                    f = self.furnaces.get((tx, ty))
                    if f and f["burn"] > 0:
                        idx = 43 + (anim4 & 1)
                cv.blit(self.tiles[idx], (tx * T - camx, ty * T - camy))
            elif it[2] is p:
                self.draw_player(camx, camy)
            elif isinstance(it[2], RPlayer):
                rp = it[2]
                self.draw_char(rp, rp.armor, rp.held, rp.swing, camx, camy, rp.name)
            else:
                self.draw_mob(it[2], camx, camy)

        if self.fishing:
            self.draw_fishing(camx, camy)
        elif self.swing > 0 and self.held() not in HAND_ITEMS:
            dx, dy = DV[p.dir]
            r = 4 + int((0.2 - self.swing) * 30)
            pygame.draw.circle(cv, (255, 255, 255),
                               (int(p.x + dx * 12 - camx), int(p.y - 7 + dy * 12 - camy)), r, 1)
        for f in self.fx:
            idx = (0 if f[2] == 0 else 3) + min(2, int(f[3] / 0.09))
            cv.blit(self.fxf[idx], (int(f[0] - 8 - camx), int(f[1] - 8 - camy)))

        for f in self.floats:
            self.text(f[2], f[0] - camx, f[1] - camy, f[4], center=True)
        self.draw_lighting(camx, camy)
        self.draw_rain()
        self.draw_hud(pts, anim4)
        if self.ui:
            self.draw_ui()

        if self.red > 0:
            self.redsurf.set_alpha(int(110 * self.red / 0.25))
            cv.blit(self.redsurf, (0, 0))
        fade = self.sleep_fade
        if self.dead_t > 0:
            fade = max(fade, min(1.0, (2.5 - self.dead_t) * 1.5))
        if fade > 0.01:
            self.fade.set_alpha(int(255 * fade))
            cv.blit(self.fade, (0, 0))
            if self.sleep_phase == "hold":
                self.text(f"Day {self.day}", W // 2, H // 2 - 14, font=self.big, center=True)
            if self.dead_t > 0:
                self.text("You died", W // 2, H // 2 - 14, (255, 120, 120),
                          font=self.big, center=True)

    def draw_fishing(self, camx, camy):
        f, p = self.fishing, self.p
        bx = f["tx"] * T + 8 - camx
        by = f["ty"] * T + 8 - camy
        if f["phase"] == "bite":
            by += 2 + int(math.sin(self.clock * 40) * 1.5)
        hx, hy = int(p.x - camx), int(p.y - 12 - camy)
        pygame.draw.line(self.cv, (240, 240, 250), (hx, hy), (int(bx), int(by) - 2), 1)
        pygame.draw.circle(self.cv, (230, 60, 70), (int(bx), int(by)), 2)
        pygame.draw.circle(self.cv, (255, 255, 255), (int(bx), int(by) - 1), 1)
        ring = int(self.clock * 6) % 3 + 3
        pygame.draw.circle(self.cv, (200, 225, 250), (int(bx), int(by) + 1), ring, 1)
        if f["phase"] == "bite":
            self.text("!", bx, by - 18, (255, 240, 120), font=self.big, center=True)

    def draw_lighting(self, camx, camy):
        amb = max(night_factor(self.time), self.cave_a)
        if amb < 0.01:
            return
        k = min(1.0, amb * 1.6)
        col = (int(lerp(120, 8, k)), int(lerp(60, 12, k)), int(lerp(25, 38, k)))
        self.dark.fill(col + (int(215 * amb ** 0.8),))
        flick = int(self.clock * 8) % 2
        rr = 48 if flick else 44
        px, py = int(self.p.x - camx), int(self.p.y - 10 - camy)
        self.dark.blit(self.lights[rr], (px - rr, py - rr), special_flags=pygame.BLEND_RGBA_SUB)
        for rp in self.remotes.values():                 # friends carry a light too
            sx, sy = int(rp.x - camx), int(rp.y - 10 - camy)
            if -60 < sx < W + 60 and -60 < sy < H + 60:
                self.dark.blit(self.lights[rr], (sx - rr, sy - rr),
                               special_flags=pygame.BLEND_RGBA_SUB)
        for (tx, ty), o in self.light_objs.items():
            sx, sy = tx * T + 8 - camx, ty * T + 8 - camy
            if -90 < sx < W + 90 and -90 < sy < H + 90:
                r = LIGHT[o][1][flick]
                self.dark.blit(self.lights[r], (int(sx) - r, int(sy) - r),
                               special_flags=pygame.BLEND_RGBA_SUB)
        for (tx, ty), f in self.furnaces.items():
            if f["burn"] > 0:
                sx, sy = tx * T + 8 - camx, ty * T + 8 - camy
                if -90 < sx < W + 90 and -90 < sy < H + 90:
                    r = FURNACE_LIGHT[1][flick]
                    self.dark.blit(self.lights[r], (int(sx) - r, int(sy) - r),
                                   special_flags=pygame.BLEND_RGBA_SUB)
        self.cv.blit(self.dark, (0, 0))

    def draw_rain(self):
        if self.rain_a <= 0.02 or self.cave_a > 0.9:
            return
        self.rain_surf.set_alpha(int(70 * self.rain_a))
        self.cv.blit(self.rain_surf, (0, 0))
        for x, y, _ in self.drops:
            pygame.draw.line(self.cv, (170, 196, 236), (int(x), int(y)), (int(x) - 3, int(y) + 8), 1)

    # ---------- drawing: HUD ----------
    def draw_hud(self, pts, anim4):
        cv = self.cv
        for i in range(MAXHP // 2):
            v = self.hp - 2 * i
            cv.blit(self.heart["full" if v >= 2 else "half" if v == 1 else "empty"],
                    (4 + i * 11, 4))
        for i in range(MAXFOOD // 2):
            v = self.hunger - 2 * i
            cv.blit(self.hunger_icon["full" if v >= 2 else "half" if v >= 1 else "empty"],
                    (1 + i * 11, 12))
        ak = self.armor_key()
        if ak:
            cv.blit(self.item_icon[ak], (118, 4))
        if self.net:
            self.text(f"Players: {1 + len(self.remotes)}", 4, 25, (150, 230, 160),
                      font=self.tiny)

        # top-right buttons: sound, menu
        for rect, icon in ((SND_RECT, self.icons[35 if self.snd.on else 36]), (MENU_RECT, None)):
            pygame.draw.rect(cv, (30, 34, 46), rect, border_radius=4)
            pygame.draw.rect(cv, (210, 220, 235), rect, 1, border_radius=4)
            if icon:
                cv.blit(icon, (rect.x + 2, rect.y))
            else:
                for yy in (3, 7, 11):
                    pygame.draw.line(cv, (236, 240, 248), (rect.x + 4, rect.y + yy),
                                     (rect.right - 5, rect.y + yy), 2)
        hh = int(self.time) % 24
        mm = int((self.time - int(self.time)) * 60) // 10 * 10
        self.text(f"Day {self.day}  {hh:02d}:{mm:02d}", W - 4, 24, right=True)
        if self.cave_a > 0.5:
            self.text("Cave", W - 4, 36, (190, 190, 210), right=True)
        elif self.rain_a > 0.3:
            self.text("Rain", W - 4, 36, (170, 200, 240), right=True)
        if SHOW_FPS:
            self.text(f"{int(self.fps)} fps", W // 2, 2, (200, 210, 200), center=True)

        # arrow buttons
        for name, r in DPAD.items():
            big = r.inflate(10, 10)
            down = any(big.collidepoint(q) for q in pts)
            pygame.draw.rect(cv, (214, 222, 238) if down else (44, 50, 66), r, border_radius=6)
            pygame.draw.rect(cv, (220, 226, 238), r, 2, border_radius=6)
            cx, cy = r.center
            tri = {"up": [(cx, cy - 7), (cx - 7, cy + 5), (cx + 7, cy + 5)],
                   "down": [(cx, cy + 7), (cx - 7, cy - 5), (cx + 7, cy - 5)],
                   "left": [(cx - 7, cy), (cx + 5, cy - 7), (cx + 5, cy + 7)],
                   "right": [(cx + 7, cy), (cx - 5, cy - 7), (cx - 5, cy + 7)]}[name]
            pygame.draw.polygon(cv, (30, 34, 46) if down else (236, 240, 248), tri)
        for (c, r, lab) in ((A_C, A_R, "A"), (B_C, B_R, "B")):
            down = any(math.hypot(x - c[0], y - c[1]) <= r + 5 for x, y in pts)
            pygame.draw.circle(cv, (230, 90, 90) if down else (170, 60, 70), c, r)
            pygame.draw.circle(cv, (255, 255, 255), c, r, 2)
            if lab == "A":
                cv.blit(self.icons[9], (c[0] - 8, c[1] - 8))          # attack / mine
            else:
                hb = self.held()
                if hb:
                    cv.blit(self.item_icon[hb], (c[0] - 8, c[1] - 8))   # use the held item
                else:
                    pygame.draw.line(cv, (255, 255, 255), (c[0] - 5, c[1]), (c[0] + 5, c[1]), 2)
                    pygame.draw.line(cv, (255, 255, 255), (c[0], c[1] - 5), (c[0], c[1] + 5), 2)

        # hotbar
        for i in range(9):
            r = pygame.Rect(HOT_X + i * HSLOT, HOT_Y, HSLOT - 2, HSLOT - 2)
            cv.blit(self.slot_bg, r.topleft)
            s = self.inv[i]
            if s:
                cv.blit(self.item_icon[s[0]], (r.x + 1, r.y + 1))
                if s[1] > 1:
                    self.text(str(s[1]), r.right - 1, r.bottom - 9, font=self.tiny, right=True)
            if i == self.sel:
                pygame.draw.rect(cv, (255, 220, 90), r, 2)
            else:
                pygame.draw.rect(cv, (110, 118, 135), r, 1)
        pygame.draw.rect(cv, (30, 34, 46), BAG_RECT, border_radius=4)
        pygame.draw.rect(cv, (210, 220, 235), BAG_RECT, 1, border_radius=4)
        cv.blit(self.icons[32], (BAG_RECT.x + 1, BAG_RECT.y + 1))
        held = self.held()
        if held:
            self.text(item_name(held), W // 2, HOT_Y - 11, center=True)
        if self.hint_t > 0:
            self.text(self.hint_text, W // 2, 60, (255, 235, 150), center=True)

    # ---------- drawing: inventory screens ----------
    def draw_slot(self, r, stack, sel=False):
        cv = self.cv
        pygame.draw.rect(cv, (38, 42, 56), r)
        pygame.draw.rect(cv, (255, 220, 90) if sel else (96, 104, 124), r, 2 if sel else 1)
        if stack:
            cv.blit(self.item_icon[stack[0]], (r.x + 2, r.y + 2))
            if stack[1] > 1:
                self.text(str(stack[1]), r.right - 1, r.bottom - 9, font=self.tiny, right=True)

    def add_btn(self, y, label, name, enabled=True, x=COL_X, w=124):
        r = pygame.Rect(x, y, w, 18)
        pygame.draw.rect(self.cv, (64, 76, 104) if enabled else (36, 38, 48), r, border_radius=5)
        pygame.draw.rect(self.cv, (200, 210, 225) if enabled else (90, 92, 104), r, 1, border_radius=5)
        self.text(label, r.centerx, r.y + 4, (255, 255, 255) if enabled else (120, 122, 134),
                  center=True)
        self.ui_btns.append((r, name, enabled))

    def draw_ui(self):
        cv = self.cv
        pygame.draw.rect(cv, (24, 28, 40), PANEL, border_radius=8)
        pygame.draw.rect(cv, (210, 220, 235), PANEL, 2, border_radius=8)
        self.ui_rects, self.ui_btns, self.craft_rows = [], [], []
        title = {"inv": "Inventory", "chest": "Chest", "furnace": "Furnace", "menu": "Game Menu",
                 "craft": "Crafting Table" if self.station == "table" else "Hand Crafting"}[self.ui]
        self.text(title, PANEL.x + 10, PANEL.y + 5, (255, 225, 140))
        if self.ui == "craft":
            self.draw_craft()
        elif self.ui == "menu":
            self.draw_game_menu()
        else:
            self.draw_containers()

    def draw_game_menu(self):
        self.text("Paused", W // 2, 40, font=self.big, center=True)
        self.add_btn(78, "Resume", "resume", True, 130, 124)
        self.add_btn(102, "Sound: ON" if self.snd.on else "Sound: OFF", "sound", True, 130, 124)
        self.add_btn(126, "Save & Title", "title", True, 130, 124)
        self.add_btn(150, "Quit Game", "quit", True, 130, 124)
        if self.is_client:
            self.text(f"Joined {self.net.ip}  -  Day {self.day}", W // 2, 180, (170, 180, 195),
                      center=True)
            self.text("The world keeps running", W // 2, 193, (150, 230, 160), center=True,
                      font=self.tiny)
        elif self.is_host:
            self.text(f"World {self.slot}  -  Day {self.day}  -  Players {1 + len(self.remotes)}",
                      W // 2, 180, (170, 180, 195), center=True)
            self.text("Friends join with IP: " + "  /  ".join(self.net.ips[:2]), W // 2, 193,
                      (150, 230, 160), center=True, font=self.tiny)
        else:
            self.text(f"World {self.slot}  -  Day {self.day}", W // 2, 182, (170, 180, 195),
                      center=True)

    def draw_containers(self):
        ui = self.ui
        if ui == "inv":
            by, hy = (40, 63, 86), 118
        else:
            by, hy = (106, 129, 152), 180
        self.text("Backpack", GX, by[0] - 11, (170, 180, 195), font=self.tiny)
        for r in range(3):
            for c in range(9):
                i = 9 + r * 9 + c
                rect = pygame.Rect(GX + c * PITCH, by[r], SZ, SZ)
                self.draw_slot(rect, self.inv[i])
                self.ui_rects.append((rect, "inv", self.inv, i))
        self.text("Hotbar", GX, hy - 11, (170, 180, 195), font=self.tiny)
        for c in range(9):
            rect = pygame.Rect(GX + c * PITCH, hy, SZ, SZ)
            self.draw_slot(rect, self.inv[c], c == self.sel)
            self.ui_rects.append((rect, "inv", self.inv, c))
        if ui == "chest":
            ch = self.chests[self.ui_key]
            for r in range(3):
                for c in range(9):
                    i = r * 9 + c
                    rect = pygame.Rect(GX + c * PITCH, 28 + r * 23, SZ, SZ)
                    self.draw_slot(rect, ch[i])
                    self.ui_rects.append((rect, "box", ch, i))
        elif ui == "furnace":
            f = self.furnaces[self.ui_key]
            for (x, y, rule, idx, label) in ((40, 36, "in", 0, "Input"), (40, 80, "fuel", 1, "Fuel"),
                                             (160, 58, "out", 2, "Output")):
                rect = pygame.Rect(x, y, SZ, SZ)
                self.draw_slot(rect, f["s"][idx])
                self.ui_rects.append((rect, rule, f["s"], idx))
                self.text(label, x + SZ // 2, y - 10, (170, 180, 195), font=self.tiny, center=True)
            pygame.draw.rect(self.cv, (50, 54, 70), (76, 64, 76, 8))
            pygame.draw.rect(self.cv, (250, 190, 60),
                             (76, 64, int(76 * min(1.0, f["prog"] / SMELT_TIME)), 8))
            pygame.draw.rect(self.cv, (200, 210, 225), (76, 64, 76, 8), 1)
            if f["burn"] > 0:
                self.cv.blit(self.tiles[43 + int(self.clock * 6) % 2], (52, 56))
            else:
                self.text("needs fuel", 114, 76, (150, 150, 165), font=self.tiny, center=True)
        # right column
        if ui == "inv":
            self.text("Armor", COL_X, 28, (170, 180, 195), font=self.tiny)
            rect = pygame.Rect(COL_X, 38, SZ, SZ)
            self.draw_slot(rect, self.armor_slot[0])
            self.ui_rects.append((rect, "armor", self.armor_slot, 0))
            ak = self.armor_key()
            self.text(f"takes {int(ARMOR_MULT[ak] * 100)}% damage" if ak else "none worn",
                      COL_X + 26, 44, (200, 205, 215), font=self.tiny)
        self.text("Carrying:", COL_X, 66, (170, 180, 195), font=self.tiny)
        rect = pygame.Rect(COL_X, 76, SZ, SZ)
        self.draw_slot(rect, self.cursor)
        if self.cursor:
            self.text(item_name(self.cursor[0]), COL_X + 26, 80, (255, 255, 255))
        else:
            self.text("tap an item to pick it up", COL_X + 26, 80, (140, 146, 160), font=self.tiny)
        kind = ITEMS[self.cursor[0]][3] if self.cursor else None
        y = 104
        self.add_btn(y, "Eat", "eat", kind == "food")
        self.add_btn(y + 21, "Wear", "wear", kind == "armor")
        self.add_btn(y + 42, "Trash", "trash", self.cursor is not None)
        if ui == "inv":
            self.add_btn(y + 63, "Craft", "craft", True)
            self.add_btn(y + 84, "Close", "close", True)
        else:
            self.add_btn(y + 63, "Close", "close", True)

    def draw_craft(self):
        cv = self.cv
        vis = [(i, r) for i, r in enumerate(RECIPES) if (not r[3]) or self.station == "table"]
        rows = 5
        self.scroll = clamp(self.scroll, 0, max(0, len(vis) - rows))
        for k in range(rows):
            idx = self.scroll + k
            if idx >= len(vis):
                break
            ri, (out, n, cost, tbl) = vis[idx]
            rect = pygame.Rect(GX, 28 + k * 35, 216, 32)
            ok = self.can_pay(cost)
            pygame.draw.rect(cv, (44, 58, 82) if ok else (34, 36, 46), rect, border_radius=5)
            pygame.draw.rect(cv, (140, 160, 190) if ok else (70, 72, 84), rect, 1, border_radius=5)
            cv.blit(self.item_icon[out], (rect.x + 5, rect.y + 8))
            self.text(f"{item_name(out)} x{n}", rect.x + 28, rect.y + 4)
            need = "  ".join(f"{item_name(k2)} {self.count(k2)}/{v}" for k2, v in cost.items())
            self.text(need, rect.x + 28, rect.y + 17, (150, 230, 150) if ok else (230, 140, 140),
                      font=self.tiny)
            self.text("CRAFT" if ok else "need more", rect.right - 6, rect.y + 10,
                      (255, 235, 150) if ok else (140, 140, 150), right=True)
            self.craft_rows.append((rect, ri))
        self.text(f"{len(vis)} recipes", GX, 28 + rows * 35, (150, 156, 170), font=self.tiny)
        if self.station != "table":
            self.text("Use a Craft Table for tools & armor", COL_X, 30, (255, 225, 140), font=self.tiny)
        self.add_btn(60, "Up", "up", self.scroll > 0)
        self.add_btn(81, "Down", "down", self.scroll < len(vis) - rows)
        self.add_btn(150, "Back" if self.station == "hand" else "Close", "back", True)


# ============================================================
#  MAIN
# ============================================================

class TitleMenu:
    """Main menu: 3 worlds + Multiplayer (host / join over Wi-Fi or hotspot)."""

    KEYS = ["1", "2", "3", "DEL", "4", "5", "6", ".", "7", "8", "9", "0"]

    def __init__(self, cv, snd):
        self.cv, self.snd = cv, snd
        self.res = get_res()
        self.confirm, self.confirm_t, self.t = None, 0.0, 0.0
        self.slot_rects = [pygame.Rect(48, 70 + i * 38, 230, 32) for i in range(NUM_WORLDS)]
        self.del_rects = [pygame.Rect(284, 70 + i * 38, 52, 32) for i in range(NUM_WORLDS)]
        self.snd_rect = pygame.Rect(24, 186, 100, 20)
        self.mp_rect = pygame.Rect(136, 186, 112, 20)
        self.quit_rect = pygame.Rect(260, 186, 100, 20)
        big = self.res["big"].render("PIXEL SURVIVAL", False, (255, 236, 150))
        self.title = pygame.transform.scale(big, (big.get_width() * 2, big.get_height() * 2))
        self.title_shadow = pygame.transform.scale(
            self.res["big"].render("PIXEL SURVIVAL", False, (60, 40, 20)),
            (big.get_width() * 2, big.get_height() * 2))
        # ---- multiplayer screens ----
        self.mode = "main"                       # main / mp / hostpick / join / connecting
        self.back_rect = pygame.Rect(144, 186, 96, 20)
        self.host_rect = pygame.Rect(72, 44, 240, 32)
        self.join_rect = pygame.Rect(72, 94, 240, 32)
        self.host_rects = [pygame.Rect(48, 54 + i * 38, 288, 32) for i in range(NUM_WORLDS)]
        self.key_rects = [(pygame.Rect(24 + (i % 4) * 38, 66 + (i // 4) * 28, 34, 24), k)
                          for i, k in enumerate(self.KEYS)]
        self.ip_rect = pygame.Rect(24, 36, 148, 24)
        self.go_rect = pygame.Rect(24, 152, 148, 26)
        self.jback_rect = pygame.Rect(24, 184, 148, 22)
        self.game_rects = [pygame.Rect(192, 54 + i * 34, 176, 30) for i in range(4)]
        self.finder = None
        self.client = None
        self.conn_t = 0.0
        self.status = ""
        self.notice, self.notice_t = "", 0.0
        self.ip = str(load_settings().get("ip", "192.168.43.1"))[:15]
        self.refresh()

    def refresh(self):
        self.info = [read_slot(i + 1) for i in range(NUM_WORLDS)]
        self.confirm = None

    def text(self, *a, **k):
        put_text(self.cv, *a, **k)

    def toast(self, msg, sec=4.0):
        self.notice, self.notice_t = msg, sec

    # ---------- mode handling ----------
    def go(self, mode):
        if mode == "join" and self.finder is None:
            self.finder = netlib.Finder()
        if mode != "join" and self.finder is not None:
            self.finder.close()
            self.finder = None
        self.mode = mode
        self.status = ""
        self.confirm = None

    def back(self):
        if self.mode == "connecting":
            if self.client:
                self.client.close()
                self.client = None
            self.go("join")
        elif self.mode in ("hostpick", "join"):
            self.go("mp")
        else:
            self.go("main")

    def shutdown(self):
        if self.client:
            self.client.close()
            self.client = None
        if self.finder:
            self.finder.close()
            self.finder = None

    def connect(self, ip):
        parts = ip.strip().split(".")
        if len(parts) != 4 or not all(p.isdigit() and 0 <= int(p) <= 255 for p in parts):
            self.status = "Type the host's IP like 192.168.43.1"
            self.snd.play("click")
            return
        self.ip = ip.strip()
        st = load_settings()
        st["ip"] = self.ip
        save_settings(st)
        self.client = netlib.Client(self.ip)
        self.conn_t = self.t
        self.go("connecting")

    # ---------- input ----------
    def on_key(self, e):
        if self.mode != "join":
            return
        if e.key == pygame.K_BACKSPACE:
            self.ip = self.ip[:-1]
        elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.connect(self.ip)
        elif e.unicode and e.unicode in "0123456789." and len(self.ip) < 15:
            self.ip += e.unicode

    def on_press(self, x, y):
        """Returns ("play", slot) / ("host", slot) / ("quit",) / None"""
        m = self.mode
        if m == "main":
            return self.press_main(x, y)
        if m == "mp":
            if self.host_rect.collidepoint(x, y):
                self.snd.play("click")
                self.go("hostpick")
            elif self.join_rect.collidepoint(x, y):
                self.snd.play("click")
                self.go("join")
            elif self.back_rect.collidepoint(x, y):
                self.snd.play("click")
                self.back()
        elif m == "hostpick":
            for i, r in enumerate(self.host_rects):
                if r.collidepoint(x, y):
                    self.snd.play("click")
                    return ("host", i + 1)
            if self.back_rect.collidepoint(x, y):
                self.snd.play("click")
                self.back()
        elif m == "join":
            for r, k in self.key_rects:
                if r.collidepoint(x, y):
                    self.snd.play("click", 0.5)
                    if k == "DEL":
                        self.ip = self.ip[:-1]
                    elif len(self.ip) < 15:
                        self.ip += k
                    return None
            if self.go_rect.collidepoint(x, y):
                self.snd.play("click")
                self.connect(self.ip)
            elif self.jback_rect.collidepoint(x, y):
                self.snd.play("click")
                self.back()
            else:
                for r, g in zip(self.game_rects, self.finder.games() if self.finder else []):
                    if r.collidepoint(x, y):
                        self.snd.play("click")
                        self.connect(g[0])
                        break
        elif m == "connecting":
            if self.back_rect.collidepoint(x, y):
                self.snd.play("click")
                self.back()
        return None

    def press_main(self, x, y):
        for i, r in enumerate(self.slot_rects):
            if r.collidepoint(x, y):
                self.snd.play("click")
                return ("play", i + 1)
        for i, r in enumerate(self.del_rects):
            if r.collidepoint(x, y) and self.info[i]:
                if self.confirm == i + 1:
                    try:
                        os.remove(world_path(i + 1))
                    except OSError:
                        pass
                    self.snd.play("hit")
                    self.refresh()
                else:
                    self.confirm, self.confirm_t = i + 1, 2.5
                    self.snd.play("click")
                return None
        if self.snd_rect.collidepoint(x, y):
            self.snd.toggle()
        elif self.mp_rect.collidepoint(x, y):
            self.snd.play("click")
            self.go("mp")
        elif self.quit_rect.collidepoint(x, y):
            return ("quit",)
        return None

    def update(self, dt):
        """Returns ("joined", client) once the host accepted us."""
        self.t += dt
        self.notice_t = max(0.0, self.notice_t - dt)
        if self.confirm:
            self.confirm_t -= dt
            if self.confirm_t <= 0:
                self.confirm = None
        if self.finder:
            self.finder.poll()
        if self.mode == "connecting" and self.client:
            c = self.client
            c.pump()
            if c.welcome:
                self.client = None
                self.go("main")
                return ("joined", c)
            if c.state == "failed" or c.dead or self.t - self.conn_t > 15:
                err = c.err or "No answer from the host"
                c.close()
                self.client = None
                self.go("join")
                self.status = err
        return None

    # ---------- drawing ----------
    def button(self, r, label, col=(60, 70, 96), edge=(200, 210, 225), font=None):
        pygame.draw.rect(self.cv, col, r, border_radius=5)
        pygame.draw.rect(self.cv, edge, r, 1, border_radius=5)
        self.text(label, r.centerx, r.centery - 5, center=True, font=font)

    def header(self, title, sub=None):
        self.cv.fill((28, 34, 50))
        self.text(title, W // 2, 8, (255, 236, 150), font=self.res["big"], center=True)
        if sub:
            self.text(sub, W // 2, 34, (170, 180, 195), font=self.res["tiny"], center=True)

    def draw(self):
        m = self.mode
        if m == "main":
            self.draw_main()
        elif m == "mp":
            self.header("Multiplayer")
            self.button(self.host_rect, "Host a Game", (46, 110, 70), (170, 235, 190))
            self.text("You run the world, friends join you", W // 2, self.host_rect.bottom + 3,
                      (170, 180, 195), font=self.res["tiny"], center=True)
            self.button(self.join_rect, "Join a Game", (50, 80, 130), (170, 200, 240))
            self.text("Enter the host's IP or pick it from the list", W // 2,
                      self.join_rect.bottom + 3, (170, 180, 195), font=self.res["tiny"],
                      center=True)
            self.text("Everybody must be on the same Wi-Fi,", W // 2, 148, (200, 210, 225),
                      center=True)
            self.text("or connected to the host phone's hotspot.", W // 2, 161, (200, 210, 225),
                      center=True)
            self.button(self.back_rect, "Back")
        elif m == "hostpick":
            self.header("Host a Game", "Choose the world friends will play in")
            for i, r in enumerate(self.host_rects):
                info = self.info[i]
                pygame.draw.rect(self.cv, (50, 66, 100) if info else (40, 48, 66), r,
                                 border_radius=6)
                pygame.draw.rect(self.cv, (210, 220, 235), r, 2, border_radius=6)
                self.text(f"World {i + 1}", r.x + 10, r.y + 4)
                self.text(f"Day {info['day']}   -   tap to host" if info
                          else "Empty   -   tap to create a new world and host it",
                          r.x + 10, r.y + 17, (160, 230, 160) if info else (190, 196, 210),
                          font=self.res["tiny"])
            self.button(self.back_rect, "Back")
        elif m == "join":
            self.draw_join()
        else:
            self.header("Joining...")
            dots = "." * (int(self.t * 3) % 4)
            self.text(f"Connecting to {self.ip}{dots}", W // 2, 92, center=True)
            self.text("Waiting for the host", W // 2, 112, (170, 180, 195), center=True,
                      font=self.res["tiny"])
            self.button(self.back_rect, "Cancel")
        if self.notice_t > 0:
            r = pygame.Rect(W // 2 - 150, 98, 300, 26)
            pygame.draw.rect(self.cv, (90, 40, 40), r, border_radius=6)
            pygame.draw.rect(self.cv, (240, 180, 180), r, 1, border_radius=6)
            self.text(self.notice, r.centerx, r.y + 8, center=True)

    def draw_join(self):
        self.header("Join a Game")
        r = self.ip_rect
        pygame.draw.rect(self.cv, (16, 20, 30), r, border_radius=4)
        pygame.draw.rect(self.cv, (255, 220, 90), r, 2, border_radius=4)
        caret = "_" if int(self.t * 2) % 2 == 0 else " "
        self.text(self.ip + caret, r.x + 8, r.y + 6, (255, 255, 255))
        for kr, k in self.key_rects:
            self.button(kr, k, (70, 60, 60) if k == "DEL" else (60, 70, 96))
        self.button(self.go_rect, "Connect", (46, 110, 70), (170, 235, 190))
        self.button(self.jback_rect, "Back")
        self.text("Games found on this Wi-Fi:", 192, 38, (200, 210, 225))
        games = self.finder.games() if self.finder else []
        for gr, (ip, name, n) in zip(self.game_rects, games):
            pygame.draw.rect(self.cv, (50, 80, 130), gr, border_radius=5)
            pygame.draw.rect(self.cv, (170, 200, 240), gr, 1, border_radius=5)
            self.text(f"{name}  ({n} playing)", gr.x + 8, gr.y + 4)
            self.text(ip, gr.x + 8, gr.y + 17, (190, 215, 245), font=self.res["tiny"])
        if not games:
            self.text("Searching...", 280, 92, (150, 158, 175), center=True)
            self.text("If nothing shows up,", 280, 112, (150, 158, 175), center=True,
                      font=self.res["tiny"])
            self.text("type the IP shown on the host phone", 280, 124, (150, 158, 175),
                      center=True, font=self.res["tiny"])
        if self.status:
            self.text(self.status, 280, 196, (255, 160, 160), center=True,
                      font=self.res["tiny"])

    def draw_main(self):
        cv, R = self.cv, self.res
        cv.fill((104, 186, 240))
        for x in range(0, W, 16):                              # grass strip with scenery
            cv.blit(R["tiles"][(x // 16 * 7) % 3], (x, 58))
            cv.blit(R["tiles"][9], (x, 74))
        for x, tile in ((18, 10), (330, 10), (352, 11), (296, 10)):
            cv.blit(R["tiles"][tile], (x, 44))
        for i, kind in enumerate(("pig", "cow", "sheep", "chicken")):
            ax = (self.t * 14 + i * 96) % (W + 48) - 24
            frames = R["animal_img"][kind]["R"]
            cv.blit(frames[int(self.t * 4) % 2], (int(ax), 46 + (i % 2) * 2))
        cv.blit(self.title_shadow, ((W - self.title.get_width()) // 2 + 2, 12))
        cv.blit(self.title, ((W - self.title.get_width()) // 2, 10))
        pygame.draw.rect(cv, (28, 34, 50), (0, 66, W, H - 66))
        pygame.draw.line(cv, (70, 80, 110), (0, 66), (W, 66), 1)
        for i in range(NUM_WORLDS):
            r, info = self.slot_rects[i], self.info[i]
            pygame.draw.rect(cv, (50, 66, 100) if info else (40, 48, 66), r, border_radius=6)
            pygame.draw.rect(cv, (210, 220, 235), r, 2, border_radius=6)
            self.text(f"World {i + 1}", r.x + 10, r.y + 4, (255, 255, 255))
            if info:
                self.text(f"Day {info['day']}   -   tap to play", r.x + 10, r.y + 17,
                          (160, 230, 160), font=R["tiny"])
            else:
                self.text("Empty   -   tap to create a new world", r.x + 10, r.y + 17,
                          (190, 196, 210), font=R["tiny"])
            if info:
                d = self.del_rects[i]
                sure = self.confirm == i + 1
                pygame.draw.rect(cv, (150, 50, 50) if sure else (70, 44, 48), d, border_radius=6)
                pygame.draw.rect(cv, (230, 160, 160), d, 1, border_radius=6)
                self.text("Sure?" if sure else "Delete", d.centerx, d.y + 10, center=True)
        self.button(self.snd_rect, "Sound: ON" if self.snd.on else "Sound: OFF")
        self.button(self.mp_rect, "Multiplayer", (46, 110, 70), (170, 235, 190))
        self.button(self.quit_rect, "Quit")


def init_display():
    if USE_SCALED:
        try:
            scr = pygame.display.set_mode((W, H), pygame.SCALED | pygame.FULLSCREEN)
            return scr, True
        except Exception:
            pass
    try:
        scr = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    except pygame.error:
        scr = pygame.display.set_mode((W * 2, H * 2))
    return scr, False


def main():
    pygame.init()
    screen, scaled = init_display()
    pygame.display.set_caption("Pixel Survival")
    SW, SH = screen.get_size()
    scaled_surf = size = None
    if scaled:
        canvas, ox, oy, scale = screen, 0, 0, 1.0
    else:
        scale = min(SW / W, SH / H)
        size = (int(W * scale), int(H * scale))
        ox, oy = (SW - size[0]) // 2, (SH - size[1]) // 2
        canvas = pygame.Surface((W, H)).convert()
        scaled_surf = pygame.Surface(size).convert()
    screen.fill((0, 0, 0))

    def present():
        if not scaled:
            pygame.transform.scale(canvas, size, scaled_surf)
            screen.blit(scaled_surf, (ox, oy))
        pygame.display.flip()

    lf = pygame.font.Font(None, 26)

    def show_loading(msg):
        canvas.fill((20, 24, 34))
        img = lf.render(msg, False, (230, 235, 245))
        canvas.blit(img, ((W - img.get_width()) // 2, H // 2 - 8))
        present()

    show_loading("Loading...")
    get_res()
    snd = Sfx(SOUNDS)
    menu = TitleMenu(canvas, snd)
    S = {"state": "title", "game": None}
    clock = pygame.time.Clock()
    fingers = {}                      # finger id -> canvas position (held buttons)
    pending = []                      # finger taps waiting for their emulated mouse event
    touch = False
    running = True
    sc = [None]                       # calibrated SCALED factor
    last_press = [0.0]

    def f2c(fx, fy, s=None):
        """normalised finger position -> canvas coordinates"""
        if scaled:
            try:
                ww, wh = pygame.display.get_window_size()
            except Exception:
                return fx * W, fy * H
            s = s or sc[0] or max(1, int(min(ww / W, wh / H)))
            return (fx * ww - (ww - W * s) / 2) / s, (fy * wh - (wh - H * s) / 2) / s
        return (fx * SW - ox) / scale, (fy * SH - oy) / scale

    def m2c(px, py):
        if scaled:
            return px, py
        return (px - ox) / scale, (py - oy) / scale

    def calibrate(fx, fy, mpos):
        if not scaled:
            return
        try:
            ww, wh = pygame.display.get_window_size()
            cands = [max(1, int(min(ww / W, wh / H))), min(ww / W, wh / H)]
            sc[0] = min(cands, key=lambda s: math.hypot(f2c(fx, fy, s)[0] - mpos[0],
                                                        f2c(fx, fy, s)[1] - mpos[1]))
        except Exception:
            pass

    def start_game(slot, hosting=False):
        info = read_slot(slot)
        seed = info["seed"] if info else random.randrange(1, 10 ** 6)
        host = None
        if hosting:
            try:
                host = netlib.Host(f"World {slot}")
            except OSError:
                menu.toast("Could not start hosting (port 5555 is busy)")
                return
        show_loading("Creating world..." if not info else "Loading world...")
        try:
            S["game"] = Game(canvas, snd, slot, seed, net=host)
        except Exception:
            if host:
                host.close()
            raise
        S["state"] = "game"
        fingers.clear()
        pending.clear()

    def start_client(client):
        w = client.welcome
        show_loading("Joining world...")
        try:
            S["game"] = Game(canvas, snd, 0, int(w["seed"]), net=client, welcome=w)
        except (KeyError, ValueError, TypeError):
            client.close()
            menu.toast("Could not join: the world data does not match")
            return
        S["state"] = "game"
        fingers.clear()
        pending.clear()

    def tap(x, y):
        nonlocal running
        if S["state"] == "title":
            act = menu.on_press(x, y)
            if act and act[0] == "quit":
                running = False
            elif act and act[0] == "play":
                start_game(act[1])
            elif act and act[0] == "host":
                start_game(act[1], hosting=True)
        else:
            S["game"].on_press(x, y)

    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        now = _time.time()
        game = S["game"]
        if game:
            game.fps = clock.get_fps()
        mouse_downs = []
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.FINGERDOWN:
                touch = True
                fingers[e.finger_id] = f2c(e.x, e.y)
                pending.append([e.x, e.y, now])
            elif e.type == pygame.FINGERMOTION:
                if e.finger_id in fingers:
                    fingers[e.finger_id] = f2c(e.x, e.y)
            elif e.type == pygame.FINGERUP:
                fingers.pop(e.finger_id, None)
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                mouse_downs.append(m2c(*e.pos))
            elif e.type == pygame.KEYDOWN and game and S["state"] == "game":
                if e.key == pygame.K_ESCAPE:
                    if game.ui:
                        game.close_ui()
                    elif not (game.dead_t > 0 or game.sleep_phase):
                        game.open_ui("menu")
                elif e.key == pygame.K_i:
                    if game.ui:
                        game.close_ui()
                    elif not (game.dead_t > 0 or game.sleep_phase):
                        game.open_ui("inv")
                elif e.key in (pygame.K_j, pygame.K_SPACE):
                    game.try_act()
                elif e.key in (pygame.K_k, pygame.K_e):
                    game.use_held()
                elif pygame.K_1 <= e.key <= pygame.K_9:
                    game.select(e.key - pygame.K_1)
            elif e.type == pygame.KEYDOWN and S["state"] == "title":
                if e.key == pygame.K_ESCAPE:
                    if menu.mode == "main":
                        running = False
                    else:
                        menu.back()
                else:
                    menu.on_key(e)
            elif e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                running = False

        # taps: the mouse position (always correct) beats the finger mapping
        for md in mouse_downs:
            if pending:
                fx, fy, _t = pending.pop(0)
                calibrate(fx, fy, md)
            elif touch and now - last_press[0] < 0.4:
                continue
            last_press[0] = now
            tap(*md)
        for p in list(pending):
            if now - p[2] > 0.08:
                pending.remove(p)
                last_press[0] = now
                tap(*f2c(p[0], p[1]))

        game = S["game"]
        if S["state"] == "title" or game is None:
            act = menu.update(dt)
            menu.draw()
            present()
            if act and act[0] == "joined":
                start_client(act[1])
            continue

        pts = list(fingers.values())
        if pygame.mouse.get_pressed()[0]:
            mp = m2c(*pygame.mouse.get_pos())
            if pts:
                near = min(pts, key=lambda q: math.hypot(q[0] - mp[0], q[1] - mp[1]))
                pts.remove(near)
            pts.append(mp)

        mx = my = 0.0
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            mx -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            mx += 1
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            my -= 1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            my += 1
        a_held = False
        for q in pts:
            for name, r in DPAD.items():
                if r.inflate(10, 10).collidepoint(q):
                    if name == "left":
                        mx -= 1
                    elif name == "right":
                        mx += 1
                    elif name == "up":
                        my -= 1
                    else:
                        my += 1
            if math.hypot(q[0] - A_C[0], q[1] - A_C[1]) <= A_R + 5:
                a_held = True

        game.update(dt, mx, my, a_held)
        game.draw(pts)
        present()

        if game.request:
            req = game.request
            game.save()
            game.close_net()
            snd.set_rain(0)
            S["game"], S["state"] = None, "title"
            fingers.clear()
            pending.clear()
            menu.refresh()
            if game.exit_msg:
                menu.toast(game.exit_msg)
            if req == "quit":
                running = False

    if S["game"]:
        S["game"].save()
        S["game"].close_net()
    menu.shutdown()
    pygame.quit()


if __name__ == "__main__":
    main()
