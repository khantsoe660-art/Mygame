# PIXEL SURVIVAL - sound manager
# Looks in the "sounds" folder for  <name>.ogg / .mp3 / .wav
# Missing sounds are generated automatically (make_assets.generate_sounds).
# To use your own sound: drop a file with the same name into "sounds".
# Optional background music: sounds/music.ogg (or .mp3 / .wav)  -> loops.
import os
import time

import pygame

NAMES = ["chop", "mine", "hit", "hurt", "eat", "place", "craft", "pickup",
         "splash", "bite", "click", "death", "zombie", "sleep", "rain", "open"]
EXTS = (".ogg", ".mp3", ".wav")


class Sfx:
    def __init__(self, folder):
        self.ok = False
        self.on = True
        self.snd = {}
        self.last = {}
        self.rain_ch = None
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(22050, -16, 1, 512)
            self.ok = True
        except Exception:
            return
        try:
            missing = [n for n in NAMES
                       if not any(os.path.exists(os.path.join(folder, n + e)) for e in EXTS)]
            if missing:
                import make_assets
                make_assets.generate_sounds(folder)
        except Exception:
            pass
        for n in NAMES:
            for e in EXTS:
                path = os.path.join(folder, n + e)
                if os.path.exists(path):
                    try:
                        self.snd[n] = pygame.mixer.Sound(path)
                        break
                    except Exception:
                        continue
        for e in EXTS:                                  # optional music
            path = os.path.join(folder, "music" + e)
            if os.path.exists(path):
                try:
                    pygame.mixer.music.load(path)
                    pygame.mixer.music.set_volume(0.35)
                    pygame.mixer.music.play(-1)
                except Exception:
                    pass
                break

    def play(self, name, vol=1.0):
        if not (self.ok and self.on):
            return
        s = self.snd.get(name)
        if s is None:
            return
        now = time.time()
        if now - self.last.get(name, 0) < 0.06:
            return
        self.last[name] = now
        try:
            s.set_volume(vol)
            s.play()
        except Exception:
            pass

    def set_rain(self, amount):
        """amount 0..1  -> looping rain sound"""
        if not (self.ok and self.on) or "rain" not in self.snd:
            return
        try:
            if amount > 0.05:
                if self.rain_ch is None or not self.rain_ch.get_busy():
                    self.rain_ch = self.snd["rain"].play(-1)
                if self.rain_ch is not None:
                    self.rain_ch.set_volume(min(1.0, amount) * 0.6)
            elif self.rain_ch is not None:
                self.rain_ch.stop()
                self.rain_ch = None
        except Exception:
            pass

    def toggle(self):
        self.on = not self.on
        if not self.ok:
            return
        try:
            if self.on:
                pygame.mixer.music.unpause()
            else:
                pygame.mixer.stop()
                pygame.mixer.music.pause()
                self.rain_ch = None
        except Exception:
            pass
