# PIXEL SURVIVAL - asset generator
# Creates all PNG files into the "assets" folder.
# Pure Python (no pygame / no Pillow needed).
#
#   python make_assets.py
#
# Files:
#   tiles.png        160x128 (10 x 8 tiles, 16x16)
#   player.png       48x80   (3 frames x 4 directions, 16x20)  rows: down,left,right,up
#   player_armor.png 48x80   same, wearing iron armor
#   zombie.png       48x80   same layout as player.png
#   animals.png      64x64   rows: pig, sheep, cow, chicken | cols: side0 side1 front0 front1
#   spider.png       32x16   2 frames
#   ghost.png        32x16   2 frames
#   items.png        128x80  8 x 5 icons (see order in generate())
#   player_gold.png / player_diamond.png  armor skins (same layout as player.png)
#   sounds/*.wav     generated sound effects (replace with your own .ogg/.wav/.mp3)
#   fx.png           96x16   hit spark (3 frames) + smoke puff (3 frames)
#
# tiles.png index:
#   0-3 grass  4-5 water(anim)  6-7 sand  8 wood floor  9 dirt
#   10 tree 11 rock 12 wood wall 13 stone wall 14 door 15 bed 16-19 campfire(anim)
#   20 iron ore 21 craft table 22-25 torch(anim)
#   26-28 potato crop (sprout, growing, ripe)  29-31 radish crop (same)
#   32 stone floor 33 carpet 34 tile floor 35 cave floor 36 brick wall 37 glass
#   38 dirt block 39 gold block 40 diamond block 41 chest 42 furnace 43-44 furnace lit
#   45 mountain rock 46 coal ore 47 gold ore 48 diamond ore (20 = iron ore)
#   49-64 oak fence (bit mask N=1 E=2 S=4 W=8)  65/66 gate closed/open  67/68 gate vertical
#   69-71 wheat crop (3 stages)

import math
import os
import random
import struct
import wave
import zlib

OUTLINE = (28, 22, 36)


class Img:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.p = [[(0, 0, 0, 0)] * w for _ in range(h)]

    # --- basic pixels ---
    def set(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.p[y][x] = c if len(c) == 4 else (c[0], c[1], c[2], 255)

    def get(self, x, y):
        return self.p[y][x]

    def rect(self, x, y, w, h, c):
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                self.set(xx, yy, c)

    # --- shapes (pixel-centre based) ---
    def ellipse(self, cx, cy, rx, ry, c):
        for yy in range(self.h):
            for xx in range(self.w):
                if ((xx + 0.5 - cx) / rx) ** 2 + ((yy + 0.5 - cy) / ry) ** 2 <= 1.0:
                    self.set(xx, yy, c)

    def circle(self, cx, cy, r, c):
        self.ellipse(cx, cy, r, r, c)

    def polygon(self, pts, c):
        n = len(pts)
        for yy in range(self.h):
            for xx in range(self.w):
                px, py = xx + 0.5, yy + 0.5
                inside = False
                j = n - 1
                for i in range(n):
                    xi, yi = pts[i]
                    xj, yj = pts[j]
                    if (yi > py) != (yj > py):
                        if px < (xj - xi) * (py - yi) / (yj - yi) + xi:
                            inside = not inside
                    j = i
                if inside:
                    self.set(xx, yy, c)

    def line(self, x0, y0, x1, y1, width, c):
        dx, dy = x1 - x0, y1 - y0
        ln = dx * dx + dy * dy
        for yy in range(self.h):
            for xx in range(self.w):
                px, py = xx + 0.5, yy + 0.5
                t = 0 if ln == 0 else max(0, min(1, ((px - x0) * dx + (py - y0) * dy) / ln))
                qx, qy = x0 + t * dx, y0 + t * dy
                if (px - qx) ** 2 + (py - qy) ** 2 <= (width / 2) ** 2:
                    self.set(xx, yy, c)

    # --- compositing ---
    def blit(self, src, ox, oy):
        for y in range(src.h):
            for x in range(src.w):
                r, g, b, a = src.p[y][x]
                if a == 0:
                    continue
                dx, dy = ox + x, oy + y
                if not (0 <= dx < self.w and 0 <= dy < self.h):
                    continue
                if a == 255:
                    self.p[dy][dx] = (r, g, b, 255)
                else:
                    R, G, B, A = self.p[dy][dx]
                    na = a + A * (255 - a) // 255
                    if na == 0:
                        continue
                    self.p[dy][dx] = (
                        (r * a + R * A * (255 - a) // 255) // na,
                        (g * a + G * A * (255 - a) // 255) // na,
                        (b * a + B * A * (255 - a) // 255) // na, na)

    def outline(self, col=OUTLINE):
        src = [row[:] for row in self.p]
        for y in range(self.h):
            for x in range(self.w):
                if src[y][x][3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < self.w and 0 <= ny < self.h and src[ny][nx][3] > 0:
                            self.p[y][x] = col + (255,)
                            break

    # --- PNG writer ---
    def save(self, path):
        raw = b"".join(b"\x00" + bytes(v for px in row for v in px) for row in self.p)

        def chunk(tag, data):
            c = struct.pack(">I", len(data)) + tag + data
            return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

        png = (b"\x89PNG\r\n\x1a\n"
               + chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 6, 0, 0, 0))
               + chunk(b"IDAT", zlib.compress(raw, 9))
               + chunk(b"IEND", b""))
        with open(path, "wb") as f:
            f.write(png)


def dark(c, f=0.72):
    return (int(c[0] * f), int(c[1] * f), int(c[2] * f))


# ============================================================
#  TILES
# ============================================================

def flower(s, x, y, petal, centre):
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        s.set(x + dx, y + dy, petal)
    s.set(x, y, centre)


def tile_grass(v):
    rng = random.Random(100 + v)
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (92, 176, 72))
    for _ in range(16):
        s.set(rng.randrange(16), rng.randrange(16),
              rng.choice([(78, 158, 62), (112, 194, 86)]))
    for x, y in ((4, 5), (11, 12)):
        for dx, dy in ((0, 0), (-1, -1), (1, -1), (0, -1)):
            s.set(x + dx, y + dy, (62, 136, 54))
    if v == 2:
        flower(s, 8, 8, (235, 80, 90), (255, 235, 120))
    if v == 3:
        flower(s, 5, 10, (250, 225, 80), (255, 255, 255))
    return s


WAVES = [(1, 3), (9, 6), (4, 10), (12, 13)]


def tile_water(f):
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (58, 118, 214))
    for x, y in WAVES:
        xx = (x + f * 3) % 14
        s.rect(xx, y, 3, 1, (150, 202, 250))
        s.rect(xx + 1, y + 1, 2, 1, (40, 96, 190))
    return s


def tile_sand(v):
    rng = random.Random(200 + v)
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (232, 208, 148))
    for _ in range(14):
        s.set(rng.randrange(16), rng.randrange(16),
              rng.choice([(210, 184, 124), (244, 226, 176)]))
    if v == 1:
        s.rect(9, 4, 2, 1, (190, 164, 108))
        s.rect(3, 11, 3, 1, (190, 164, 108))
    return s


def tile_floor():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (196, 142, 86))
    for r in range(4):
        s.rect(0, r * 4, 16, 1, (216, 166, 108))
        s.rect(0, r * 4 + 3, 16, 1, (150, 102, 60))
    for r, x in {0: 5, 1: 11, 2: 3, 3: 9}.items():
        s.rect(x, r * 4, 1, 3, (150, 102, 60))
    return s


def tile_dirt():
    rng = random.Random(300)
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (150, 110, 70))
    for _ in range(18):
        s.set(rng.randrange(16), rng.randrange(16),
              rng.choice([(126, 90, 56), (172, 130, 86)]))
    return s


def tile_tree():
    s = Img(16, 16)
    s.rect(7, 11, 3, 4, (118, 78, 48))
    s.rect(9, 11, 1, 4, (92, 58, 36))
    s.circle(8, 6.5, 6.2, (34, 110, 52))
    s.circle(7, 5.5, 5, (52, 150, 70))
    s.circle(6, 4.5, 3, (86, 186, 94))
    for x, y in ((5, 3), (8, 2), (10, 6), (4, 6)):
        s.set(x, y, (126, 216, 122))
    for x, y in ((11, 9), (9, 10), (5, 9)):
        s.set(x, y, (28, 92, 44))
    s.outline()
    return s


def rock_base():
    s = Img(16, 16)
    s.ellipse(8, 9.5, 6.2, 4.6, (104, 108, 124))
    s.ellipse(7.5, 8.5, 5, 3.4, (146, 150, 166))
    s.ellipse(6.5, 7.5, 2.6, 1.6, (190, 194, 208))
    return s


def tile_rock():
    s = rock_base()
    s.set(10, 9, (92, 96, 110))
    s.set(11, 10, (92, 96, 110))
    s.set(9, 11, (92, 96, 110))
    s.outline()
    return s


def tile_table():
    s = Img(16, 16)
    s.rect(2, 12, 2, 3, (104, 68, 40))
    s.rect(12, 12, 2, 3, (104, 68, 40))
    s.rect(1, 10, 14, 2, (138, 94, 56))
    s.rect(1, 3, 14, 7, (198, 146, 90))
    s.rect(1, 3, 14, 1, (224, 174, 114))
    s.rect(1, 6, 14, 1, (164, 114, 68))
    s.rect(3, 4, 3, 2, (182, 188, 204))
    s.rect(6, 5, 4, 1, (120, 80, 46))
    s.rect(11, 4, 2, 2, (214, 70, 80))
    s.outline()
    return s


TORCH_TIPS = [(8, 2), (7.4, 1.4), (8.6, 2), (8, 1.4)]


def tile_torch(f):
    s = Img(16, 16)
    s.rect(7, 7, 2, 7, (124, 82, 46))
    s.rect(8, 7, 1, 7, (96, 62, 36))
    tx, ty = TORCH_TIPS[f]
    s.polygon([(6, 7), (6.4, 4.5), (tx, ty), (9.6, 4.5), (10, 7)], (255, 140, 40))
    s.polygon([(7, 7), (7.2, 5.5), (tx, ty + 2), (8.8, 5.5), (9, 7)], (255, 214, 80))
    s.outline()
    return s


def tile_wall():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (176, 124, 74))
    for x in (3, 7, 11):
        s.rect(x, 0, 1, 16, (122, 82, 48))
    s.rect(0, 0, 16, 2, (212, 160, 102))
    s.rect(0, 14, 16, 2, (98, 64, 38))
    for x in (1, 5, 9, 13):
        s.set(x, 4, (60, 60, 70))
        s.set(x, 11, (60, 60, 70))
    return s


def tile_stone_wall():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (146, 150, 162))
    for y in (5, 10, 15):
        s.rect(0, y, 16, 1, (96, 100, 114))
    s.rect(7, 0, 1, 5, (96, 100, 114))
    s.rect(3, 6, 1, 4, (96, 100, 114))
    s.rect(11, 6, 1, 4, (96, 100, 114))
    s.rect(7, 11, 1, 4, (96, 100, 114))
    for y in (0, 6, 11):
        s.rect(0, y, 16, 1, (178, 182, 196))
    return s


def tile_door():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (88, 58, 38))
    s.rect(2, 1, 12, 15, (164, 114, 68))
    s.rect(2, 1, 12, 1, (192, 142, 88))
    s.rect(4, 3, 8, 5, (138, 92, 54))
    s.rect(4, 9, 8, 5, (138, 92, 54))
    s.rect(4, 3, 8, 1, (112, 74, 44))
    s.rect(4, 9, 8, 1, (112, 74, 44))
    s.rect(11, 8, 1, 2, (250, 214, 84))
    return s


def tile_bed():
    s = Img(16, 16)
    s.rect(2, 1, 12, 14, (120, 80, 50))
    s.rect(3, 2, 10, 4, (234, 238, 250))
    s.rect(3, 2, 10, 1, (255, 255, 255))
    s.rect(3, 6, 10, 8, (214, 70, 80))
    s.rect(3, 9, 10, 1, (176, 48, 60))
    s.rect(3, 6, 10, 1, (236, 110, 118))
    s.outline()
    return s


FLAME_TIPS = [(8, 3), (7, 2), (9, 3), (8, 2)]


def tile_fire(f):
    s = Img(16, 16)
    s.line(3, 13, 13, 11, 3, (112, 72, 42))
    s.line(3, 11, 13, 13, 3, (132, 88, 52))
    tx, ty = FLAME_TIPS[f]
    s.polygon([(4.5, 11), (5.5, 7), (tx, ty), (10.5, 7), (11.5, 11)], (255, 140, 40))
    s.polygon([(6, 11), (6.5, 8), (tx, ty + 3), (9.5, 8), (10, 11)], (255, 200, 60))
    s.polygon([(7, 11), (8, 8.5), (9, 11)], (255, 246, 170))
    s.outline()
    return s


# ============================================================
#  CHARACTERS  (16 x 20, content y=2..18)
# ============================================================

PLAYER_PAL = dict(skin=(250, 208, 168), hair=(92, 58, 40), shirt=(66, 120, 220),
                  pants=(58, 64, 112), shoe=(50, 40, 40), eye=(30, 24, 40))
ZOMBIE_PAL = dict(skin=(124, 176, 100), hair=(52, 62, 52), shirt=(58, 128, 140),
                  pants=(84, 72, 120), shoe=(50, 40, 40), eye=(232, 50, 50))


def draw_char(d, f, pal, zombie=False):
    s = Img(16, 20)
    skin, hair, shirt, pants = pal["skin"], pal["hair"], pal["shirt"], pal["pants"]
    shoe, eye = pal["shoe"], pal["eye"]
    pants_far = dark(pants)
    sign = -1 if d == "left" else 1

    # --- legs ---
    if d in ("down", "up"):
        lo = -1 if f == 1 else 0
        ro = -1 if f == 2 else 0
        s.rect(5, 14, 3, 3 + lo, pants)
        s.rect(5, 17 + lo, 3, 1, shoe)
        s.rect(8, 14, 3, 3 + ro, pants)
        s.rect(8, 17 + ro, 3, 1, shoe)
    else:
        if f == 0:
            near_x, far_x = 6, 6
        elif f == 1:
            near_x, far_x = 6 + 2 * sign, 6 - 2 * sign
        else:
            near_x, far_x = 6 - 2 * sign, 6 + 2 * sign
        s.rect(far_x, 14, 3, 3, pants_far)
        s.rect(far_x, 17, 3, 1, dark(shoe, 0.8))
        s.rect(near_x, 14, 3, 3, pants)
        s.rect(near_x, 17, 3, 1, shoe)

    # --- body ---
    s.rect(5, 9, 6, 5, shirt)
    s.rect(5, 13, 6, 1, dark(shirt, 0.8))
    if zombie:
        s.set(6, 11, dark(shirt, 0.6))
        s.set(9, 12, dark(shirt, 0.6))
        s.set(10, 10, skin)

    # --- arms ---
    arm_skin = skin
    if d in ("down", "up"):
        la = 1 if f == 1 else (-1 if f == 2 else 0)
        ra = -la
        top = 8 if zombie else 9
        ln = 5 if zombie else 4
        s.rect(3, top + la, 2, ln - 2, shirt)
        s.rect(3, top + la + ln - 2, 2, 2, arm_skin)
        s.rect(11, top + ra, 2, ln - 2, shirt)
        s.rect(11, top + ra + ln - 2, 2, 2, arm_skin)

    # --- head ---
    s.rect(4, 2, 8, 7, skin)
    if d == "down":
        s.rect(4, 2, 8, 3, hair)
        s.set(4, 5, hair)
        s.set(11, 5, hair)
        s.rect(6, 6, 1, 2, eye)
        s.rect(9, 6, 1, 2, eye)
    elif d == "up":
        s.rect(4, 2, 8, 7, hair)
        s.rect(5, 8, 6, 1, dark(hair, 0.8))
    elif d == "left":
        s.rect(4, 2, 8, 3, hair)
        s.rect(8, 5, 4, 4, hair)
        s.rect(5, 6, 1, 2, eye)
        s.set(3, 6, skin)
    else:
        s.rect(4, 2, 8, 3, hair)
        s.rect(4, 5, 4, 4, hair)
        s.rect(10, 6, 1, 2, eye)
        s.set(12, 6, skin)

    # --- side arm (drawn over the body) ---
    if d in ("left", "right"):
        if zombie:
            if d == "right":
                s.rect(8, 9, 6, 2, arm_skin)
            else:
                s.rect(2, 9, 6, 2, arm_skin)
        else:
            ax = 7 + (2 * sign if f == 1 else (-2 * sign if f == 2 else 0))
            s.rect(ax, 9, 2, 2, shirt)
            s.rect(ax, 11, 2, 2, arm_skin)
    s.outline()
    return s


def make_char_sheet(pal, zombie=False):
    sheet = Img(48, 80)
    for row, d in enumerate(("down", "left", "right", "up")):
        for f in range(3):
            sheet.blit(draw_char(d, f, pal, zombie), f * 16, row * 20)
    return sheet


# ============================================================
#  ITEMS / FX
# ============================================================

HEART = ["  XX   XX ".strip(), "XXXX.XXXX", "XXXXXXXXX", "XXXXXXXXX",
         ".XXXXXXX.", "..XXXXX..", "...XXX...", "....X...."]
HEART[0] = ".XX...XX."


def icon_wood():
    s = Img(16, 16)
    s.rect(3, 5, 10, 7, (150, 100, 58))
    s.rect(3, 9, 10, 3, (120, 78, 44))
    s.rect(3, 5, 10, 1, (176, 124, 76))
    s.circle(4, 8.5, 3.3, (214, 164, 104))
    s.circle(4, 8.5, 1.4, (160, 110, 64))
    s.outline()
    return s


def icon_stone():
    s = Img(16, 16)
    s.polygon([(3, 12), (2, 8), (5, 4), (10, 4), (13, 8), (12, 12)], (112, 116, 132))
    s.polygon([(4, 10), (3.5, 8), (5.5, 5.5), (9.5, 5.5), (11, 8), (10, 10)], (156, 160, 176))
    s.rect(5, 6, 3, 1, (200, 204, 216))
    s.outline()
    return s


def icon_heart(state):
    s = Img(16, 16)
    for y, row in enumerate(HEART):
        for x, ch in enumerate(row):
            if ch == "X":
                if state == "full" or (state == "half" and x < 5):
                    col = (232, 56, 84)
                else:
                    col = (66, 62, 78)
                s.set(3 + x, 4 + y, col)
    if state != "empty":
        s.set(4, 5, (255, 170, 180))
        s.set(5, 5, (255, 170, 180))
    s.outline()
    return s


def lighter(c, f=1.25):
    return tuple(min(255, int(v * f)) for v in c)


def icon_iron():
    s = Img(16, 16)
    s.polygon([(4, 6), (13, 6), (14, 9), (3, 9)], (206, 214, 234))
    s.rect(3, 9, 11, 4, (130, 138, 162))
    s.rect(3, 9, 11, 1, (168, 176, 200))
    s.rect(5, 7, 5, 1, (240, 244, 255))
    s.outline()
    return s


def icon_meat(cooked):
    s = Img(16, 16)
    c = (160, 96, 56) if cooked else (228, 104, 110)
    s.ellipse(7, 8.5, 5, 4.2, c)
    s.ellipse(5.8, 7, 2.8, 1.8, lighter(c))
    s.rect(11, 7, 3, 2, (240, 236, 224))
    s.circle(14, 7, 1.3, (240, 236, 224))
    s.circle(14, 9, 1.3, (240, 236, 224))
    s.outline()
    return s


def icon_axe():
    s = Img(16, 16)
    s.line(4, 13, 11, 5, 2, (130, 88, 50))
    s.polygon([(8, 3), (13, 2), (14, 6), (11, 8), (9, 6)], (196, 202, 216))
    s.polygon([(11, 8), (14, 6), (13, 8), (11, 9)], (140, 146, 164))
    s.outline()
    return s


def icon_pick():
    s = Img(16, 16)
    s.line(4, 13, 11, 6, 2, (130, 88, 50))
    s.polygon([(2, 7), (5, 3), (10, 2), (14, 5), (12, 6), (9, 4), (6, 5), (4, 8)],
              (192, 198, 214))
    s.outline()
    return s


def icon_sword(blade, edge):
    s = Img(16, 16)
    s.line(13, 2, 6, 9, 2.4, blade)
    s.line(13, 2, 6, 9, 0.9, edge)
    s.line(4, 7, 8, 11, 1.6, (212, 170, 70))
    s.line(6, 9, 3, 12, 2, (130, 88, 50))
    s.set(2, 13, (212, 170, 70))
    s.outline()
    return s


def icon_armor():
    s = Img(16, 16)
    s.polygon([(2, 4), (5, 2), (7, 3), (9, 3), (11, 2), (14, 4), (12, 6),
               (12, 13), (4, 13), (4, 6)], (178, 184, 202))
    s.polygon([(7, 3), (9, 3), (8, 5)], (96, 100, 116))
    s.rect(7, 6, 2, 7, (150, 156, 176))
    s.rect(5, 6, 1, 6, (206, 212, 228))
    s.outline()
    return s


def fx_spark(f):
    s = Img(16, 16)
    if f == 0:
        s.set(8, 8, (255, 255, 255))
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            s.set(8 + dx, 8 + dy, (255, 240, 150))
    elif f == 1:
        for k in (3, 4):
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                s.set(8 + dx * k, 8 + dy * k, (255, 232, 120))
        for k in (2, 3):
            for dx, dy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
                s.set(8 + dx * k, 8 + dy * k, (255, 200, 90))
    else:
        for dx, dy in ((5, 0), (-5, 0), (0, 5), (0, -5), (4, 4), (-4, 4), (4, -4), (-4, -4)):
            s.set(8 + dx, 8 + dy, (255, 170, 70, 220))
    return s


def fx_smoke(f):
    s = Img(16, 16)
    if f == 0:
        s.circle(8, 9, 2.4, (214, 214, 220, 220))
    elif f == 1:
        s.circle(8, 8, 3.8, (204, 204, 210, 170))
    else:
        s.circle(8, 7, 5.6, (196, 196, 204, 100))
    return s


# ============================================================
#  NEW BLOCKS (caves, floors, walls, chest, furnace)
# ============================================================

SPOTS = [(3, 4), (9, 3), (6, 8), (11, 9), (3, 11), (9, 12)]


def mass_base(seed=0):
    rng = random.Random(500 + seed)
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (108, 110, 124))
    for _ in range(22):
        s.set(rng.randrange(16), rng.randrange(16),
              rng.choice([(94, 96, 110), (124, 126, 140), (100, 102, 116)]))
    s.rect(0, 0, 16, 2, (150, 152, 168))
    s.rect(0, 14, 16, 2, (74, 76, 90))
    s.rect(0, 0, 1, 16, (122, 124, 138))
    s.rect(15, 0, 1, 16, (84, 86, 100))
    return s


def tile_ore(main, light, seed):
    s = mass_base(seed)
    for x, y in SPOTS:
        s.rect(x, y, 2, 2, main)
        s.set(x, y, light)
    return s


def tile_iron():
    return tile_ore((214, 150, 112), (250, 210, 172), 1)


def tile_stone_floor():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (148, 150, 162))
    for p in (0, 8):
        s.rect(0, p, 16, 1, (112, 114, 128))
        s.rect(p, 0, 1, 16, (112, 114, 128))
    for x, y in ((3, 3), (11, 5), (5, 11), (12, 12)):
        s.set(x, y, (170, 172, 184))
    return s


def tile_carpet():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (190, 50, 62))
    s.rect(1, 1, 14, 14, (206, 66, 78))
    s.rect(0, 0, 16, 1, (240, 200, 80))
    s.rect(0, 15, 16, 1, (240, 200, 80))
    s.rect(0, 0, 1, 16, (240, 200, 80))
    s.rect(15, 0, 1, 16, (240, 200, 80))
    for x, y in ((4, 4), (11, 4), (4, 11), (11, 11), (8, 8)):
        s.set(x, y, (240, 200, 80))
    return s


def tile_tilefloor():
    s = Img(16, 16)
    for y in range(2):
        for x in range(2):
            c = (228, 230, 236) if (x + y) % 2 == 0 else (160, 170, 190)
            s.rect(x * 8, y * 8, 8, 8, c)
    s.rect(0, 7, 16, 1, (120, 128, 148))
    s.rect(7, 0, 1, 16, (120, 128, 148))
    return s


def tile_cave_floor():
    rng = random.Random(600)
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (58, 58, 72))
    for _ in range(20):
        s.set(rng.randrange(16), rng.randrange(16), rng.choice([(46, 46, 60), (72, 72, 88)]))
    return s


def tile_brick():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (214, 202, 192))
    for r in range(4):
        off = 4 if r % 2 else 0
        for x in range(-4, 16, 8):
            s.rect(max(0, x + off), r * 4, min(7, 16 - max(0, x + off)), 3, (172, 84, 70))
            s.rect(max(0, x + off), r * 4, min(7, 16 - max(0, x + off)), 1, (198, 108, 90))
    return s


def tile_glass():
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, (176, 222, 244, 70))
    for i in range(16):
        s.set(i, 0, (150, 196, 226))
        s.set(i, 15, (150, 196, 226))
        s.set(0, i, (150, 196, 226))
        s.set(15, i, (150, 196, 226))
    for k in range(4, 10):
        s.set(k, 12 - k, (255, 255, 255, 190))
    s.set(11, 5, (255, 255, 255, 190))
    return s


def tile_block(base, light, dark_, seed):
    rng = random.Random(seed)
    s = Img(16, 16)
    s.rect(0, 0, 16, 16, base)
    for _ in range(18):
        s.set(rng.randrange(16), rng.randrange(16), rng.choice([lighter(base, 0.88), lighter(base, 1.12)]))
    s.rect(0, 0, 16, 2, light)
    s.rect(0, 14, 16, 2, dark_)
    s.rect(0, 0, 1, 16, lighter(base, 1.08))
    s.rect(15, 0, 1, 16, dark_)
    return s


def tile_dirtblock():
    return tile_block((124, 86, 54), (160, 116, 76), (84, 56, 34), 700)


def tile_goldblock():
    s = tile_block((244, 200, 56), (255, 236, 130), (186, 138, 24), 701)
    s.rect(4, 4, 8, 8, (252, 216, 80))
    s.rect(4, 4, 8, 1, (255, 244, 170))
    s.rect(4, 11, 8, 1, (200, 150, 30))
    return s


def tile_diamondblock():
    s = tile_block((90, 214, 226), (190, 250, 255), (40, 150, 170), 702)
    s.rect(4, 4, 8, 8, (120, 232, 240))
    s.rect(4, 4, 8, 1, (220, 255, 255))
    s.rect(4, 11, 8, 1, (50, 170, 190))
    return s


def tile_chest():
    s = Img(16, 16)
    s.rect(2, 5, 12, 9, (150, 100, 56))
    s.rect(2, 3, 12, 4, (180, 128, 72))
    s.rect(2, 7, 12, 1, (96, 62, 36))
    s.rect(7, 3, 2, 11, (96, 62, 36))
    s.rect(7, 7, 2, 3, (244, 214, 84))
    s.rect(3, 4, 4, 1, (210, 160, 100))
    s.outline()
    return s


def tile_furnace(lit):
    s = Img(16, 16)
    s.rect(1, 1, 14, 14, (140, 142, 156))
    s.rect(1, 1, 14, 2, (176, 178, 194))
    for y in (6, 11):
        s.rect(1, y, 14, 1, (108, 110, 124))
    s.rect(4, 7, 8, 6, (30, 28, 34))
    if lit:
        c1, c2 = ((255, 150, 40), (255, 220, 90)) if lit == 1 else ((255, 190, 60), (255, 240, 130))
        s.rect(5, 9, 6, 3, c1)
        s.rect(6, 8 if lit == 1 else 9, 4, 3, c2)
    s.outline()
    return s


# ---------- new icons ----------
def icon_coal():
    s = Img(16, 16)
    s.polygon([(3, 11), (2, 7), (5, 4), (10, 4), (13, 7), (12, 11)], (46, 46, 54))
    s.polygon([(4, 9), (4, 7), (6, 5.5), (9, 5.5)], (86, 86, 98))
    s.set(10, 8, (110, 110, 124))
    s.outline()
    return s


def icon_ore(main, light):
    s = Img(16, 16)
    s.polygon([(3, 12), (2, 7), (5, 4), (10, 4), (13, 7), (12, 12)], (112, 116, 132))
    s.polygon([(4, 9), (4, 7), (6, 5.5), (9, 5.5)], (152, 156, 172))
    for x, y in ((5, 8), (9, 7), (7, 10), (10, 10)):
        s.rect(x, y, 2, 2, main)
        s.set(x, y, light)
    s.outline()
    return s


def icon_ingot(top, front, hi):
    s = Img(16, 16)
    s.polygon([(4, 6), (13, 6), (14, 9), (3, 9)], top)
    s.rect(3, 9, 11, 4, front)
    s.rect(3, 9, 11, 1, lighter(front, 1.25))
    s.rect(5, 7, 5, 1, hi)
    s.outline()
    return s


def icon_diamond():
    s = Img(16, 16)
    s.polygon([(3, 6), (6, 3), (10, 3), (13, 6), (8, 14)], (96, 226, 236))
    s.polygon([(3, 6), (13, 6), (8, 14)], (60, 184, 204))
    s.polygon([(6, 3), (7, 6), (5, 6)], (210, 255, 255))
    s.rect(7, 4, 2, 1, (210, 255, 255))
    s.outline()
    return s


def icon_armor_c(main, dark_, light):
    s = Img(16, 16)
    s.polygon([(2, 4), (5, 2), (7, 3), (9, 3), (11, 2), (14, 4), (12, 6),
               (12, 13), (4, 13), (4, 6)], main)
    s.polygon([(7, 3), (9, 3), (8, 5)], dark_)
    s.rect(7, 6, 2, 7, lighter(main, 0.86))
    s.rect(5, 6, 1, 6, light)
    s.outline()
    return s


def icon_shovel():
    s = Img(16, 16)
    s.line(5, 5, 12, 12, 2, (130, 88, 50))
    s.polygon([(2, 2), (6, 1.5), (7.5, 4), (5, 7.5), (2, 5)], (192, 198, 214))
    s.set(3, 3, (236, 240, 250))
    s.outline()
    return s


def icon_rod():
    s = Img(16, 16)
    s.line(2, 14, 12, 3, 1.6, (150, 100, 56))
    s.line(12, 3, 14, 10, 0.7, (240, 240, 250))
    s.circle(14, 11, 1.2, (230, 60, 70))
    s.outline()
    return s


def icon_fish(cooked):
    s = Img(16, 16)
    c = (206, 134, 74) if cooked else (108, 160, 206)
    s.ellipse(7.5, 8, 5, 3.2, c)
    s.polygon([(11, 8), (15, 4.5), (15, 11.5)], lighter(c, 0.85))
    s.rect(4, 9, 6, 1, lighter(c, 1.2))
    s.set(4, 7, (30, 28, 40))
    s.outline()
    return s


def icon_pick_c(head):
    s = Img(16, 16)
    s.line(4, 13, 11, 6, 2, (130, 88, 50))
    s.polygon([(2, 7), (5, 3), (10, 2), (14, 5), (12, 6), (9, 4), (6, 5), (4, 8)], head)
    s.outline()
    return s


def icon_bag():
    s = Img(16, 16)
    s.ellipse(8, 9, 5.5, 5.5, (170, 104, 52))
    s.rect(4, 3, 8, 3, (140, 84, 40))
    s.rect(5, 9, 6, 4, (196, 130, 70))
    s.rect(7, 11, 2, 2, (244, 214, 84))
    s.outline()
    return s


def icon_wool():
    s = Img(16, 16)
    for cx, cy in ((5, 8), (8, 5.5), (11, 8), (8, 9.5), (6, 11), (10, 11)):
        s.circle(cx, cy, 3, (244, 244, 248))
    s.rect(4, 11, 8, 1, (214, 214, 224))
    s.outline()
    return s


def icon_brick():
    s = Img(16, 16)
    s.rect(2, 5, 12, 6, (190, 90, 72))
    s.rect(2, 5, 12, 1, (222, 120, 98))
    s.rect(2, 10, 12, 1, (140, 62, 50))
    s.rect(8, 5, 1, 3, (140, 62, 50))
    s.outline()
    return s


def icon_sound(on):
    s = Img(16, 16)
    s.polygon([(2, 6), (5, 6), (9, 3), (9, 13), (5, 10), (2, 10)], (230, 234, 244))
    if on:
        s.line(11, 6, 12.5, 8, 1, (230, 234, 244))
        s.line(12.5, 8, 11, 10, 1, (230, 234, 244))
        s.line(13, 4.5, 14.5, 8, 1, (230, 234, 244))
        s.line(14.5, 8, 13, 11.5, 1, (230, 234, 244))
    else:
        s.line(11, 6, 15, 11, 1.4, (240, 90, 90))
        s.line(15, 6, 11, 11, 1.4, (240, 90, 90))
    return s


# ============================================================
#  FENCES, GATES, WHEAT
# ============================================================

WOOD, WOOD_D, WOOD_L = (178, 126, 76), (120, 80, 46), (214, 162, 102)


def tile_fence(mask):
    s = Img(16, 16)
    n, e, so, w = mask & 1, mask & 2, mask & 4, mask & 8
    for x0, x1, on in ((8, 16, e), (0, 8, w)):
        if on:
            for y in (5, 10):
                s.rect(x0, y, x1 - x0, 2, WOOD)
                s.rect(x0, y, x1 - x0, 1, WOOD_L)
    if n:
        s.rect(7, 0, 2, 8, WOOD)
        s.rect(7, 0, 1, 8, WOOD_L)
    if so:
        s.rect(7, 8, 2, 8, WOOD)
        s.rect(7, 8, 1, 8, WOOD_L)
    s.rect(6, 2, 4, 12, WOOD)
    s.rect(6, 2, 4, 2, WOOD_L)
    s.rect(9, 4, 1, 10, WOOD_D)
    s.outline()
    return s


def transpose(img):
    t = Img(16, 16)
    for y in range(16):
        for x in range(16):
            t.p[x][y] = img.p[y][x]
    return t


def tile_gate(vertical, opened):
    s = Img(16, 16)
    for x0 in (0, 13):                                       # the two posts
        s.rect(x0, 2, 3, 12, WOOD)
        s.rect(x0, 2, 3, 2, WOOD_L)
        s.rect(x0 + 2, 4, 1, 10, WOOD_D)
    if not opened:
        for y in (5, 10):
            s.rect(3, y, 10, 2, WOOD)
            s.rect(3, y, 10, 1, WOOD_L)
        s.rect(5, 5, 2, 7, WOOD)
        s.rect(9, 5, 2, 7, WOOD)
        s.rect(7, 8, 2, 2, (244, 214, 84))
    else:                                                    # leaf swung open
        s.rect(3, 4, 2, 10, WOOD)
        s.rect(3, 4, 1, 10, WOOD_L)
        s.rect(5, 4, 1, 10, WOOD_D)
        s.rect(3, 12, 3, 2, WOOD_D)
    s.outline()
    return transpose(s) if vertical else s


def tile_wheat(stage):
    s = Img(16, 16)
    crop_soil(s)
    if stage == 0:
        for x in (4, 7, 10):
            s.rect(x, 8, 1, 3, (100, 190, 80))
            s.set(x, 7, (150, 224, 110))
    elif stage == 1:
        for x in (3, 6, 9, 12):
            s.rect(x, 5, 1, 6, (88, 176, 70))
            s.rect(x + 1, 7, 1, 4, (124, 204, 92))
    else:
        for x in (3, 6, 9, 12):
            s.rect(x, 4, 1, 7, (214, 176, 64))
            s.rect(x - 1, 2, 3, 3, (240, 206, 90))
            s.set(x, 1, (252, 230, 140))
            s.set(x + 1, 3, (200, 156, 50))
    s.outline()
    return s


def icon_seeds():
    s = Img(16, 16)
    s.ellipse(8, 10, 5.5, 4, (150, 106, 60))
    s.rect(5, 5, 6, 2, (120, 84, 48))
    for x, y in ((6, 9), (9, 8), (8, 11), (11, 10), (5, 11)):
        s.rect(x, y, 2, 1, (214, 190, 90))
    s.outline()
    return s


def icon_wheat():
    s = Img(16, 16)
    for dx in (-3, 0, 3):
        s.line(8 + dx * 0.4, 14, 8 + dx, 3, 1.2, (214, 176, 64))
        s.circle(8 + dx, 3.5, 1.6, (244, 210, 96))
        s.circle(8 + dx * 0.9, 6, 1.3, (230, 192, 80))
    s.rect(6, 10, 4, 2, (140, 92, 52))
    s.outline()
    return s


def icon_bread():
    s = Img(16, 16)
    s.ellipse(8, 9, 6.2, 3.8, (206, 148, 74))
    s.ellipse(8, 7.8, 5.2, 2.4, (230, 176, 100))
    for x in (5, 8, 11):
        s.line(x - 0.5, 7, x + 0.5, 9.5, 0.8, (170, 112, 50))
    s.outline()
    return s


# ============================================================
#  CROPS + FOOD ICONS
# ============================================================

def crop_soil(s):
    s.rect(2, 11, 12, 4, (112, 74, 44))
    s.rect(2, 11, 12, 1, (142, 98, 60))
    s.rect(3, 13, 10, 1, (88, 56, 34))


def tile_potato(stage):
    s = Img(16, 16)
    crop_soil(s)
    g, gl, gd = (56, 150, 64), (108, 198, 94), (38, 112, 50)
    if stage == 0:
        for x, y in ((7, 10), (8, 10), (7, 9), (8, 9)):
            s.set(x, y, g)
        s.set(6, 9, gl)
        s.set(9, 9, gl)
    elif stage == 1:
        s.rect(7, 7, 2, 4, g)
        s.circle(5.5, 8.2, 2.2, g)
        s.circle(10.5, 8.2, 2.2, g)
        s.circle(8, 6, 2.4, gl)
    else:
        s.circle(8, 6.5, 4.2, gd)
        s.circle(5, 8.5, 2.6, g)
        s.circle(11, 8.5, 2.6, g)
        s.circle(7.5, 5.5, 2.6, gl)
        s.set(7, 3, (255, 255, 255))
        s.set(10, 5, (255, 255, 255))
        s.ellipse(5, 12.2, 2.3, 1.6, (208, 162, 106))
        s.ellipse(10.8, 12.4, 2.5, 1.7, (190, 144, 92))
        s.set(4, 12, (150, 108, 70))
        s.set(11, 12, (150, 108, 70))
    s.outline()
    return s


def tile_radish(stage):
    s = Img(16, 16)
    crop_soil(s)
    g, gl = (92, 178, 80), (140, 214, 110)
    if stage == 0:
        for x, y in ((7, 10), (8, 10), (7, 9), (8, 9)):
            s.set(x, y, g)
        s.set(6, 9, gl)
        s.set(9, 9, gl)
    elif stage == 1:
        s.line(8, 11, 5, 5, 1.6, g)
        s.line(8, 11, 8, 4, 1.6, gl)
        s.line(8, 11, 11, 5, 1.6, g)
    else:
        s.line(8, 11, 4, 4, 2, g)
        s.line(8, 11, 8, 2.5, 2, gl)
        s.line(8, 11, 12, 4, 2, g)
        s.circle(5.8, 12, 1.9, (222, 60, 96))
        s.circle(10.4, 12.2, 2.1, (230, 70, 104))
        s.set(5, 11, (250, 150, 170))
        s.set(10, 11, (250, 150, 170))
    s.outline()
    return s


def icon_hunger(state):
    s = Img(16, 16)
    for x in range(16):
        pass
    full = (214, 126, 64)
    empty = (70, 66, 78)
    if state == "half":
        left = Img(16, 16)
        left.ellipse(6.5, 6.5, 4.0, 3.5, full)
        right = Img(16, 16)
        right.ellipse(6.5, 6.5, 4.0, 3.5, empty)
        for y in range(16):
            for x in range(16):
                src = left if x < 7 else right
                if src.p[y][x][3]:
                    s.p[y][x] = src.p[y][x]
    else:
        s.ellipse(6.5, 6.5, 4.0, 3.5, full if state == "full" else empty)
    bone = (240, 236, 224) if state != "empty" else (110, 108, 120)
    s.line(9, 9, 12.5, 12.5, 1.6, bone)
    s.circle(12.5, 12.8, 1.4, bone)
    s.circle(13.4, 11.8, 1.1, bone)
    if state != "empty":
        s.set(4, 4, (248, 176, 112))
        s.set(5, 4, (248, 176, 112))
    s.outline()
    return s


def icon_potato(baked):
    s = Img(16, 16)
    c = (190, 128, 56) if baked else (214, 176, 120)
    s.ellipse(8, 8.5, 5.4, 4.2, c)
    s.ellipse(6.4, 7, 2.6, 1.5, lighter(c))
    if baked:
        s.ellipse(8, 6.6, 3.4, 1.3, (255, 238, 150))
        s.set(7, 6, (255, 252, 210))
        s.set(9, 6, (255, 252, 210))
    else:
        s.set(10, 9, (150, 108, 70))
        s.set(6, 10, (150, 108, 70))
        s.set(11, 7, (150, 108, 70))
    s.outline()
    return s


def icon_radish():
    s = Img(16, 16)
    s.polygon([(8, 5.5), (11.5, 7), (10.5, 11.5), (8, 14.5), (5.5, 11.5), (4.5, 7)],
              (224, 62, 100))
    s.polygon([(6.5, 7), (7.5, 6.2), (7, 9), (6, 9)], (250, 150, 172))
    s.line(8, 13, 8, 15, 1.2, (250, 244, 236))
    s.line(8, 5.5, 5, 1.5, 1.6, (96, 184, 84))
    s.line(8, 5.5, 8, 1, 1.6, (140, 214, 110))
    s.line(8, 5.5, 11, 1.5, 1.6, (96, 184, 84))
    s.outline()
    return s


# ============================================================
#  MOBS  (16 x 16)
# ============================================================

EYE = (34, 28, 40)


def pig_img(view, step):
    s = Img(16, 16)
    P, D, L = (242, 162, 174), (216, 122, 140), (228, 142, 158)
    if view == "side":
        for x in ((3, 8) if step == 0 else (4, 7)):
            s.rect(x, 12, 2, 3, D)
        s.rect(2, 6, 9, 7, P)
        s.rect(2, 11, 9, 2, L)
        s.rect(9, 5, 5, 6, P)
        s.rect(13, 8, 2, 3, D)
        s.set(14, 9, (150, 70, 90))
        s.rect(10, 4, 2, 2, D)
        s.set(11, 7, EYE)
        s.set(1, 7, D)
    else:
        s.rect(5, 12, 2, 3 if step == 0 else 2, D)
        s.rect(9, 12, 2, 2 if step == 0 else 3, D)
        s.rect(4, 6, 8, 7, P)
        s.rect(4, 11, 8, 2, L)
        s.rect(4, 2, 8, 7, P)
        s.rect(4, 1, 2, 2, D)
        s.rect(10, 1, 2, 2, D)
        s.rect(6, 5, 4, 3, D)
        s.set(7, 6, (150, 70, 90))
        s.set(8, 6, (150, 70, 90))
        s.set(5, 4, EYE)
        s.set(10, 4, EYE)
    return s


def sheep_img(view, step):
    s = Img(16, 16)
    Wl, Sh, Hd = (244, 244, 244), (214, 214, 222), (72, 68, 76)
    if view == "side":
        for x in ((4, 9) if step == 0 else (5, 8)):
            s.rect(x, 12, 2, 3, Hd)
        s.ellipse(7.5, 8.5, 6.2, 4.6, Wl)
        s.circle(4, 5.5, 2.4, Wl)
        s.circle(8, 4.8, 2.6, Wl)
        s.circle(11, 6.5, 2.2, Wl)
        s.rect(3, 11, 9, 1, Sh)
        s.rect(11, 6, 4, 5, Hd)
        s.rect(11, 5, 2, 1, Wl)
        s.set(13, 8, (230, 230, 230))
    else:
        s.rect(5, 12, 2, 3 if step == 0 else 2, Hd)
        s.rect(9, 12, 2, 2 if step == 0 else 3, Hd)
        s.ellipse(8, 9, 5.6, 4.6, Wl)
        s.rect(4, 11, 8, 1, Sh)
        s.rect(5, 2, 6, 6, Hd)
        s.rect(5, 1, 6, 2, Wl)
        s.set(6, 5, (230, 230, 230))
        s.set(9, 5, (230, 230, 230))
    return s


def cow_img(view, step):
    s = Img(16, 16)
    Wc, K, Pk, Hn = (244, 244, 244), (46, 46, 52), (240, 170, 180), (236, 224, 170)
    if view == "side":
        for x in ((3, 9) if step == 0 else (4, 8)):
            s.rect(x, 12, 2, 3, (70, 62, 60))
        s.rect(2, 5, 10, 8, Wc)
        s.rect(4, 6, 3, 3, K)
        s.rect(9, 8, 2, 4, K)
        s.rect(6, 12, 3, 1, Pk)
        s.rect(11, 4, 4, 6, Wc)
        s.rect(12, 4, 3, 2, K)
        s.rect(11, 3, 1, 2, Hn)
        s.rect(14, 3, 1, 2, Hn)
        s.rect(13, 8, 2, 2, Pk)
        s.set(12, 6, EYE)
        s.set(1, 6, K)
    else:
        s.rect(4, 12, 2, 3 if step == 0 else 2, (70, 62, 60))
        s.rect(10, 12, 2, 2 if step == 0 else 3, (70, 62, 60))
        s.rect(3, 6, 10, 7, Wc)
        s.rect(4, 7, 3, 3, K)
        s.rect(10, 9, 2, 3, K)
        s.rect(4, 2, 8, 7, Wc)
        s.rect(4, 2, 3, 2, K)
        s.rect(3, 1, 1, 2, Hn)
        s.rect(12, 1, 1, 2, Hn)
        s.rect(5, 6, 6, 3, Pk)
        s.set(6, 7, (150, 80, 96))
        s.set(9, 7, (150, 80, 96))
        s.set(5, 4, EYE)
        s.set(10, 4, EYE)
    return s


def chicken_img(view, step):
    s = Img(16, 16)
    Wh, Sh, Rd, Or = (250, 250, 250), (220, 220, 226), (216, 50, 60), (240, 170, 50)
    if view == "side":
        s.rect(6 if step == 0 else 7, 12, 1, 3, Or)
        s.rect(9 if step == 0 else 8, 12, 1, 3, Or)
        s.ellipse(7.5, 9, 4.6, 3.6, Wh)
        s.rect(3, 6, 2, 4, Wh)
        s.rect(4, 10, 7, 1, Sh)
        s.rect(10, 4, 4, 4, Wh)
        s.rect(13, 6, 2, 1, Or)
        s.rect(11, 3, 2, 1, Rd)
        s.set(12, 8, Rd)
        s.set(12, 5, EYE)
    else:
        s.rect(6 if step == 0 else 5, 12, 1, 3, Or)
        s.rect(9 if step == 0 else 10, 12, 1, 3, Or)
        s.ellipse(8, 9, 4, 3.6, Wh)
        s.rect(5, 10, 6, 1, Sh)
        s.rect(6, 3, 4, 4, Wh)
        s.rect(7, 2, 2, 1, Rd)
        s.rect(7, 6, 2, 1, Or)
        s.set(6, 4, EYE)
        s.set(9, 4, EYE)
    return s


def spider_img(f):
    s = Img(16, 16)
    leg = (30, 24, 36)
    ends = [(1, 4), (0, 8), (1, 12), (3, 14)] if f == 0 else [(2, 5), (1, 9), (2, 13), (4, 14)]
    starts = [(6, 6.5), (5.5, 8), (5.5, 9.5), (6.5, 10.5)]
    for (ex, ey), (sx, sy) in zip(ends, starts):
        s.line(sx, sy, ex, ey, 1.2, leg)
        s.line(15.99 - sx, sy, 15.99 - ex, ey, 1.2, leg)
    s.ellipse(8, 9.5, 3.8, 3.4, (52, 42, 60))
    s.ellipse(8, 8.5, 1.8, 1.1, (76, 64, 88))
    s.rect(7, 10, 2, 2, (196, 40, 60))
    s.ellipse(8, 5.5, 2.5, 2.3, (38, 32, 46))
    s.set(7, 5, (255, 70, 70))
    s.set(9, 5, (255, 70, 70))
    return s


def ghost_img(f):
    s = Img(16, 16)
    col = (238, 244, 255, 235)
    s.ellipse(8, 7, 5.2, 5.4, col)
    s.rect(3, 7, 10, 6, col)
    for x in range(3, 13):
        if ((x + f * 2) // 2) % 2 == 0:
            s.set(x, 13, col)
    s.rect(11, 8, 2, 5, (206, 216, 240, 235))
    s.rect(6, 6, 1, 3, (30, 30, 56))
    s.rect(9, 6, 1, 3, (30, 30, 56))
    s.rect(7, 10, 2, 1, (60, 60, 96))
    s.outline((112, 126, 186))
    return s


# ============================================================
#  BUILD EVERYTHING
# ============================================================

ARMOR_PAL = dict(skin=(250, 208, 168), hair=(150, 156, 172), shirt=(178, 184, 202),
                 pants=(98, 102, 120), shoe=(60, 60, 72), eye=(30, 24, 40))


GOLD_PAL = dict(skin=(250, 208, 168), hair=(240, 196, 60), shirt=(246, 204, 70),
                pants=(196, 146, 40), shoe=(120, 84, 30), eye=(30, 24, 40))
DIAMOND_PAL = dict(skin=(250, 208, 168), hair=(80, 214, 226), shirt=(104, 226, 236),
                   pants=(44, 150, 176), shoe=(30, 100, 124), eye=(30, 24, 40))


def generate(folder):
    os.makedirs(folder, exist_ok=True)

    tiles = [tile_grass(0), tile_grass(1), tile_grass(2), tile_grass(3),
             tile_water(0), tile_water(1), tile_sand(0), tile_sand(1),
             tile_floor(), tile_dirt(),
             tile_tree(), tile_rock(), tile_wall(), tile_stone_wall(), tile_door(),
             tile_bed(), tile_fire(0), tile_fire(1), tile_fire(2), tile_fire(3),
             tile_iron(), tile_table(),
             tile_torch(0), tile_torch(1), tile_torch(2), tile_torch(3),
             tile_potato(0), tile_potato(1), tile_potato(2),
             tile_radish(0), tile_radish(1), tile_radish(2),
             tile_stone_floor(), tile_carpet(), tile_tilefloor(), tile_cave_floor(),
             tile_brick(), tile_glass(), tile_dirtblock(), tile_goldblock(),
             tile_diamondblock(), tile_chest(), tile_furnace(0), tile_furnace(1),
             tile_furnace(2), mass_base(0),
             tile_ore((40, 40, 48), (90, 90, 104), 2),
             tile_ore((250, 206, 56), (255, 244, 150), 3),
             tile_ore((84, 228, 236), (210, 255, 255), 4)]
    tiles += [tile_fence(m) for m in range(16)]
    tiles += [tile_gate(False, False), tile_gate(False, True),
              tile_gate(True, False), tile_gate(True, True)]
    tiles += [tile_wheat(0), tile_wheat(1), tile_wheat(2)]
    sheet = Img(160, 128)
    for i, t in enumerate(tiles):
        sheet.blit(t, (i % 10) * 16, (i // 10) * 16)
    sheet.save(os.path.join(folder, "tiles.png"))

    make_char_sheet(PLAYER_PAL).save(os.path.join(folder, "player.png"))
    make_char_sheet(ARMOR_PAL).save(os.path.join(folder, "player_armor.png"))
    make_char_sheet(GOLD_PAL).save(os.path.join(folder, "player_gold.png"))
    make_char_sheet(DIAMOND_PAL).save(os.path.join(folder, "player_diamond.png"))
    make_char_sheet(ZOMBIE_PAL, True).save(os.path.join(folder, "zombie.png"))

    animals = Img(64, 64)
    for r, fn in enumerate((pig_img, sheep_img, cow_img, chicken_img)):
        for c, (view, step) in enumerate((("side", 0), ("side", 1),
                                          ("front", 0), ("front", 1))):
            im = fn(view, step)
            im.outline()
            animals.blit(im, c * 16, r * 16)
    animals.save(os.path.join(folder, "animals.png"))

    sp = Img(32, 16)
    gh = Img(32, 16)
    for f in range(2):
        sp.blit(spider_img(f), f * 16, 0)
        gh.blit(ghost_img(f), f * 16, 0)
    sp.save(os.path.join(folder, "spider.png"))
    gh.save(os.path.join(folder, "ghost.png"))

    # items.png cells (16x16, 8 per row):
    # 0 wood 1 stone 2 heart 3 heart-empty 4 iron 5 meat 6 cooked 7 axe
    # 8 pickaxe 9 sword 10 iron-sword 11 armor 12 heart-half
    # 13 hunger-full 14 hunger-empty 15 hunger-half 16 potato 17 baked-potato 18 radish
    # 19 coal 20 iron-ore 21 gold-ore 22 gold-ingot 23 diamond 24 gold-armor 25 diamond-armor
    # 26 shovel 27 rod 28 fish 29 cooked-fish 30 iron-pickaxe 31 diamond-sword 32 bag 33 wool
    # 34 brick 35 sound-on 36 sound-off 37 seeds 38 wheat 39 bread
    icons = [icon_wood(), icon_stone(), icon_heart("full"), icon_heart("empty"),
             icon_iron(), icon_meat(False), icon_meat(True), icon_axe(),
             icon_pick(), icon_sword((176, 180, 190), (222, 226, 236)),
             icon_sword((196, 224, 255), (250, 252, 255)), icon_armor(),
             icon_heart("half"),
             icon_hunger("full"), icon_hunger("empty"), icon_hunger("half"),
             icon_potato(False), icon_potato(True), icon_radish(),
             icon_coal(), icon_ore((214, 150, 112), (250, 210, 172)),
             icon_ore((250, 206, 56), (255, 244, 150)),
             icon_ingot((250, 220, 90), (214, 160, 40), (255, 246, 190)),
             icon_diamond(),
             icon_armor_c((246, 204, 70), (150, 110, 30), (255, 240, 160)),
             icon_armor_c((104, 226, 236), (30, 120, 140), (220, 255, 255)),
             icon_shovel(), icon_rod(), icon_fish(False), icon_fish(True),
             icon_pick_c((150, 200, 240)),
             icon_sword((110, 228, 240), (230, 255, 255)),
             icon_bag(), icon_wool(), icon_brick(),
             icon_sound(True), icon_sound(False),
             icon_seeds(), icon_wheat(), icon_bread()]
    items = Img(128, 80)
    for i, ic in enumerate(icons):
        items.blit(ic, (i % 8) * 16, (i // 8) * 16)
    items.save(os.path.join(folder, "items.png"))

    fx = Img(96, 16)
    for i in range(3):
        fx.blit(fx_spark(i), i * 16, 0)
        fx.blit(fx_smoke(i), (i + 3) * 16, 0)
    fx.save(os.path.join(folder, "fx.png"))
    print("Assets saved to", folder)


# ============================================================
#  SOUNDS  (tiny synthesizer -> .wav files)
# ============================================================

SR = 22050


def _env(n, decay):
    return [math.exp(-decay * i / SR) for i in range(n)]


def tone(freq, dur, vol=0.5, decay=8.0, f1=None, square=False):
    n = int(SR * dur)
    f1 = freq if f1 is None else f1
    out, ph = [], 0.0
    for i in range(n):
        ph += 2 * math.pi * (freq + (f1 - freq) * i / n) / SR
        v = math.sin(ph)
        if square:
            v = 1.0 if v > 0 else -1.0
        out.append(v * vol * math.exp(-decay * i / SR))
    return out


def noise(dur, vol=0.5, decay=20.0, smooth=0.0, seed=1):
    rng = random.Random(seed)
    n, prev, out = int(SR * dur), 0.0, []
    for i in range(n):
        x = rng.uniform(-1, 1)
        prev = prev * smooth + x * (1 - smooth)
        out.append(prev * vol * math.exp(-decay * i / SR))
    return out


def mix(*parts):
    n = max(len(p) for p in parts)
    return [sum(p[i] for p in parts if i < len(p)) for i in range(n)]


def delay(samples, sec):
    return [0.0] * int(SR * sec) + samples


def write_wav(path, samples):
    data = b"".join(struct.pack("<h", int(max(-1.0, min(1.0, v)) * 32000)) for v in samples)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data)


SOUND_NAMES = ["chop", "mine", "hit", "hurt", "eat", "place", "craft", "pickup",
               "splash", "bite", "click", "death", "zombie", "sleep", "rain", "open"]


def make_sound(name):
    if name == "chop":
        return mix(noise(0.12, 0.6, 28, 0.5), tone(150, 0.12, 0.6, 22, 90))
    if name == "mine":
        return mix(noise(0.07, 0.5, 40, 0.1), tone(1100, 0.06, 0.4, 50, 700))
    if name == "hit":
        return mix(noise(0.1, 0.5, 30, 0.3), tone(260, 0.14, 0.5, 20, 110))
    if name == "hurt":
        return tone(420, 0.28, 0.55, 7, 150, square=True)
    if name == "eat":
        return mix(noise(0.05, 0.5, 40, 0.6, 2), delay(noise(0.05, 0.5, 40, 0.6, 3), 0.09),
                   delay(noise(0.05, 0.5, 40, 0.6, 4), 0.18))
    if name == "place":
        return mix(tone(190, 0.1, 0.55, 22, 120), noise(0.08, 0.35, 35, 0.6))
    if name == "craft":
        return mix(tone(660, 0.18, 0.4, 9), delay(tone(880, 0.25, 0.4, 7), 0.1))
    if name == "pickup":
        return tone(520, 0.12, 0.4, 12, 980)
    if name == "splash":
        return mix(noise(0.35, 0.5, 8, 0.7), tone(300, 0.2, 0.2, 14, 120))
    if name == "bite":
        return mix(tone(1250, 0.09, 0.5, 14), delay(tone(1250, 0.09, 0.5, 14), 0.12))
    if name == "click":
        return tone(760, 0.035, 0.4, 60)
    if name == "death":
        return tone(420, 0.9, 0.55, 3, 50, square=True)
    if name == "zombie":
        return mix(tone(115, 0.7, 0.45, 3, 80, square=True), noise(0.7, 0.2, 4, 0.8, 9))
    if name == "sleep":
        return mix(tone(330, 0.6, 0.3, 4), delay(tone(262, 0.7, 0.3, 4), 0.25))
    if name == "open":
        return mix(tone(240, 0.12, 0.4, 14, 360), noise(0.06, 0.3, 40, 0.5))
    if name == "rain":                                   # 2 second loop
        return noise(2.0, 0.22, 0.0, 0.82, 5)
    return tone(440, 0.1)


def generate_sounds(folder):
    """Create any missing default sound. Put your own .ogg/.wav/.mp3 with the
    same name in this folder and the game uses yours instead."""
    os.makedirs(folder, exist_ok=True)
    for name in SOUND_NAMES:
        path = os.path.join(folder, name + ".wav")
        have = any(os.path.exists(os.path.join(folder, name + e)) for e in (".ogg", ".mp3", ".wav"))
        if not have:
            write_wav(path, make_sound(name))
    print("Sounds ready in", folder)


if __name__ == "__main__":
    _here = os.path.dirname(os.path.abspath(__file__))
    generate(os.path.join(_here, "assets"))
    generate_sounds(os.path.join(_here, "sounds"))
