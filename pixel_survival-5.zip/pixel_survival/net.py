# net.py  -  tiny LAN / Wi-Fi hotspot multiplayer layer for Pixel Survival
#
#   Host   : TCP server (port 5555). The host phone runs the whole world.
#   Client : connects to the host IP (typed in, or found automatically).
#   Finder : listens for the host's UDP "I am here" broadcast (port 5556).
#
# Messages are JSON, one per line.  Everything is non-blocking, so the game loop
# never freezes because of the network.

import json
import socket
import threading
import time

PORT = 5555
DISC_PORT = 5556
MAGIC = "PXSURV1"
VERSION = 1
MAX_CLIENTS = 3                  # host + 3 friends = 4 players
_WOULD_BLOCK = (BlockingIOError, InterruptedError)


# ------------------------------------------------------------
#  finding this device's IP address
# ------------------------------------------------------------
def local_ips():
    """Best guess list of this device's LAN / hotspot IPv4 addresses."""
    found = []

    def add(ip):
        if (ip and ip not in found and not ip.startswith("127.")
                and not ip.startswith("169.254.") and ip != "0.0.0.0"):
            found.append(ip)

    for target in (("8.8.8.8", 80), ("192.168.43.255", 1), ("192.168.0.255", 1),
                   ("10.255.255.255", 1)):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(target)
            add(s.getsockname()[0])
            s.close()
        except OSError:
            pass
    try:                                           # Linux / Android interface query
        import fcntl
        import struct
        for ifname in ("wlan0", "wlan1", "ap0", "swlan0", "softap0", "eth0", "rndis0"):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                packed = struct.pack("256s", ifname.encode()[:15])
                add(socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, packed)[20:24]))
                s.close()
            except OSError:
                pass
    except ImportError:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            add(ip)
    except OSError:
        pass
    return found or ["192.168.43.1"]


# ------------------------------------------------------------
#  one TCP connection with line framing
# ------------------------------------------------------------
class Conn:
    def __init__(self, sock):
        sock.setblocking(False)
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        self.sock = sock
        self.buf = b""
        self.out = b""
        self.dead = False

    def send(self, msg):
        if self.dead:
            return
        self.out += (json.dumps(msg, separators=(",", ":")) + "\n").encode()
        self.flush()

    def flush(self):
        if self.out and not self.dead:
            try:
                n = self.sock.send(self.out)
                self.out = self.out[n:]
            except _WOULD_BLOCK:
                pass
            except OSError:
                self.dead = True
        if len(self.out) > 3000000:                # far too slow, give up
            self.dead = True

    def backlog(self):
        return len(self.out)

    def poll(self):
        msgs = []
        if self.dead:
            return msgs
        self.flush()
        try:
            while True:
                data = self.sock.recv(65536)
                if not data:
                    self.dead = True
                    break
                self.buf += data
        except _WOULD_BLOCK:
            pass
        except OSError:
            self.dead = True
        if b"\n" in self.buf:
            parts = self.buf.split(b"\n")
            self.buf = parts.pop()
            for line in parts:
                if line:
                    try:
                        obj = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(obj, dict):
                        msgs.append(obj)
        if len(self.buf) > 4000000:
            self.dead = True
        return msgs

    def close(self):
        self.dead = True
        try:
            self.sock.close()
        except OSError:
            pass


# ------------------------------------------------------------
#  HOST
# ------------------------------------------------------------
class Host:
    def __init__(self, label="World"):
        self.label = label
        self.srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("", PORT))                  # OSError if the port is taken
        self.srv.listen(8)
        self.srv.setblocking(False)
        self.conns = {}                            # client id -> Conn
        self.dropped = []                          # ids that just disconnected
        self.ips = local_ips()
        self.beacon_t = 0.0
        self.udp = None
        try:
            self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.udp.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            self.udp.setblocking(False)
        except OSError:
            self.udp = None
        self.targets = ["255.255.255.255"]
        for ip in self.ips:
            parts = ip.split(".")
            if len(parts) == 4:
                self.targets.append(".".join(parts[:3] + ["255"]))

    def accept(self):
        """Accept new TCP clients. Returns the id of a newly accepted client (or None)."""
        try:
            sock, _addr = self.srv.accept()
        except _WOULD_BLOCK:
            return None
        except OSError:
            return None
        conn = Conn(sock)
        for cid in range(1, MAX_CLIENTS + 1):
            if cid not in self.conns:
                self.conns[cid] = conn
                return cid
        conn.send({"t": "full"})
        conn.close()
        return None

    def poll(self):
        """-> list of (client id, message). Dead clients go to self.dropped."""
        out = []
        for cid, conn in list(self.conns.items()):
            for m in conn.poll():
                out.append((cid, m))
            if conn.dead:
                conn.close()
                del self.conns[cid]
                self.dropped.append(cid)
        return out

    def send(self, cid, msg):
        c = self.conns.get(cid)
        if c:
            c.send(msg)

    def broadcast(self, msg, exclude=None):
        for cid, c in self.conns.items():
            if cid != exclude:
                c.send(msg)

    def backlog(self, cid):
        c = self.conns.get(cid)
        return c.backlog() if c else 0

    def beacon(self, dt, players):
        self.beacon_t -= dt
        if self.beacon_t > 0 or not self.udp:
            return
        self.beacon_t = 1.0
        data = f"{MAGIC}|{self.label}|{PORT}|{players}".encode()
        for t in self.targets:
            try:
                self.udp.sendto(data, (t, DISC_PORT))
            except OSError:
                pass

    def close(self):
        for c in self.conns.values():
            c.send({"t": "kick"})
            c.flush()
            c.close()
        self.conns.clear()
        for s in (self.srv, self.udp):
            try:
                if s:
                    s.close()
            except OSError:
                pass


# ------------------------------------------------------------
#  CLIENT
# ------------------------------------------------------------
class Client:
    """Connects in a background thread so the menu never freezes."""

    def __init__(self, ip):
        self.ip = ip.strip()
        self.state = "connecting"                  # connecting / connected / failed
        self.err = ""
        self.conn = None
        self.inbox = []
        self.welcome = None
        self.cancelled = False
        self.dead = False
        threading.Thread(target=self._connect, daemon=True).start()

    def _connect(self):
        try:
            sock = socket.create_connection((self.ip, PORT), timeout=5)
        except (OSError, ValueError) as e:
            self.state, self.err = "failed", "Could not reach " + self.ip
            return
        if self.cancelled:
            sock.close()
            return
        self.conn = Conn(sock)
        self.conn.send({"t": "hello", "v": VERSION})
        self.state = "connected"

    def pump(self):
        """Read the network. Fills self.inbox; catches the welcome message."""
        if self.conn:
            msgs = self.conn.poll()
            if self.conn.dead:
                self.dead = True
            for m in msgs:
                t = m.get("t")
                if t == "full":
                    self.state, self.err = "failed", "The game is full"
                elif t == "kick":
                    self.state, self.err = "failed", "The host closed the game"
                elif t == "welcome" and self.welcome is None:
                    self.welcome = m
                else:
                    self.inbox.append(m)
            if self.dead and self.welcome is None and self.state == "connected":
                self.state, self.err = "failed", "Connection lost"

    def take(self):
        msgs, self.inbox = self.inbox, []
        return msgs

    def poll(self):
        self.pump()
        return self.take()

    def send(self, msg):
        if self.conn:
            self.conn.send(msg)

    def close(self):
        self.cancelled = True
        if self.conn:
            self.conn.send({"t": "bye"})
            self.conn.flush()
            self.conn.close()


# ------------------------------------------------------------
#  Finder: shows games announced on the Wi-Fi
# ------------------------------------------------------------
class Finder:
    def __init__(self):
        self.found = {}                            # ip -> (label, players, last seen)
        self.sock = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            s.bind(("", DISC_PORT))
            s.setblocking(False)
            self.sock = s
        except OSError:
            self.sock = None

    def poll(self):
        if not self.sock:
            return
        try:
            while True:
                data, addr = self.sock.recvfrom(512)
                parts = data.decode("utf-8", "ignore").split("|")
                if len(parts) >= 4 and parts[0] == MAGIC:
                    self.found[addr[0]] = (parts[1][:20], parts[3][:2], time.time())
        except _WOULD_BLOCK:
            pass
        except OSError:
            pass

    def games(self):
        now = time.time()
        self.found = {ip: v for ip, v in self.found.items() if now - v[2] < 4.0}
        return [(ip, v[0], v[1]) for ip, v in sorted(self.found.items())][:4]

    def close(self):
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass
        self.sock = None
