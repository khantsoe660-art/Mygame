# PIXEL SURVIVAL - game data (no pygame needed here)
# Items, recipes, mobs, constants and the world / cave generator.

import math
import random

# ============================================================
#  SETTINGS
# ============================================================

T = 16                      # tile size
MAP = 80                    # world is MAP x MAP tiles
W, H = 384, 216             # internal resolution
FPS = 60
SEED = 2024

PLAYER_SPEED = 62
TIME_RATE = 0.10            # in-game hours per real second (240 s = 1 day)
START_TIME = 8.0
MAXHP = 20                  # 20 half-hearts = 10 hearts
MAXFOOD = 20                # 20 points = 10 drumsticks
HUNGER_RATE = 1 / 14        # hunger points lost per second
STAGE_TIME = 45.0           # seconds per crop growth stage (x2 in rain)
REGROW_MIN, REGROW_MAX = 150.0, 300.0     # trees / rocks grow back after this
INV_SIZE = 36               # 9 hotbar + 27 backpack
SMELT_TIME = 5.0

# ground types
G_GRASS, G_WATER, G_SAND, G_DIRT, G_CAVE = 0, 1, 2, 3, 4

# objects (things standing on a tile)
(O_TREE, O_ROCK, O_WALL, O_STONE, O_DOOR, O_BED, O_FIRE,
 O_IRON, O_TABLE, O_TORCH) = range(1, 11)
O_POT0, O_POT1, O_POT2, O_RAD0, O_RAD1, O_RAD2 = 11, 12, 13, 14, 15, 16
(O_BRICK, O_GLASS, O_DIRT, O_GOLDBLK, O_DIAMONDBLK, O_CHEST, O_FURNACE,
 O_MASS, O_COAL, O_GOLD, O_DIAMOND) = range(17, 28)
O_FENCE, O_GATE, O_GATE_OPEN = 28, 29, 30
O_WHT0, O_WHT1, O_WHT2 = 31, 32, 33

SOLID_OBJ = {O_TREE, O_ROCK, O_WALL, O_STONE, O_BED, O_FIRE, O_IRON, O_TABLE,
             O_BRICK, O_GLASS, O_DIRT, O_GOLDBLK, O_DIAMONDBLK, O_CHEST,
             O_FURNACE, O_MASS, O_COAL, O_GOLD, O_DIAMOND, O_FENCE, O_GATE}
ANIMAL_SOLID = {O_DOOR}                 # animals don't walk through doors
HOSTILE_SOLID = {O_DOOR, O_GATE_OPEN}   # monsters can't open doors / gates
OBJ_TILE = {O_TREE: 10, O_ROCK: 11, O_WALL: 12, O_STONE: 13, O_DOOR: 14,
            O_BED: 15, O_FIRE: 16, O_IRON: 20, O_TABLE: 21, O_TORCH: 22,
            O_POT0: 26, O_POT1: 27, O_POT2: 28, O_RAD0: 29, O_RAD1: 30, O_RAD2: 31,
            O_BRICK: 36, O_GLASS: 37, O_DIRT: 38, O_GOLDBLK: 39, O_DIAMONDBLK: 40,
            O_CHEST: 41, O_FURNACE: 42, O_MASS: 45, O_COAL: 46, O_GOLD: 47,
            O_DIAMOND: 48, O_FENCE: 49, O_GATE: 65, O_GATE_OPEN: 66,
            O_WHT0: 69, O_WHT1: 70, O_WHT2: 71}
FLOOR_TILE = {1: 8, 2: 32, 3: 33, 4: 34}             # floor id -> tile index
# light objects: (ghost repel radius, light sprite radii)
LIGHT = {O_FIRE: (64, (70, 80)), O_TORCH: (44, (36, 40))}
FURNACE_LIGHT = (40, (36, 40))
DV = {0: (0, 1), 1: (-1, 0), 2: (1, 0), 3: (0, -1)}   # facing -> vector

# crop object id -> (item, first-stage id, stage 0..2)
CROP_INFO = {O_POT0: ("potato", O_POT0, 0), O_POT1: ("potato", O_POT0, 1),
             O_POT2: ("potato", O_POT0, 2), O_RAD0: ("radish", O_RAD0, 0),
             O_RAD1: ("radish", O_RAD0, 1), O_RAD2: ("radish", O_RAD0, 2),
             O_WHT0: ("wheat", O_WHT0, 0), O_WHT1: ("wheat", O_WHT0, 1),
             O_WHT2: ("wheat", O_WHT0, 2)}
# what a ripe crop gives: (item, min, max)
CROP_DROPS = {"potato": [("potato", 2, 3)], "radish": [("radish", 2, 3)],
              "wheat": [("wheat", 1, 2), ("seeds", 1, 3)]}
PLANTABLE = {"potato", "radish", "seeds"}

# resource object -> (hp, drop item, (min, max), pickaxe tier needed, tool)
RES = {
    O_TREE: (3, "wood", (2, 3), 0, "axe"),
    O_ROCK: (4, "stone", (1, 3), 0, "pick"),
    O_MASS: (5, "stone", (1, 1), 1, "pick"),
    O_COAL: (5, "coal", (1, 2), 1, "pick"),
    O_IRON: (6, "iron_ore", (1, 1), 1, "pick"),
    O_GOLD: (7, "gold_ore", (1, 1), 2, "pick"),
    O_DIAMOND: (9, "diamond", (1, 2), 2, "pick"),
}
CAVE_OBJS = {O_MASS, O_COAL, O_IRON, O_GOLD, O_DIAMOND}   # mined -> cave floor
TOOL_TIER = {"pick": 1, "ipick": 2}
TOOL_DMG = {"sword": 2, "isword": 3, "dsword": 5, "axe": 2, "pick": 2, "ipick": 2}
# damage against MONSTERS (swords hit them much harder)
TOOL_DMG_HOSTILE = {"sword": 4, "isword": 6, "dsword": 9, "axe": 3, "pick": 2, "ipick": 2}
SWORDS = {"sword", "isword", "dsword"}
HAND_ITEMS = {"axe", "pick", "ipick", "shovel", "sword", "isword", "dsword", "rod"}
ARMOR_MULT = {"garmor": 0.62, "iarmor": 0.5, "darmor": 0.35}   # damage taken

# ============================================================
#  ITEMS   key -> (name, icon, max stack, kind)
#  icon = ("i", cell in items.png) or ("t", tile in tiles.png)
# ============================================================

def _r(name, cell, kind="res", stack=64):
    return (name, ("i", cell), stack, kind)


def _t(name, tile, stack=64):
    return (name, ("t", tile), stack, "block")


ITEMS = {
    # resources
    "wood": _r("Wood", 0), "stone": _r("Stone", 1), "coal": _r("Coal", 19),
    "iron_ore": _r("Iron Ore", 20), "iron": _r("Iron Ingot", 4),
    "gold_ore": _r("Gold Ore", 21), "gold": _r("Gold Ingot", 22),
    "diamond": _r("Diamond", 23), "wool": _r("Wool", 33), "brick": _r("Brick", 34),
    "sand": ("Sand", ("t", 6), 64, "res"),
    "seeds": _r("Wheat Seeds", 37), "wheat": _r("Wheat", 38),
    # food
    "meat": _r("Raw Meat", 5, "food"), "cooked": _r("Cooked Meat", 6, "food"),
    "fish": _r("Raw Fish", 28, "food"), "cfish": _r("Cooked Fish", 29, "food"),
    "potato": _r("Potato", 16, "food"), "baked": _r("Baked Potato", 17, "food"),
    "radish": _r("Radish", 18, "food"), "bread": _r("Bread", 39, "food"),
    # tools
    "axe": _r("Axe", 7, "tool", 1), "pick": _r("Pickaxe", 8, "tool", 1),
    "ipick": _r("Iron Pickaxe", 30, "tool", 1), "shovel": _r("Shovel", 26, "tool", 1),
    "sword": _r("Sword", 9, "tool", 1), "isword": _r("Iron Sword", 10, "tool", 1),
    "dsword": _r("Diamond Sword", 31, "tool", 1), "rod": _r("Fishing Rod", 27, "tool", 1),
    # armor
    "iarmor": _r("Iron Armor", 11, "armor", 1), "garmor": _r("Gold Armor", 24, "armor", 1),
    "darmor": _r("Diamond Armor", 25, "armor", 1),
    # placeable blocks
    "floor": _t("Wood Floor", 8), "sfloor": _t("Stone Floor", 32),
    "carpet": _t("Red Carpet", 33), "tfloor": _t("Tile Floor", 34),
    "wall": _t("Wood Wall", 12), "swall": _t("Stone Wall", 13),
    "brickwall": _t("Brick Wall", 36), "glass": _t("Glass", 37),
    "dirt": _t("Dirt Block", 38), "door": _t("Door", 14), "bed": _t("Bed", 15),
    "table": _t("Craft Table", 21), "torch": _t("Torch", 22), "chest": _t("Chest", 41),
    "furnace": _t("Furnace", 42), "campfire": _t("Campfire", 16),
    "goldblock": _t("Gold Block", 39), "diamondblock": _t("Diamond Block", 40),
    "fence": _t("Oak Fence", 59), "gate": _t("Oak Fence Gate", 65),
}

# placeable item -> (kind, object/floor id)
PLACE = {
    "floor": ("floor", 1), "sfloor": ("floor", 2), "carpet": ("floor", 3),
    "tfloor": ("floor", 4),
    "wall": ("obj", O_WALL), "swall": ("obj", O_STONE), "brickwall": ("obj", O_BRICK),
    "glass": ("obj", O_GLASS), "door": ("obj", O_DOOR), "bed": ("obj", O_BED),
    "table": ("obj", O_TABLE), "torch": ("obj", O_TORCH), "chest": ("obj", O_CHEST),
    "furnace": ("obj", O_FURNACE), "campfire": ("obj", O_FIRE),
    "goldblock": ("obj", O_GOLDBLK), "diamondblock": ("obj", O_DIAMONDBLK),
    "dirt": ("dirt", O_DIRT), "potato": ("crop", O_POT0), "radish": ("crop", O_RAD0),
    "seeds": ("crop", O_WHT0), "fence": ("obj", O_FENCE), "gate": ("obj", O_GATE),
}
# object -> item you get back when you pick it up
PICK_ITEM = {
    O_WALL: "wall", O_STONE: "swall", O_BRICK: "brickwall", O_GLASS: "glass",
    O_DOOR: "door", O_BED: "bed", O_TABLE: "table", O_TORCH: "torch",
    O_CHEST: "chest", O_FURNACE: "furnace", O_FIRE: "campfire",
    O_GOLDBLK: "goldblock", O_DIAMONDBLK: "diamondblock", O_DIRT: "dirt",
    O_POT0: "potato", O_POT1: "potato", O_POT2: "potato",
    O_RAD0: "radish", O_RAD1: "radish", O_RAD2: "radish",
    O_WHT0: "seeds", O_WHT1: "seeds", O_WHT2: "seeds",
    O_FENCE: "fence", O_GATE: "gate", O_GATE_OPEN: "gate",
}
FLOOR_ITEM = {1: "floor", 2: "sfloor", 3: "carpet", 4: "tfloor"}

FOOD = {"meat": 4, "cooked": 12, "fish": 3, "cfish": 8, "potato": 3, "baked": 8,
        "radish": 4, "bread": 8}
COOK = {"meat": "cooked", "fish": "cfish", "potato": "baked"}          # campfire
SMELT = {"iron_ore": "iron", "gold_ore": "gold", "meat": "cooked", "fish": "cfish",
         "potato": "baked", "dirt": "brick", "sand": "glass"}           # furnace
FUEL = {"coal": 48.0, "wood": 12.0}                                     # burn seconds

# (result item, count, cost, needs craft table)
RECIPES = [
    ("table", 1, {"wood": 4}, False),
    ("torch", 2, {"wood": 1}, False),
    ("torch", 4, {"wood": 1, "coal": 1}, False),
    ("floor", 4, {"wood": 1}, False),
    ("wall", 2, {"wood": 2}, False),
    ("door", 1, {"wood": 3}, False),
    ("bed", 1, {"wood": 4}, False),
    ("chest", 1, {"wood": 8}, False),
    ("campfire", 1, {"wood": 3, "stone": 2}, False),
    ("furnace", 1, {"stone": 8}, False),
    ("sfloor", 4, {"stone": 2}, False),
    ("swall", 2, {"stone": 3}, False),
    ("tfloor", 4, {"stone": 1, "dirt": 1}, False),
    ("carpet", 3, {"wool": 2}, False),
    ("fence", 4, {"wood": 2}, False),
    ("gate", 1, {"wood": 3}, False),
    ("bread", 1, {"wheat": 3}, False),
    ("brickwall", 2, {"brick": 2}, False),
    ("axe", 1, {"wood": 3, "stone": 2}, True),
    ("pick", 1, {"wood": 2, "stone": 3}, True),
    ("shovel", 1, {"wood": 2, "stone": 1}, True),
    ("sword", 1, {"wood": 1, "stone": 2}, True),
    ("rod", 1, {"wood": 3, "stone": 1}, True),
    ("ipick", 1, {"wood": 2, "iron": 3}, True),
    ("isword", 1, {"wood": 1, "iron": 2}, True),
    ("dsword", 1, {"wood": 1, "diamond": 2}, True),
    ("iarmor", 1, {"iron": 8}, True),
    ("garmor", 1, {"gold": 8}, True),
    ("darmor", 1, {"diamond": 8}, True),
    ("goldblock", 1, {"gold": 5}, True),
    ("diamondblock", 1, {"diamond": 5}, True),
]

# ============================================================
#  MOBS
# ============================================================

ANIMALS = ("pig", "sheep", "cow", "chicken")
ANIMAL_FOOD = {"cow": ("wheat",), "sheep": ("wheat",), "pig": ("potato", "radish"),
               "chicken": ("seeds",)}
BABY_TIME = 90.0            # seconds until a baby animal grows up
BREED_COOLDOWN = 45.0
LOVE_TIME = 10.0
MOBS = {
    "pig": dict(hp=4, sp=18, hostile=False, dmg=0, drops=[("meat", 1, 2)]),
    "sheep": dict(hp=4, sp=16, hostile=False, dmg=0, drops=[("meat", 1, 2), ("wool", 1, 2)]),
    "cow": dict(hp=6, sp=14, hostile=False, dmg=0, drops=[("meat", 2, 3)]),
    "chicken": dict(hp=2, sp=22, hostile=False, dmg=0, drops=[("meat", 1, 1)]),
    "zombie": dict(hp=6, sp=30, hostile=True, dmg=2, drops=[]),
    "spider": dict(hp=5, sp=44, hostile=True, dmg=2, drops=[]),
    "ghost": dict(hp=8, sp=22, hostile=True, dmg=3, drops=[]),
}

# ============================================================
#  HELPERS
# ============================================================

def lerp(a, b, t):
    return a + (b - a) * t


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def night_factor(t):
    """0 = full day, 1 = full night."""
    if 7 <= t <= 17:
        return 0.0
    if 17 < t < 19:
        return (t - 17) / 2
    if t >= 19 or t < 5:
        return 1.0
    return 1 - (t - 5) / 2


def enc(grid):
    return "".join(chr(48 + v) for row in grid for v in row)


def dec(s):
    return [[ord(ch) - 48 for ch in s[i * MAP:(i + 1) * MAP]] for i in range(MAP)]


# ============================================================
#  WORLD GENERATION  (same world for the same SEED)
# ============================================================

def value_noise(rng, n, size):
    grid = [[rng.random() for _ in range(n + 2)] for _ in range(n + 2)]
    out = [[0.0] * size for _ in range(size)]
    for y in range(size):
        gy = y / size * n
        y0 = int(gy)
        fy = gy - y0
        fy = fy * fy * (3 - 2 * fy)
        for x in range(size):
            gx = x / size * n
            x0 = int(gx)
            fx = gx - x0
            fx = fx * fx * (3 - 2 * fx)
            a = lerp(grid[y0][x0], grid[y0][x0 + 1], fx)
            b = lerp(grid[y0 + 1][x0], grid[y0 + 1][x0 + 1], fx)
            out[y][x] = lerp(a, b, fy)
    return out


def gen_world(seed=SEED):
    rng = random.Random(seed)
    n = MAP
    h1 = value_noise(rng, 6, n)
    h2 = value_noise(rng, 14, n)
    forest = value_noise(rng, 7, n)
    rocks = value_noise(rng, 9, n)
    mtn = value_noise(rng, 5, n)
    ground = [[0] * n for _ in range(n)]
    var = [[0] * n for _ in range(n)]
    obj = [[0] * n for _ in range(n)]
    c = n / 2
    for y in range(n):
        for x in range(n):
            d = max(abs(x - c), abs(y - c)) / c
            h = 0.65 * h1[y][x] + 0.35 * h2[y][x]
            h -= 0.7 * max(0.0, d - 0.70) ** 1.3
            near_spawn = math.hypot(x - c, y - c)
            if near_spawn < 7:
                h = max(h, 0.55)
            g = G_WATER if h < 0.34 else (G_SAND if h < 0.38 else G_GRASS)
            ground[y][x] = g
            r1 = rng.random()
            r2 = rng.random()
            if g == G_GRASS:
                var[y][x] = 0 if r1 < 0.55 else 1 if r1 < 0.85 else 2 if r1 < 0.93 else 3
            else:
                var[y][x] = 0 if r1 < 0.6 else 1
            if near_spawn < 4 or g == G_WATER:
                continue
            if g == G_GRASS and near_spawn >= 14 and mtn[y][x] > 0.74:
                obj[y][x] = O_MASS                       # mountain
                ground[y][x] = G_CAVE
                continue
            if g == G_GRASS:
                p_tree = 0.30 if forest[y][x] > 0.52 else 0.05
                p_rock = 0.12 if rocks[y][x] > 0.66 else 0.015
                if r2 < p_tree:
                    obj[y][x] = O_TREE
                elif r2 < p_tree + p_rock:
                    obj[y][x] = O_ROCK
                elif r2 < p_tree + p_rock + 0.004:
                    obj[y][x] = O_POT2                  # wild potato (ripe)
                elif r2 < p_tree + p_rock + 0.008:
                    obj[y][x] = O_RAD2                  # wild radish (ripe)
                elif r2 < p_tree + p_rock + 0.014:
                    obj[y][x] = O_WHT2                  # wild wheat (ripe)
            elif r2 < 0.01:
                obj[y][x] = O_ROCK
    carve_caves(rng, ground, obj)
    return ground, var, obj


def carve_caves(rng, ground, obj):
    """Dig tunnels into every mountain and hide ores near them."""
    n = MAP
    seen = set()
    comps = []
    for y in range(n):
        for x in range(n):
            if obj[y][x] == O_MASS and (x, y) not in seen:
                comp, stack = [], [(x, y)]
                seen.add((x, y))
                while stack:
                    cx, cy = stack.pop()
                    comp.append((cx, cy))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = cx + dx, cy + dy
                        if 0 <= nx < n and 0 <= ny < n and obj[ny][nx] == O_MASS \
                                and (nx, ny) not in seen:
                            seen.add((nx, ny))
                            stack.append((nx, ny))
                comps.append(comp)
    carved = set()
    for comp in comps:
        if len(comp) < 30:
            continue
        cs = set(comp)
        edges = [(x, y, dx, dy) for (x, y) in sorted(comp)
                 for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                 if (x - dx, y - dy) not in cs and 0 <= x - dx < n and 0 <= y - dy < n]
        if not edges:
            continue

        def carve(px, py):
            if (px, py) in cs:
                obj[py][px] = 0
                ground[py][px] = G_CAVE
                carved.add((px, py))

        worms = min(5, 1 + len(comp) // 110)
        steps = min(90, 25 + len(comp) // 6)
        for _ in range(worms):
            x, y, dx, dy = rng.choice(edges)
            for _s in range(steps):
                carve(x, y)
                if rng.random() < 0.4:
                    carve(x + dy, y + dx)
                if rng.random() < 0.06:
                    for ox in (-1, 0, 1):
                        for oy in (-1, 0, 1):
                            carve(x + ox, y + oy)
                if rng.random() < 0.22:
                    dx, dy = (dy, dx) if rng.random() < 0.5 else (-dy, -dx)
                x += dx
                y += dy
                if (x, y) not in cs:
                    break
    # ores: more of them right next to the tunnels
    for comp in comps:
        for (x, y) in sorted(comp):
            if obj[y][x] != O_MASS:
                continue
            near = any((x + ox, y + oy) in carved
                       for ox in range(-2, 3) for oy in range(-2, 3))
            pd, pg, pi, pc = (0.024, 0.04, 0.08, 0.13) if near else (0.006, 0.01, 0.02, 0.04)
            r = rng.random()
            if r < pd:
                obj[y][x] = O_DIAMOND
            elif r < pd + pg:
                obj[y][x] = O_GOLD
            elif r < pd + pg + pi:
                obj[y][x] = O_IRON
            elif r < pd + pg + pi + pc:
                obj[y][x] = O_COAL

    # make sure every world has enough of each ore (small mountains are unlucky)
    cands = [(x, y) for comp in comps for (x, y) in sorted(comp)
             if obj[y][x] == O_MASS
             and any((x + ox, y + oy) in carved for ox in range(-2, 3) for oy in range(-2, 3))]
    rng.shuffle(cands)
    have = {}
    for row in obj:
        for v in row:
            have[v] = have.get(v, 0) + 1
    for ore, minimum in ((O_DIAMOND, 7), (O_GOLD, 9), (O_IRON, 20), (O_COAL, 30)):
        while have.get(ore, 0) < minimum and cands:
            x, y = cands.pop()
            obj[y][x] = ore
            have[ore] = have.get(ore, 0) + 1
